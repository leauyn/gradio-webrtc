import { _ as a, d as o } from "./mermaid.core-DnykLoWL.js";
var d = /* @__PURE__ */ a((t, e) => {
  let n;
  return e === "sandbox" && (n = o("#i" + t)), (e === "sandbox" ? o(n.nodes()[0].contentDocument.body) : o("body")).select(`[id="${t}"]`);
}, "getDiagramElement");
export {
  d as g
};
