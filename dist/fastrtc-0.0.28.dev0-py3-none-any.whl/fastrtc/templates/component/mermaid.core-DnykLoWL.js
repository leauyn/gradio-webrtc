var eg = Object.defineProperty;
var rg = (e, t, r) => t in e ? eg(e, t, { enumerable: !0, configurable: !0, writable: !0, value: r }) : e[t] = r;
var ot = (e, t, r) => rg(e, typeof t != "symbol" ? t + "" : t, r);
import { g as ig, c as ng, p as gr } from "./index-Bt-EZqiV.js";
var mo = {
  name: "mermaid",
  version: "11.11.0",
  description: "Markdown-ish syntax for generating flowcharts, mindmaps, sequence diagrams, class diagrams, gantt charts, git graphs and more.",
  type: "module",
  module: "./dist/mermaid.core.mjs",
  types: "./dist/mermaid.d.ts",
  exports: {
    ".": {
      types: "./dist/mermaid.d.ts",
      import: "./dist/mermaid.core.mjs",
      default: "./dist/mermaid.core.mjs"
    },
    "./*": "./*"
  },
  keywords: [
    "diagram",
    "markdown",
    "flowchart",
    "sequence diagram",
    "gantt",
    "class diagram",
    "git graph",
    "mindmap",
    "packet diagram",
    "c4 diagram",
    "er diagram",
    "pie chart",
    "pie diagram",
    "quadrant chart",
    "requirement diagram",
    "graph"
  ],
  scripts: {
    clean: "rimraf dist",
    dev: "pnpm -w dev",
    "docs:code": "typedoc src/defaultConfig.ts src/config.ts src/mermaid.ts && prettier --write ./src/docs/config/setup",
    "docs:build": "rimraf ../../docs && pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts",
    "docs:verify": "pnpm docs:code && pnpm docs:spellcheck && tsx scripts/docs.cli.mts --verify",
    "docs:pre:vitepress": "pnpm --filter ./src/docs prefetch && rimraf src/vitepress && pnpm docs:code && tsx scripts/docs.cli.mts --vitepress && pnpm --filter ./src/vitepress install --no-frozen-lockfile --ignore-scripts",
    "docs:build:vitepress": "pnpm docs:pre:vitepress && (cd src/vitepress && pnpm run build) && cpy --flat src/docs/landing/ ./src/vitepress/.vitepress/dist/landing",
    "docs:dev": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:dev:docker": 'pnpm docs:pre:vitepress && concurrently "pnpm --filter ./src/vitepress dev:docker" "tsx scripts/docs.cli.mts --watch --vitepress"',
    "docs:serve": "pnpm docs:build:vitepress && vitepress serve src/vitepress",
    "docs:spellcheck": 'cspell "src/docs/**/*.md"',
    "docs:release-version": "tsx scripts/update-release-version.mts",
    "docs:verify-version": "tsx scripts/update-release-version.mts --verify",
    "types:build-config": "tsx scripts/create-types-from-json-schema.mts",
    "types:verify-config": "tsx scripts/create-types-from-json-schema.mts --verify",
    checkCircle: "npx madge --circular ./src",
    prepublishOnly: "pnpm docs:verify-version"
  },
  repository: {
    type: "git",
    url: "https://github.com/mermaid-js/mermaid"
  },
  author: "Knut Sveidqvist",
  license: "MIT",
  standard: {
    ignore: [
      "**/parser/*.js",
      "dist/**/*.js",
      "cypress/**/*.js"
    ],
    globals: [
      "page"
    ]
  },
  dependencies: {
    "@braintree/sanitize-url": "^7.0.4",
    "@iconify/utils": "^3.0.1",
    "@mermaid-js/parser": "workspace:^",
    "@types/d3": "^7.4.3",
    cytoscape: "^3.29.3",
    "cytoscape-cose-bilkent": "^4.1.0",
    "cytoscape-fcose": "^2.2.0",
    d3: "^7.9.0",
    "d3-sankey": "^0.12.3",
    "dagre-d3-es": "7.0.11",
    dayjs: "^1.11.13",
    dompurify: "^3.2.5",
    katex: "^0.16.22",
    khroma: "^2.1.0",
    "lodash-es": "^4.17.21",
    marked: "^15.0.7",
    roughjs: "^4.6.6",
    stylis: "^4.3.6",
    "ts-dedent": "^2.2.0",
    uuid: "^11.1.0"
  },
  devDependencies: {
    "@adobe/jsonschema2md": "^8.0.2",
    "@iconify/types": "^2.0.0",
    "@types/cytoscape": "^3.21.9",
    "@types/cytoscape-fcose": "^2.2.4",
    "@types/d3-sankey": "^0.12.4",
    "@types/d3-scale": "^4.0.9",
    "@types/d3-scale-chromatic": "^3.1.0",
    "@types/d3-selection": "^3.0.11",
    "@types/d3-shape": "^3.1.7",
    "@types/jsdom": "^21.1.7",
    "@types/katex": "^0.16.7",
    "@types/lodash-es": "^4.17.12",
    "@types/micromatch": "^4.0.9",
    "@types/stylis": "^4.2.7",
    "@types/uuid": "^10.0.0",
    ajv: "^8.17.1",
    canvas: "^3.1.0",
    chokidar: "3.6.0",
    concurrently: "^9.1.2",
    "csstree-validator": "^4.0.1",
    globby: "^14.0.2",
    jison: "^0.4.18",
    "js-base64": "^3.7.7",
    jsdom: "^26.1.0",
    "json-schema-to-typescript": "^15.0.4",
    micromatch: "^4.0.8",
    "path-browserify": "^1.0.1",
    prettier: "^3.5.2",
    remark: "^15.0.1",
    "remark-frontmatter": "^5.0.0",
    "remark-gfm": "^4.0.1",
    rimraf: "^6.0.1",
    "start-server-and-test": "^2.0.10",
    "type-fest": "^4.35.0",
    typedoc: "^0.28.9",
    "typedoc-plugin-markdown": "^4.8.0",
    typescript: "~5.7.3",
    "unist-util-flatmap": "^1.0.0",
    "unist-util-visit": "^5.0.0",
    vitepress: "^1.0.2",
    "vitepress-plugin-search": "1.0.4-alpha.22"
  },
  files: [
    "dist/",
    "README.md"
  ],
  publishConfig: {
    access: "public"
  }
}, Nl = { exports: {} };
(function(e, t) {
  (function(r, i) {
    e.exports = i();
  })(ng, function() {
    var r = 1e3, i = 6e4, n = 36e5, a = "millisecond", o = "second", s = "minute", l = "hour", c = "day", h = "week", u = "month", f = "quarter", d = "year", g = "date", m = "Invalid Date", x = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, y = /\[([^\]]+)]|Y{1,4}|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, b = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function(B) {
      var L = ["th", "st", "nd", "rd"], T = B % 100;
      return "[" + B + (L[(T - 20) % 10] || L[T] || L[0]) + "]";
    } }, w = function(B, L, T) {
      var $ = String(B);
      return !$ || $.length >= L ? B : "" + Array(L + 1 - $.length).join(T) + B;
    }, k = { s: w, z: function(B) {
      var L = -B.utcOffset(), T = Math.abs(L), $ = Math.floor(T / 60), M = T % 60;
      return (L <= 0 ? "+" : "-") + w($, 2, "0") + ":" + w(M, 2, "0");
    }, m: function B(L, T) {
      if (L.date() < T.date()) return -B(T, L);
      var $ = 12 * (T.year() - L.year()) + (T.month() - L.month()), M = L.clone().add($, u), z = T - M < 0, U = L.clone().add($ + (z ? -1 : 1), u);
      return +(-($ + (T - M) / (z ? M - U : U - M)) || 0);
    }, a: function(B) {
      return B < 0 ? Math.ceil(B) || 0 : Math.floor(B);
    }, p: function(B) {
      return { M: u, y: d, w: h, d: c, D: g, h: l, m: s, s: o, ms: a, Q: f }[B] || String(B || "").toLowerCase().replace(/s$/, "");
    }, u: function(B) {
      return B === void 0;
    } }, _ = "en", C = {};
    C[_] = b;
    var v = "$isDayjsObject", D = function(B) {
      return B instanceof I || !(!B || !B[v]);
    }, R = function B(L, T, $) {
      var M;
      if (!L) return _;
      if (typeof L == "string") {
        var z = L.toLowerCase();
        C[z] && (M = z), T && (C[z] = T, M = z);
        var U = L.split("-");
        if (!M && U.length > 1) return B(U[0]);
      } else {
        var J = L.name;
        C[J] = L, M = J;
      }
      return !$ && M && (_ = M), M || !$ && _;
    }, O = function(B, L) {
      if (D(B)) return B.clone();
      var T = typeof L == "object" ? L : {};
      return T.date = B, T.args = arguments, new I(T);
    }, A = k;
    A.l = R, A.i = D, A.w = function(B, L) {
      return O(B, { locale: L.$L, utc: L.$u, x: L.$x, $offset: L.$offset });
    };
    var I = function() {
      function B(T) {
        this.$L = R(T.locale, null, !0), this.parse(T), this.$x = this.$x || T.x || {}, this[v] = !0;
      }
      var L = B.prototype;
      return L.parse = function(T) {
        this.$d = function($) {
          var M = $.date, z = $.utc;
          if (M === null) return /* @__PURE__ */ new Date(NaN);
          if (A.u(M)) return /* @__PURE__ */ new Date();
          if (M instanceof Date) return new Date(M);
          if (typeof M == "string" && !/Z$/i.test(M)) {
            var U = M.match(x);
            if (U) {
              var J = U[2] - 1 || 0, lt = (U[7] || "0").substring(0, 3);
              return z ? new Date(Date.UTC(U[1], J, U[3] || 1, U[4] || 0, U[5] || 0, U[6] || 0, lt)) : new Date(U[1], J, U[3] || 1, U[4] || 0, U[5] || 0, U[6] || 0, lt);
            }
          }
          return new Date(M);
        }(T), this.init();
      }, L.init = function() {
        var T = this.$d;
        this.$y = T.getFullYear(), this.$M = T.getMonth(), this.$D = T.getDate(), this.$W = T.getDay(), this.$H = T.getHours(), this.$m = T.getMinutes(), this.$s = T.getSeconds(), this.$ms = T.getMilliseconds();
      }, L.$utils = function() {
        return A;
      }, L.isValid = function() {
        return this.$d.toString() !== m;
      }, L.isSame = function(T, $) {
        var M = O(T);
        return this.startOf($) <= M && M <= this.endOf($);
      }, L.isAfter = function(T, $) {
        return O(T) < this.startOf($);
      }, L.isBefore = function(T, $) {
        return this.endOf($) < O(T);
      }, L.$g = function(T, $, M) {
        return A.u(T) ? this[$] : this.set(M, T);
      }, L.unix = function() {
        return Math.floor(this.valueOf() / 1e3);
      }, L.valueOf = function() {
        return this.$d.getTime();
      }, L.startOf = function(T, $) {
        var M = this, z = !!A.u($) || $, U = A.p(T), J = function(dt, ut) {
          var _t = A.w(M.$u ? Date.UTC(M.$y, ut, dt) : new Date(M.$y, ut, dt), M);
          return z ? _t : _t.endOf(c);
        }, lt = function(dt, ut) {
          return A.w(M.toDate()[dt].apply(M.toDate("s"), (z ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(ut)), M);
        }, ft = this.$W, yt = this.$M, At = this.$D, et = "set" + (this.$u ? "UTC" : "");
        switch (U) {
          case d:
            return z ? J(1, 0) : J(31, 11);
          case u:
            return z ? J(1, yt) : J(0, yt + 1);
          case h:
            var it = this.$locale().weekStart || 0, gt = (ft < it ? ft + 7 : ft) - it;
            return J(z ? At - gt : At + (6 - gt), yt);
          case c:
          case g:
            return lt(et + "Hours", 0);
          case l:
            return lt(et + "Minutes", 1);
          case s:
            return lt(et + "Seconds", 2);
          case o:
            return lt(et + "Milliseconds", 3);
          default:
            return this.clone();
        }
      }, L.endOf = function(T) {
        return this.startOf(T, !1);
      }, L.$set = function(T, $) {
        var M, z = A.p(T), U = "set" + (this.$u ? "UTC" : ""), J = (M = {}, M[c] = U + "Date", M[g] = U + "Date", M[u] = U + "Month", M[d] = U + "FullYear", M[l] = U + "Hours", M[s] = U + "Minutes", M[o] = U + "Seconds", M[a] = U + "Milliseconds", M)[z], lt = z === c ? this.$D + ($ - this.$W) : $;
        if (z === u || z === d) {
          var ft = this.clone().set(g, 1);
          ft.$d[J](lt), ft.init(), this.$d = ft.set(g, Math.min(this.$D, ft.daysInMonth())).$d;
        } else J && this.$d[J](lt);
        return this.init(), this;
      }, L.set = function(T, $) {
        return this.clone().$set(T, $);
      }, L.get = function(T) {
        return this[A.p(T)]();
      }, L.add = function(T, $) {
        var M, z = this;
        T = Number(T);
        var U = A.p($), J = function(yt) {
          var At = O(z);
          return A.w(At.date(At.date() + Math.round(yt * T)), z);
        };
        if (U === u) return this.set(u, this.$M + T);
        if (U === d) return this.set(d, this.$y + T);
        if (U === c) return J(1);
        if (U === h) return J(7);
        var lt = (M = {}, M[s] = i, M[l] = n, M[o] = r, M)[U] || 1, ft = this.$d.getTime() + T * lt;
        return A.w(ft, this);
      }, L.subtract = function(T, $) {
        return this.add(-1 * T, $);
      }, L.format = function(T) {
        var $ = this, M = this.$locale();
        if (!this.isValid()) return M.invalidDate || m;
        var z = T || "YYYY-MM-DDTHH:mm:ssZ", U = A.z(this), J = this.$H, lt = this.$m, ft = this.$M, yt = M.weekdays, At = M.months, et = M.meridiem, it = function(ut, _t, ye, $r) {
          return ut && (ut[_t] || ut($, z)) || ye[_t].slice(0, $r);
        }, gt = function(ut) {
          return A.s(J % 12 || 12, ut, "0");
        }, dt = et || function(ut, _t, ye) {
          var $r = ut < 12 ? "AM" : "PM";
          return ye ? $r.toLowerCase() : $r;
        };
        return z.replace(y, function(ut, _t) {
          return _t || function(ye) {
            switch (ye) {
              case "YY":
                return String($.$y).slice(-2);
              case "YYYY":
                return A.s($.$y, 4, "0");
              case "M":
                return ft + 1;
              case "MM":
                return A.s(ft + 1, 2, "0");
              case "MMM":
                return it(M.monthsShort, ft, At, 3);
              case "MMMM":
                return it(At, ft);
              case "D":
                return $.$D;
              case "DD":
                return A.s($.$D, 2, "0");
              case "d":
                return String($.$W);
              case "dd":
                return it(M.weekdaysMin, $.$W, yt, 2);
              case "ddd":
                return it(M.weekdaysShort, $.$W, yt, 3);
              case "dddd":
                return yt[$.$W];
              case "H":
                return String(J);
              case "HH":
                return A.s(J, 2, "0");
              case "h":
                return gt(1);
              case "hh":
                return gt(2);
              case "a":
                return dt(J, lt, !0);
              case "A":
                return dt(J, lt, !1);
              case "m":
                return String(lt);
              case "mm":
                return A.s(lt, 2, "0");
              case "s":
                return String($.$s);
              case "ss":
                return A.s($.$s, 2, "0");
              case "SSS":
                return A.s($.$ms, 3, "0");
              case "Z":
                return U;
            }
            return null;
          }(ut) || U.replace(":", "");
        });
      }, L.utcOffset = function() {
        return 15 * -Math.round(this.$d.getTimezoneOffset() / 15);
      }, L.diff = function(T, $, M) {
        var z, U = this, J = A.p($), lt = O(T), ft = (lt.utcOffset() - this.utcOffset()) * i, yt = this - lt, At = function() {
          return A.m(U, lt);
        };
        switch (J) {
          case d:
            z = At() / 12;
            break;
          case u:
            z = At();
            break;
          case f:
            z = At() / 3;
            break;
          case h:
            z = (yt - ft) / 6048e5;
            break;
          case c:
            z = (yt - ft) / 864e5;
            break;
          case l:
            z = yt / n;
            break;
          case s:
            z = yt / i;
            break;
          case o:
            z = yt / r;
            break;
          default:
            z = yt;
        }
        return M ? z : A.a(z);
      }, L.daysInMonth = function() {
        return this.endOf(u).$D;
      }, L.$locale = function() {
        return C[this.$L];
      }, L.locale = function(T, $) {
        if (!T) return this.$L;
        var M = this.clone(), z = R(T, $, !0);
        return z && (M.$L = z), M;
      }, L.clone = function() {
        return A.w(this.$d, this);
      }, L.toDate = function() {
        return new Date(this.valueOf());
      }, L.toJSON = function() {
        return this.isValid() ? this.toISOString() : null;
      }, L.toISOString = function() {
        return this.$d.toISOString();
      }, L.toString = function() {
        return this.$d.toUTCString();
      }, B;
    }(), E = I.prototype;
    return O.prototype = E, [["$ms", a], ["$s", o], ["$m", s], ["$H", l], ["$W", c], ["$M", u], ["$y", d], ["$D", g]].forEach(function(B) {
      E[B[1]] = function(L) {
        return this.$g(L, B[0], B[1]);
      };
    }), O.extend = function(B, L) {
      return B.$i || (B(L, I, O), B.$i = !0), O;
    }, O.locale = R, O.isDayjs = D, O.unix = function(B) {
      return O(1e3 * B);
    }, O.en = C[_], O.Ls = C, O.p = {}, O;
  });
})(Nl);
var ag = Nl.exports;
const sg = /* @__PURE__ */ ig(ag);
var zl = Object.defineProperty, p = (e, t) => zl(e, "name", { value: t, configurable: !0 }), og = (e, t) => {
  for (var r in t)
    zl(e, r, { get: t[r], enumerable: !0 });
}, se = {
  trace: 0,
  debug: 1,
  info: 2,
  warn: 3,
  error: 4,
  fatal: 5
}, F = {
  trace: /* @__PURE__ */ p((...e) => {
  }, "trace"),
  debug: /* @__PURE__ */ p((...e) => {
  }, "debug"),
  info: /* @__PURE__ */ p((...e) => {
  }, "info"),
  warn: /* @__PURE__ */ p((...e) => {
  }, "warn"),
  error: /* @__PURE__ */ p((...e) => {
  }, "error"),
  fatal: /* @__PURE__ */ p((...e) => {
  }, "fatal")
}, fs = /* @__PURE__ */ p(function(e = "fatal") {
  let t = se.fatal;
  typeof e == "string" ? e.toLowerCase() in se && (t = se[e]) : typeof e == "number" && (t = e), F.trace = () => {
  }, F.debug = () => {
  }, F.info = () => {
  }, F.warn = () => {
  }, F.error = () => {
  }, F.fatal = () => {
  }, t <= se.fatal && (F.fatal = console.error ? console.error.bind(console, Wt("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", Wt("FATAL"))), t <= se.error && (F.error = console.error ? console.error.bind(console, Wt("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", Wt("ERROR"))), t <= se.warn && (F.warn = console.warn ? console.warn.bind(console, Wt("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", Wt("WARN"))), t <= se.info && (F.info = console.info ? console.info.bind(console, Wt("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", Wt("INFO"))), t <= se.debug && (F.debug = console.debug ? console.debug.bind(console, Wt("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Wt("DEBUG"))), t <= se.trace && (F.trace = console.debug ? console.debug.bind(console, Wt("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", Wt("TRACE")));
}, "setLogLevel"), Wt = /* @__PURE__ */ p((e) => `%c${sg().format("ss.SSS")} : ${e} : `, "format");
const $i = {
  /* CLAMP */
  min: {
    r: 0,
    g: 0,
    b: 0,
    s: 0,
    l: 0,
    a: 0
  },
  max: {
    r: 255,
    g: 255,
    b: 255,
    h: 360,
    s: 100,
    l: 100,
    a: 1
  },
  clamp: {
    r: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    g: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    b: (e) => e >= 255 ? 255 : e < 0 ? 0 : e,
    h: (e) => e % 360,
    s: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    l: (e) => e >= 100 ? 100 : e < 0 ? 0 : e,
    a: (e) => e >= 1 ? 1 : e < 0 ? 0 : e
  },
  /* CONVERSION */
  //SOURCE: https://planetcalc.com/7779
  toLinear: (e) => {
    const t = e / 255;
    return e > 0.03928 ? Math.pow((t + 0.055) / 1.055, 2.4) : t / 12.92;
  },
  //SOURCE: https://gist.github.com/mjackson/5311256
  hue2rgb: (e, t, r) => (r < 0 && (r += 1), r > 1 && (r -= 1), r < 1 / 6 ? e + (t - e) * 6 * r : r < 1 / 2 ? t : r < 2 / 3 ? e + (t - e) * (2 / 3 - r) * 6 : e),
  hsl2rgb: ({ h: e, s: t, l: r }, i) => {
    if (!t)
      return r * 2.55;
    e /= 360, t /= 100, r /= 100;
    const n = r < 0.5 ? r * (1 + t) : r + t - r * t, a = 2 * r - n;
    switch (i) {
      case "r":
        return $i.hue2rgb(a, n, e + 1 / 3) * 255;
      case "g":
        return $i.hue2rgb(a, n, e) * 255;
      case "b":
        return $i.hue2rgb(a, n, e - 1 / 3) * 255;
    }
  },
  rgb2hsl: ({ r: e, g: t, b: r }, i) => {
    e /= 255, t /= 255, r /= 255;
    const n = Math.max(e, t, r), a = Math.min(e, t, r), o = (n + a) / 2;
    if (i === "l")
      return o * 100;
    if (n === a)
      return 0;
    const s = n - a, l = o > 0.5 ? s / (2 - n - a) : s / (n + a);
    if (i === "s")
      return l * 100;
    switch (n) {
      case e:
        return ((t - r) / s + (t < r ? 6 : 0)) * 60;
      case t:
        return ((r - e) / s + 2) * 60;
      case r:
        return ((e - t) / s + 4) * 60;
      default:
        return -1;
    }
  }
}, lg = {
  /* API */
  clamp: (e, t, r) => t > r ? Math.min(t, Math.max(r, e)) : Math.min(r, Math.max(t, e)),
  round: (e) => Math.round(e * 1e10) / 1e10
}, cg = {
  /* API */
  dec2hex: (e) => {
    const t = Math.round(e).toString(16);
    return t.length > 1 ? t : `0${t}`;
  }
}, Q = {
  channel: $i,
  lang: lg,
  unit: cg
}, xe = {};
for (let e = 0; e <= 255; e++)
  xe[e] = Q.unit.dec2hex(e);
const St = {
  ALL: 0,
  RGB: 1,
  HSL: 2
};
class hg {
  constructor() {
    this.type = St.ALL;
  }
  /* API */
  get() {
    return this.type;
  }
  set(t) {
    if (this.type && this.type !== t)
      throw new Error("Cannot change both RGB and HSL channels at the same time");
    this.type = t;
  }
  reset() {
    this.type = St.ALL;
  }
  is(t) {
    return this.type === t;
  }
}
class ug {
  /* CONSTRUCTOR */
  constructor(t, r) {
    this.color = r, this.changed = !1, this.data = t, this.type = new hg();
  }
  /* API */
  set(t, r) {
    return this.color = r, this.changed = !1, this.data = t, this.type.type = St.ALL, this;
  }
  /* HELPERS */
  _ensureHSL() {
    const t = this.data, { h: r, s: i, l: n } = t;
    r === void 0 && (t.h = Q.channel.rgb2hsl(t, "h")), i === void 0 && (t.s = Q.channel.rgb2hsl(t, "s")), n === void 0 && (t.l = Q.channel.rgb2hsl(t, "l"));
  }
  _ensureRGB() {
    const t = this.data, { r, g: i, b: n } = t;
    r === void 0 && (t.r = Q.channel.hsl2rgb(t, "r")), i === void 0 && (t.g = Q.channel.hsl2rgb(t, "g")), n === void 0 && (t.b = Q.channel.hsl2rgb(t, "b"));
  }
  /* GETTERS */
  get r() {
    const t = this.data, r = t.r;
    return !this.type.is(St.HSL) && r !== void 0 ? r : (this._ensureHSL(), Q.channel.hsl2rgb(t, "r"));
  }
  get g() {
    const t = this.data, r = t.g;
    return !this.type.is(St.HSL) && r !== void 0 ? r : (this._ensureHSL(), Q.channel.hsl2rgb(t, "g"));
  }
  get b() {
    const t = this.data, r = t.b;
    return !this.type.is(St.HSL) && r !== void 0 ? r : (this._ensureHSL(), Q.channel.hsl2rgb(t, "b"));
  }
  get h() {
    const t = this.data, r = t.h;
    return !this.type.is(St.RGB) && r !== void 0 ? r : (this._ensureRGB(), Q.channel.rgb2hsl(t, "h"));
  }
  get s() {
    const t = this.data, r = t.s;
    return !this.type.is(St.RGB) && r !== void 0 ? r : (this._ensureRGB(), Q.channel.rgb2hsl(t, "s"));
  }
  get l() {
    const t = this.data, r = t.l;
    return !this.type.is(St.RGB) && r !== void 0 ? r : (this._ensureRGB(), Q.channel.rgb2hsl(t, "l"));
  }
  get a() {
    return this.data.a;
  }
  /* SETTERS */
  set r(t) {
    this.type.set(St.RGB), this.changed = !0, this.data.r = t;
  }
  set g(t) {
    this.type.set(St.RGB), this.changed = !0, this.data.g = t;
  }
  set b(t) {
    this.type.set(St.RGB), this.changed = !0, this.data.b = t;
  }
  set h(t) {
    this.type.set(St.HSL), this.changed = !0, this.data.h = t;
  }
  set s(t) {
    this.type.set(St.HSL), this.changed = !0, this.data.s = t;
  }
  set l(t) {
    this.type.set(St.HSL), this.changed = !0, this.data.l = t;
  }
  set a(t) {
    this.changed = !0, this.data.a = t;
  }
}
const Bn = new ug({ r: 0, g: 0, b: 0, a: 0 }, "transparent"), nr = {
  /* VARIABLES */
  re: /^#((?:[a-f0-9]{2}){2,4}|[a-f0-9]{3})$/i,
  /* API */
  parse: (e) => {
    if (e.charCodeAt(0) !== 35)
      return;
    const t = e.match(nr.re);
    if (!t)
      return;
    const r = t[1], i = parseInt(r, 16), n = r.length, a = n % 4 === 0, o = n > 4, s = o ? 1 : 17, l = o ? 8 : 4, c = a ? 0 : -1, h = o ? 255 : 15;
    return Bn.set({
      r: (i >> l * (c + 3) & h) * s,
      g: (i >> l * (c + 2) & h) * s,
      b: (i >> l * (c + 1) & h) * s,
      a: a ? (i & h) * s / 255 : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `#${xe[Math.round(t)]}${xe[Math.round(r)]}${xe[Math.round(i)]}${xe[Math.round(n * 255)]}` : `#${xe[Math.round(t)]}${xe[Math.round(r)]}${xe[Math.round(i)]}`;
  }
}, De = {
  /* VARIABLES */
  re: /^hsla?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(?:deg|grad|rad|turn)?)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?%)(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e-?\d+)?(%)?))?\s*?\)$/i,
  hueRe: /^(.+?)(deg|grad|rad|turn)$/i,
  /* HELPERS */
  _hue2deg: (e) => {
    const t = e.match(De.hueRe);
    if (t) {
      const [, r, i] = t;
      switch (i) {
        case "grad":
          return Q.channel.clamp.h(parseFloat(r) * 0.9);
        case "rad":
          return Q.channel.clamp.h(parseFloat(r) * 180 / Math.PI);
        case "turn":
          return Q.channel.clamp.h(parseFloat(r) * 360);
      }
    }
    return Q.channel.clamp.h(parseFloat(e));
  },
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 104 && t !== 72)
      return;
    const r = e.match(De.re);
    if (!r)
      return;
    const [, i, n, a, o, s] = r;
    return Bn.set({
      h: De._hue2deg(i),
      s: Q.channel.clamp.s(parseFloat(n)),
      l: Q.channel.clamp.l(parseFloat(a)),
      a: o ? Q.channel.clamp.a(s ? parseFloat(o) / 100 : parseFloat(o)) : 1
    }, e);
  },
  stringify: (e) => {
    const { h: t, s: r, l: i, a: n } = e;
    return n < 1 ? `hsla(${Q.lang.round(t)}, ${Q.lang.round(r)}%, ${Q.lang.round(i)}%, ${n})` : `hsl(${Q.lang.round(t)}, ${Q.lang.round(r)}%, ${Q.lang.round(i)}%)`;
  }
}, Gr = {
  /* VARIABLES */
  colors: {
    aliceblue: "#f0f8ff",
    antiquewhite: "#faebd7",
    aqua: "#00ffff",
    aquamarine: "#7fffd4",
    azure: "#f0ffff",
    beige: "#f5f5dc",
    bisque: "#ffe4c4",
    black: "#000000",
    blanchedalmond: "#ffebcd",
    blue: "#0000ff",
    blueviolet: "#8a2be2",
    brown: "#a52a2a",
    burlywood: "#deb887",
    cadetblue: "#5f9ea0",
    chartreuse: "#7fff00",
    chocolate: "#d2691e",
    coral: "#ff7f50",
    cornflowerblue: "#6495ed",
    cornsilk: "#fff8dc",
    crimson: "#dc143c",
    cyanaqua: "#00ffff",
    darkblue: "#00008b",
    darkcyan: "#008b8b",
    darkgoldenrod: "#b8860b",
    darkgray: "#a9a9a9",
    darkgreen: "#006400",
    darkgrey: "#a9a9a9",
    darkkhaki: "#bdb76b",
    darkmagenta: "#8b008b",
    darkolivegreen: "#556b2f",
    darkorange: "#ff8c00",
    darkorchid: "#9932cc",
    darkred: "#8b0000",
    darksalmon: "#e9967a",
    darkseagreen: "#8fbc8f",
    darkslateblue: "#483d8b",
    darkslategray: "#2f4f4f",
    darkslategrey: "#2f4f4f",
    darkturquoise: "#00ced1",
    darkviolet: "#9400d3",
    deeppink: "#ff1493",
    deepskyblue: "#00bfff",
    dimgray: "#696969",
    dimgrey: "#696969",
    dodgerblue: "#1e90ff",
    firebrick: "#b22222",
    floralwhite: "#fffaf0",
    forestgreen: "#228b22",
    fuchsia: "#ff00ff",
    gainsboro: "#dcdcdc",
    ghostwhite: "#f8f8ff",
    gold: "#ffd700",
    goldenrod: "#daa520",
    gray: "#808080",
    green: "#008000",
    greenyellow: "#adff2f",
    grey: "#808080",
    honeydew: "#f0fff0",
    hotpink: "#ff69b4",
    indianred: "#cd5c5c",
    indigo: "#4b0082",
    ivory: "#fffff0",
    khaki: "#f0e68c",
    lavender: "#e6e6fa",
    lavenderblush: "#fff0f5",
    lawngreen: "#7cfc00",
    lemonchiffon: "#fffacd",
    lightblue: "#add8e6",
    lightcoral: "#f08080",
    lightcyan: "#e0ffff",
    lightgoldenrodyellow: "#fafad2",
    lightgray: "#d3d3d3",
    lightgreen: "#90ee90",
    lightgrey: "#d3d3d3",
    lightpink: "#ffb6c1",
    lightsalmon: "#ffa07a",
    lightseagreen: "#20b2aa",
    lightskyblue: "#87cefa",
    lightslategray: "#778899",
    lightslategrey: "#778899",
    lightsteelblue: "#b0c4de",
    lightyellow: "#ffffe0",
    lime: "#00ff00",
    limegreen: "#32cd32",
    linen: "#faf0e6",
    magenta: "#ff00ff",
    maroon: "#800000",
    mediumaquamarine: "#66cdaa",
    mediumblue: "#0000cd",
    mediumorchid: "#ba55d3",
    mediumpurple: "#9370db",
    mediumseagreen: "#3cb371",
    mediumslateblue: "#7b68ee",
    mediumspringgreen: "#00fa9a",
    mediumturquoise: "#48d1cc",
    mediumvioletred: "#c71585",
    midnightblue: "#191970",
    mintcream: "#f5fffa",
    mistyrose: "#ffe4e1",
    moccasin: "#ffe4b5",
    navajowhite: "#ffdead",
    navy: "#000080",
    oldlace: "#fdf5e6",
    olive: "#808000",
    olivedrab: "#6b8e23",
    orange: "#ffa500",
    orangered: "#ff4500",
    orchid: "#da70d6",
    palegoldenrod: "#eee8aa",
    palegreen: "#98fb98",
    paleturquoise: "#afeeee",
    palevioletred: "#db7093",
    papayawhip: "#ffefd5",
    peachpuff: "#ffdab9",
    peru: "#cd853f",
    pink: "#ffc0cb",
    plum: "#dda0dd",
    powderblue: "#b0e0e6",
    purple: "#800080",
    rebeccapurple: "#663399",
    red: "#ff0000",
    rosybrown: "#bc8f8f",
    royalblue: "#4169e1",
    saddlebrown: "#8b4513",
    salmon: "#fa8072",
    sandybrown: "#f4a460",
    seagreen: "#2e8b57",
    seashell: "#fff5ee",
    sienna: "#a0522d",
    silver: "#c0c0c0",
    skyblue: "#87ceeb",
    slateblue: "#6a5acd",
    slategray: "#708090",
    slategrey: "#708090",
    snow: "#fffafa",
    springgreen: "#00ff7f",
    tan: "#d2b48c",
    teal: "#008080",
    thistle: "#d8bfd8",
    transparent: "#00000000",
    turquoise: "#40e0d0",
    violet: "#ee82ee",
    wheat: "#f5deb3",
    white: "#ffffff",
    whitesmoke: "#f5f5f5",
    yellow: "#ffff00",
    yellowgreen: "#9acd32"
  },
  /* API */
  parse: (e) => {
    e = e.toLowerCase();
    const t = Gr.colors[e];
    if (t)
      return nr.parse(t);
  },
  stringify: (e) => {
    const t = nr.stringify(e);
    for (const r in Gr.colors)
      if (Gr.colors[r] === t)
        return r;
  }
}, Pr = {
  /* VARIABLES */
  re: /^rgba?\(\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))\s*?(?:,|\s)\s*?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?))(?:\s*?(?:,|\/)\s*?\+?(-?(?:\d+(?:\.\d+)?|(?:\.\d+))(?:e\d+)?(%?)))?\s*?\)$/i,
  /* API */
  parse: (e) => {
    const t = e.charCodeAt(0);
    if (t !== 114 && t !== 82)
      return;
    const r = e.match(Pr.re);
    if (!r)
      return;
    const [, i, n, a, o, s, l, c, h] = r;
    return Bn.set({
      r: Q.channel.clamp.r(n ? parseFloat(i) * 2.55 : parseFloat(i)),
      g: Q.channel.clamp.g(o ? parseFloat(a) * 2.55 : parseFloat(a)),
      b: Q.channel.clamp.b(l ? parseFloat(s) * 2.55 : parseFloat(s)),
      a: c ? Q.channel.clamp.a(h ? parseFloat(c) / 100 : parseFloat(c)) : 1
    }, e);
  },
  stringify: (e) => {
    const { r: t, g: r, b: i, a: n } = e;
    return n < 1 ? `rgba(${Q.lang.round(t)}, ${Q.lang.round(r)}, ${Q.lang.round(i)}, ${Q.lang.round(n)})` : `rgb(${Q.lang.round(t)}, ${Q.lang.round(r)}, ${Q.lang.round(i)})`;
  }
}, re = {
  /* VARIABLES */
  format: {
    keyword: Gr,
    hex: nr,
    rgb: Pr,
    rgba: Pr,
    hsl: De,
    hsla: De
  },
  /* API */
  parse: (e) => {
    if (typeof e != "string")
      return e;
    const t = nr.parse(e) || Pr.parse(e) || De.parse(e) || Gr.parse(e);
    if (t)
      return t;
    throw new Error(`Unsupported color format: "${e}"`);
  },
  stringify: (e) => !e.changed && e.color ? e.color : e.type.is(St.HSL) || e.data.r === void 0 ? De.stringify(e) : e.a < 1 || !Number.isInteger(e.r) || !Number.isInteger(e.g) || !Number.isInteger(e.b) ? Pr.stringify(e) : nr.stringify(e)
}, ql = (e, t) => {
  const r = re.parse(e);
  for (const i in t)
    r[i] = Q.channel.clamp[i](t[i]);
  return re.stringify(r);
}, Ur = (e, t, r = 0, i = 1) => {
  if (typeof e != "number")
    return ql(e, { a: t });
  const n = Bn.set({
    r: Q.channel.clamp.r(e),
    g: Q.channel.clamp.g(t),
    b: Q.channel.clamp.b(r),
    a: Q.channel.clamp.a(i)
  });
  return re.stringify(n);
}, fg = (e) => {
  const { r: t, g: r, b: i } = re.parse(e), n = 0.2126 * Q.channel.toLinear(t) + 0.7152 * Q.channel.toLinear(r) + 0.0722 * Q.channel.toLinear(i);
  return Q.lang.round(n);
}, dg = (e) => fg(e) >= 0.5, ui = (e) => !dg(e), Wl = (e, t, r) => {
  const i = re.parse(e), n = i[t], a = Q.channel.clamp[t](n + r);
  return n !== a && (i[t] = a), re.stringify(i);
}, q = (e, t) => Wl(e, "l", t), X = (e, t) => Wl(e, "l", -t), S = (e, t) => {
  const r = re.parse(e), i = {};
  for (const n in t)
    t[n] && (i[n] = r[n] + t[n]);
  return ql(e, i);
}, pg = (e, t, r = 50) => {
  const { r: i, g: n, b: a, a: o } = re.parse(e), { r: s, g: l, b: c, a: h } = re.parse(t), u = r / 100, f = u * 2 - 1, d = o - h, m = ((f * d === -1 ? f : (f + d) / (1 + f * d)) + 1) / 2, x = 1 - m, y = i * m + s * x, b = n * m + l * x, w = a * m + c * x, k = o * u + h * (1 - u);
  return Ur(y, b, w, k);
}, P = (e, t = 100) => {
  const r = re.parse(e);
  return r.r = 255 - r.r, r.g = 255 - r.g, r.b = 255 - r.b, pg(r, e, t);
};
var Hl = /^-{3}\s*[\n\r](.*?)[\n\r]-{3}\s*[\n\r]+/s, Xr = /%{2}{\s*(?:(\w+)\s*:|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, gg = /\s*%%.*\n/gm, or, jl = (or = class extends Error {
  constructor(t) {
    super(t), this.name = "UnknownDiagramError";
  }
}, p(or, "UnknownDiagramError"), or), qe = {}, ds = /* @__PURE__ */ p(function(e, t) {
  e = e.replace(Hl, "").replace(Xr, "").replace(gg, `
`);
  for (const [r, { detector: i }] of Object.entries(qe))
    if (i(e, t))
      return r;
  throw new jl(
    `No diagram type detected matching given configuration for text: ${e}`
  );
}, "detectType"), ya = /* @__PURE__ */ p((...e) => {
  for (const { id: t, detector: r, loader: i } of e)
    Yl(t, r, i);
}, "registerLazyLoadedDiagrams"), Yl = /* @__PURE__ */ p((e, t, r) => {
  qe[e] && F.warn(`Detector with key ${e} already exists. Overwriting.`), qe[e] = { detector: t, loader: r }, F.debug(`Detector with key ${e} added${r ? " with loader" : ""}`);
}, "addDetector"), mg = /* @__PURE__ */ p((e) => qe[e].loader, "getDiagramLoader"), xa = /* @__PURE__ */ p((e, t, { depth: r = 2, clobber: i = !1 } = {}) => {
  const n = { depth: r, clobber: i };
  return Array.isArray(t) && !Array.isArray(e) ? (t.forEach((a) => xa(e, a, n)), e) : Array.isArray(t) && Array.isArray(e) ? (t.forEach((a) => {
    e.includes(a) || e.push(a);
  }), e) : e === void 0 || r <= 0 ? e != null && typeof e == "object" && typeof t == "object" ? Object.assign(e, t) : t : (t !== void 0 && typeof e == "object" && typeof t == "object" && Object.keys(t).forEach((a) => {
    typeof t[a] == "object" && (e[a] === void 0 || typeof e[a] == "object") ? (e[a] === void 0 && (e[a] = Array.isArray(t[a]) ? [] : {}), e[a] = xa(e[a], t[a], { depth: r - 1, clobber: i })) : (i || typeof e[a] != "object" && typeof t[a] != "object") && (e[a] = t[a]);
  }), e);
}, "assignWithDepth"), xt = xa, Ln = "#ffffff", Mn = "#f2f2f2", Ft = /* @__PURE__ */ p((e, t) => t ? S(e, { s: -40, l: 10 }) : S(e, { s: -40, l: -10 }), "mkBorder"), lr, yg = (lr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#fff4dd", this.noteBkgColor = "#fff5ad", this.noteTextColor = "#333", this.THEME_COLOR_LIMIT = 12, this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px";
  }
  updateColors() {
    var r, i, n, a, o, s, l, c, h, u, f, d, g, m, x, y, b, w, k, _, C;
    if (this.primaryTextColor = this.primaryTextColor || (this.darkMode ? "#eee" : "#333"), this.secondaryColor = this.secondaryColor || S(this.primaryColor, { h: -120 }), this.tertiaryColor = this.tertiaryColor || S(this.primaryColor, { h: 180, l: 5 }), this.primaryBorderColor = this.primaryBorderColor || Ft(this.primaryColor, this.darkMode), this.secondaryBorderColor = this.secondaryBorderColor || Ft(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = this.tertiaryBorderColor || Ft(this.tertiaryColor, this.darkMode), this.noteBorderColor = this.noteBorderColor || Ft(this.noteBkgColor, this.darkMode), this.noteBkgColor = this.noteBkgColor || "#fff5ad", this.noteTextColor = this.noteTextColor || "#333", this.secondaryTextColor = this.secondaryTextColor || P(this.secondaryColor), this.tertiaryTextColor = this.tertiaryTextColor || P(this.tertiaryColor), this.lineColor = this.lineColor || P(this.background), this.arrowheadColor = this.arrowheadColor || P(this.background), this.textColor = this.textColor || this.primaryTextColor, this.border2 = this.border2 || this.tertiaryBorderColor, this.nodeBkg = this.nodeBkg || this.primaryColor, this.mainBkg = this.mainBkg || this.primaryColor, this.nodeBorder = this.nodeBorder || this.primaryBorderColor, this.clusterBkg = this.clusterBkg || this.tertiaryColor, this.clusterBorder = this.clusterBorder || this.tertiaryBorderColor, this.defaultLinkColor = this.defaultLinkColor || this.lineColor, this.titleColor = this.titleColor || this.tertiaryTextColor, this.edgeLabelBackground = this.edgeLabelBackground || (this.darkMode ? X(this.secondaryColor, 30) : this.secondaryColor), this.nodeTextColor = this.nodeTextColor || this.primaryTextColor, this.actorBorder = this.actorBorder || this.primaryBorderColor, this.actorBkg = this.actorBkg || this.mainBkg, this.actorTextColor = this.actorTextColor || this.primaryTextColor, this.actorLineColor = this.actorLineColor || this.actorBorder, this.labelBoxBkgColor = this.labelBoxBkgColor || this.actorBkg, this.signalColor = this.signalColor || this.textColor, this.signalTextColor = this.signalTextColor || this.textColor, this.labelBoxBorderColor = this.labelBoxBorderColor || this.actorBorder, this.labelTextColor = this.labelTextColor || this.actorTextColor, this.loopTextColor = this.loopTextColor || this.actorTextColor, this.activationBorderColor = this.activationBorderColor || X(this.secondaryColor, 10), this.activationBkgColor = this.activationBkgColor || this.secondaryColor, this.sequenceNumberColor = this.sequenceNumberColor || P(this.lineColor), this.sectionBkgColor = this.sectionBkgColor || this.tertiaryColor, this.altSectionBkgColor = this.altSectionBkgColor || "white", this.sectionBkgColor = this.sectionBkgColor || this.secondaryColor, this.sectionBkgColor2 = this.sectionBkgColor2 || this.primaryColor, this.excludeBkgColor = this.excludeBkgColor || "#eeeeee", this.taskBorderColor = this.taskBorderColor || this.primaryBorderColor, this.taskBkgColor = this.taskBkgColor || this.primaryColor, this.activeTaskBorderColor = this.activeTaskBorderColor || this.primaryColor, this.activeTaskBkgColor = this.activeTaskBkgColor || q(this.primaryColor, 23), this.gridColor = this.gridColor || "lightgrey", this.doneTaskBkgColor = this.doneTaskBkgColor || "lightgrey", this.doneTaskBorderColor = this.doneTaskBorderColor || "grey", this.critBorderColor = this.critBorderColor || "#ff8888", this.critBkgColor = this.critBkgColor || "red", this.todayLineColor = this.todayLineColor || "red", this.vertLineColor = this.vertLineColor || "navy", this.taskTextColor = this.taskTextColor || this.textColor, this.taskTextOutsideColor = this.taskTextOutsideColor || this.textColor, this.taskTextLightColor = this.taskTextLightColor || this.textColor, this.taskTextColor = this.taskTextColor || this.primaryTextColor, this.taskTextDarkColor = this.taskTextDarkColor || this.textColor, this.taskTextClickableColor = this.taskTextClickableColor || "#003163", this.personBorder = this.personBorder || this.primaryBorderColor, this.personBkg = this.personBkg || this.mainBkg, this.darkMode ? (this.rowOdd = this.rowOdd || X(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || X(this.mainBkg, 10)) : (this.rowOdd = this.rowOdd || q(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || q(this.mainBkg, 5)), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || this.tertiaryColor, this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.specialStateColor = this.lineColor, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || S(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || S(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || S(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || S(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || S(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || S(this.primaryColor, { h: 210, l: 150 }), this.cScale9 = this.cScale9 || S(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || S(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || S(this.primaryColor, { h: 330 }), this.darkMode)
      for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
        this["cScale" + v] = X(this["cScale" + v], 75);
    else
      for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
        this["cScale" + v] = X(this["cScale" + v], 25);
    for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
      this["cScaleInv" + v] = this["cScaleInv" + v] || P(this["cScale" + v]);
    for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
      this.darkMode ? this["cScalePeer" + v] = this["cScalePeer" + v] || q(this["cScale" + v], 10) : this["cScalePeer" + v] = this["cScalePeer" + v] || X(this["cScale" + v], 10);
    this.scaleLabelColor = this.scaleLabelColor || this.labelTextColor;
    for (let v = 0; v < this.THEME_COLOR_LIMIT; v++)
      this["cScaleLabel" + v] = this["cScaleLabel" + v] || this.scaleLabelColor;
    const t = this.darkMode ? -4 : -1;
    for (let v = 0; v < 5; v++)
      this["surface" + v] = this["surface" + v] || S(this.mainBkg, { h: 180, s: -15, l: t * (5 + v * 3) }), this["surfacePeer" + v] = this["surfacePeer" + v] || S(this.mainBkg, { h: 180, s: -15, l: t * (8 + v * 3) });
    this.classText = this.classText || this.textColor, this.fillType0 = this.fillType0 || this.primaryColor, this.fillType1 = this.fillType1 || this.secondaryColor, this.fillType2 = this.fillType2 || S(this.primaryColor, { h: 64 }), this.fillType3 = this.fillType3 || S(this.secondaryColor, { h: 64 }), this.fillType4 = this.fillType4 || S(this.primaryColor, { h: -64 }), this.fillType5 = this.fillType5 || S(this.secondaryColor, { h: -64 }), this.fillType6 = this.fillType6 || S(this.primaryColor, { h: 128 }), this.fillType7 = this.fillType7 || S(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || S(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || S(this.secondaryColor, { l: -10 }), this.pie6 = this.pie6 || S(this.tertiaryColor, { l: -10 }), this.pie7 = this.pie7 || S(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || S(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || S(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || S(this.primaryColor, { h: 60, l: -20 }), this.pie11 = this.pie11 || S(this.primaryColor, { h: -60, l: -20 }), this.pie12 = this.pie12 || S(this.primaryColor, { h: 120, l: -10 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.radar = {
      axisColor: ((r = this.radar) == null ? void 0 : r.axisColor) || this.lineColor,
      axisStrokeWidth: ((i = this.radar) == null ? void 0 : i.axisStrokeWidth) || 2,
      axisLabelFontSize: ((n = this.radar) == null ? void 0 : n.axisLabelFontSize) || 12,
      curveOpacity: ((a = this.radar) == null ? void 0 : a.curveOpacity) || 0.5,
      curveStrokeWidth: ((o = this.radar) == null ? void 0 : o.curveStrokeWidth) || 2,
      graticuleColor: ((s = this.radar) == null ? void 0 : s.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((l = this.radar) == null ? void 0 : l.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((c = this.radar) == null ? void 0 : c.graticuleOpacity) || 0.3,
      legendBoxSize: ((h = this.radar) == null ? void 0 : h.legendBoxSize) || 12,
      legendFontSize: ((u = this.radar) == null ? void 0 : u.legendFontSize) || 12
    }, this.archEdgeColor = this.archEdgeColor || "#777", this.archEdgeArrowColor = this.archEdgeArrowColor || "#777", this.archEdgeWidth = this.archEdgeWidth || "3", this.archGroupBorderColor = this.archGroupBorderColor || "#000", this.archGroupBorderWidth = this.archGroupBorderWidth || "2px", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || S(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || S(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || S(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || S(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || S(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || S(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ui(this.quadrant1Fill) ? q(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((f = this.xyChart) == null ? void 0 : f.backgroundColor) || this.background,
      titleColor: ((d = this.xyChart) == null ? void 0 : d.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((g = this.xyChart) == null ? void 0 : g.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((m = this.xyChart) == null ? void 0 : m.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((x = this.xyChart) == null ? void 0 : x.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((y = this.xyChart) == null ? void 0 : y.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((b = this.xyChart) == null ? void 0 : b.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((w = this.xyChart) == null ? void 0 : w.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((k = this.xyChart) == null ? void 0 : k.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((_ = this.xyChart) == null ? void 0 : _.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((C = this.xyChart) == null ? void 0 : C.plotColorPalette) || "#FFF4DD,#FFD8B1,#FFA07A,#ECEFF1,#D6DBDF,#C3E0A8,#FFB6A4,#FFD74D,#738FA7,#FFFFF0"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? X(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || S(this.primaryColor, { h: -30 }), this.git4 = this.git4 || S(this.primaryColor, { h: -60 }), this.git5 = this.git5 || S(this.primaryColor, { h: -90 }), this.git6 = this.git6 || S(this.primaryColor, { h: 60 }), this.git7 = this.git7 || S(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = q(this.git0, 25), this.git1 = q(this.git1, 25), this.git2 = q(this.git2, 25), this.git3 = q(this.git3, 25), this.git4 = q(this.git4, 25), this.git5 = q(this.git5, 25), this.git6 = q(this.git6, 25), this.git7 = q(this.git7, 25)) : (this.git0 = X(this.git0, 25), this.git1 = X(this.git1, 25), this.git2 = X(this.git2, 25), this.git3 = X(this.git3, 25), this.git4 = X(this.git4, 25), this.git5 = X(this.git5, 25), this.git6 = X(this.git6, 25), this.git7 = X(this.git7, 25)), this.gitInv0 = this.gitInv0 || P(this.git0), this.gitInv1 = this.gitInv1 || P(this.git1), this.gitInv2 = this.gitInv2 || P(this.git2), this.gitInv3 = this.gitInv3 || P(this.git3), this.gitInv4 = this.gitInv4 || P(this.git4), this.gitInv5 = this.gitInv5 || P(this.git5), this.gitInv6 = this.gitInv6 || P(this.git6), this.gitInv7 = this.gitInv7 || P(this.git7), this.branchLabelColor = this.branchLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.gitBranchLabel0 = this.gitBranchLabel0 || this.branchLabelColor, this.gitBranchLabel1 = this.gitBranchLabel1 || this.branchLabelColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.branchLabelColor, this.gitBranchLabel3 = this.gitBranchLabel3 || this.branchLabelColor, this.gitBranchLabel4 = this.gitBranchLabel4 || this.branchLabelColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.branchLabelColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.branchLabelColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ln, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Mn;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(lr, "Theme"), lr), xg = /* @__PURE__ */ p((e) => {
  const t = new yg();
  return t.calculate(e), t;
}, "getThemeVariables"), cr, bg = (cr = class {
  constructor() {
    this.background = "#333", this.primaryColor = "#1f2020", this.secondaryColor = q(this.primaryColor, 16), this.tertiaryColor = S(this.primaryColor, { h: -160 }), this.primaryBorderColor = P(this.background), this.secondaryBorderColor = Ft(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Ft(this.tertiaryColor, this.darkMode), this.primaryTextColor = P(this.primaryColor), this.secondaryTextColor = P(this.secondaryColor), this.tertiaryTextColor = P(this.tertiaryColor), this.lineColor = P(this.background), this.textColor = P(this.background), this.mainBkg = "#1f2020", this.secondBkg = "calculated", this.mainContrastColor = "lightgrey", this.darkTextColor = q(P("#323D47"), 10), this.lineColor = "calculated", this.border1 = "#ccc", this.border2 = Ur(255, 255, 255, 0.25), this.arrowheadColor = "calculated", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "#181818", this.textColor = "#ccc", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#F9FFFE", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "calculated", this.activationBkgColor = "calculated", this.sequenceNumberColor = "black", this.sectionBkgColor = X("#EAE8D9", 30), this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "#EAE8D9", this.excludeBkgColor = X(this.sectionBkgColor, 10), this.taskBorderColor = Ur(255, 255, 255, 70), this.taskBkgColor = "calculated", this.taskTextColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = Ur(255, 255, 255, 50), this.activeTaskBkgColor = "#81B1DB", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "grey", this.critBorderColor = "#E83737", this.critBkgColor = "#E83737", this.taskTextDarkColor = "calculated", this.todayLineColor = "#DB5757", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || q(this.mainBkg, 5) || "#ffffff", this.rowEven = this.rowEven || X(this.mainBkg, 10), this.labelColor = "calculated", this.errorBkgColor = "#a44141", this.errorTextColor = "#ddd";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, d, g, m, x, y, b, w, k, _;
    this.secondBkg = q(this.mainBkg, 16), this.lineColor = this.mainContrastColor, this.arrowheadColor = this.mainContrastColor, this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.edgeLabelBackground = q(this.labelBackground, 25), this.actorBorder = this.border1, this.actorBkg = this.mainBkg, this.actorTextColor = this.mainContrastColor, this.actorLineColor = this.actorBorder, this.signalColor = this.mainContrastColor, this.signalTextColor = this.mainContrastColor, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.mainContrastColor, this.loopTextColor = this.mainContrastColor, this.noteBorderColor = this.secondaryBorderColor, this.noteBkgColor = this.secondBkg, this.noteTextColor = this.secondaryTextColor, this.activationBorderColor = this.border1, this.activationBkgColor = this.secondBkg, this.altSectionBkgColor = this.background, this.taskBkgColor = q(this.mainBkg, 23), this.taskTextColor = this.darkTextColor, this.taskTextLightColor = this.mainContrastColor, this.taskTextOutsideColor = this.taskTextLightColor, this.gridColor = this.mainContrastColor, this.doneTaskBkgColor = this.mainContrastColor, this.taskTextDarkColor = this.darkTextColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#555", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#f4f4f4", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = S(this.primaryColor, { h: 64 }), this.fillType3 = S(this.secondaryColor, { h: 64 }), this.fillType4 = S(this.primaryColor, { h: -64 }), this.fillType5 = S(this.secondaryColor, { h: -64 }), this.fillType6 = S(this.primaryColor, { h: 128 }), this.fillType7 = S(this.secondaryColor, { h: 128 }), this.cScale1 = this.cScale1 || "#0b0000", this.cScale2 = this.cScale2 || "#4d1037", this.cScale3 = this.cScale3 || "#3f5258", this.cScale4 = this.cScale4 || "#4f2f1b", this.cScale5 = this.cScale5 || "#6e0a0a", this.cScale6 = this.cScale6 || "#3b0048", this.cScale7 = this.cScale7 || "#995a01", this.cScale8 = this.cScale8 || "#154706", this.cScale9 = this.cScale9 || "#161722", this.cScale10 = this.cScale10 || "#00296f", this.cScale11 = this.cScale11 || "#01629c", this.cScale12 = this.cScale12 || "#010029", this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || S(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || S(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || S(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || S(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || S(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || S(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || S(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || S(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || S(this.primaryColor, { h: 330 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || P(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScalePeer" + C] = this["cScalePeer" + C] || q(this["cScale" + C], 10);
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || S(this.mainBkg, { h: 30, s: -30, l: -(-10 + C * 4) }), this["surfacePeer" + C] = this["surfacePeer" + C] || S(this.mainBkg, { h: 30, s: -30, l: -(-7 + C * 4) });
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || S(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || S(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || S(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || S(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || S(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || S(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ui(this.quadrant1Fill) ? q(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#3498db,#2ecc71,#e74c3c,#f1c40f,#bdc3c7,#ffffff,#34495e,#9b59b6,#1abc9c,#e67e22"
    }, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.background
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((d = this.radar) == null ? void 0 : d.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((x = this.radar) == null ? void 0 : x.curveStrokeWidth) || 2,
      graticuleColor: ((y = this.radar) == null ? void 0 : y.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((w = this.radar) == null ? void 0 : w.graticuleOpacity) || 0.3,
      legendBoxSize: ((k = this.radar) == null ? void 0 : k.legendBoxSize) || 12,
      legendFontSize: ((_ = this.radar) == null ? void 0 : _.legendFontSize) || 12
    }, this.classText = this.primaryTextColor, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || (this.darkMode ? X(this.secondaryColor, 30) : this.secondaryColor), this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = q(this.secondaryColor, 20), this.git1 = q(this.pie2 || this.secondaryColor, 20), this.git2 = q(this.pie3 || this.tertiaryColor, 20), this.git3 = q(this.pie4 || S(this.primaryColor, { h: -30 }), 20), this.git4 = q(this.pie5 || S(this.primaryColor, { h: -60 }), 20), this.git5 = q(this.pie6 || S(this.primaryColor, { h: -90 }), 10), this.git6 = q(this.pie7 || S(this.primaryColor, { h: 60 }), 10), this.git7 = q(this.pie8 || S(this.primaryColor, { h: 120 }), 20), this.gitInv0 = this.gitInv0 || P(this.git0), this.gitInv1 = this.gitInv1 || P(this.git1), this.gitInv2 = this.gitInv2 || P(this.git2), this.gitInv3 = this.gitInv3 || P(this.git3), this.gitInv4 = this.gitInv4 || P(this.git4), this.gitInv5 = this.gitInv5 || P(this.git5), this.gitInv6 = this.gitInv6 || P(this.git6), this.gitInv7 = this.gitInv7 || P(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || P(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || P(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || q(this.background, 12), this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || q(this.background, 2), this.nodeBorder = this.nodeBorder || "#999";
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(cr, "Theme"), cr), Cg = /* @__PURE__ */ p((e) => {
  const t = new bg();
  return t.calculate(e), t;
}, "getThemeVariables"), hr, wg = (hr = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#ECECFF", this.secondaryColor = S(this.primaryColor, { h: 120 }), this.secondaryColor = "#ffffde", this.tertiaryColor = S(this.primaryColor, { h: -160 }), this.primaryBorderColor = Ft(this.primaryColor, this.darkMode), this.secondaryBorderColor = Ft(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Ft(this.tertiaryColor, this.darkMode), this.primaryTextColor = P(this.primaryColor), this.secondaryTextColor = P(this.secondaryColor), this.tertiaryTextColor = P(this.tertiaryColor), this.lineColor = P(this.background), this.textColor = P(this.background), this.background = "white", this.mainBkg = "#ECECFF", this.secondBkg = "#ffffde", this.lineColor = "#333333", this.border1 = "#9370DB", this.border2 = "#aaaa33", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.labelBackground = "rgba(232,232,232, 0.8)", this.textColor = "#333", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "calculated", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "calculated", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "calculated", this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = this.taskTextDarkColor, this.taskTextClickableColor = "calculated", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBorderColor = "calculated", this.critBkgColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.sectionBkgColor = Ur(102, 102, 255, 0.49), this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#fff400", this.taskBorderColor = "#534fbc", this.taskBkgColor = "#8a90dd", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "#534fbc", this.activeTaskBkgColor = "#bfc7ff", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "navy", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = "calculated", this.rowEven = "calculated", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222", this.updateColors();
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, d, g, m, x, y, b, w, k, _;
    this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || S(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || S(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || S(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || S(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || S(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || S(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || S(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || S(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || S(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || X(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || X(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = X(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || X(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || S(this["cScale" + C], { h: 180 });
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || S(this.mainBkg, { h: 30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || S(this.mainBkg, { h: 30, l: -(7 + C * 5) });
    if (this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor, this.labelTextColor !== "calculated") {
      this.cScaleLabel0 = this.cScaleLabel0 || P(this.labelTextColor), this.cScaleLabel3 = this.cScaleLabel3 || P(this.labelTextColor);
      for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
        this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.labelTextColor;
    }
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.textColor, this.edgeLabelBackground = this.labelBackground, this.actorBorder = q(this.border1, 23), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.signalColor = this.textColor, this.signalTextColor = this.textColor, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || q(this.primaryColor, 75) || "#ffffff", this.rowEven = this.rowEven || q(this.primaryColor, 1), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.nodeBorder, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = S(this.primaryColor, { h: 64 }), this.fillType3 = S(this.secondaryColor, { h: 64 }), this.fillType4 = S(this.primaryColor, { h: -64 }), this.fillType5 = S(this.secondaryColor, { h: -64 }), this.fillType6 = S(this.primaryColor, { h: 128 }), this.fillType7 = S(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || S(this.tertiaryColor, { l: -40 }), this.pie4 = this.pie4 || S(this.primaryColor, { l: -10 }), this.pie5 = this.pie5 || S(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || S(this.tertiaryColor, { l: -20 }), this.pie7 = this.pie7 || S(this.primaryColor, { h: 60, l: -20 }), this.pie8 = this.pie8 || S(this.primaryColor, { h: -60, l: -40 }), this.pie9 = this.pie9 || S(this.primaryColor, { h: 120, l: -40 }), this.pie10 = this.pie10 || S(this.primaryColor, { h: 60, l: -40 }), this.pie11 = this.pie11 || S(this.primaryColor, { h: -90, l: -40 }), this.pie12 = this.pie12 || S(this.primaryColor, { h: 120, l: -30 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || S(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || S(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || S(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || S(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || S(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || S(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ui(this.quadrant1Fill) ? q(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((d = this.xyChart) == null ? void 0 : d.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((y = this.xyChart) == null ? void 0 : y.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((w = this.xyChart) == null ? void 0 : w.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((k = this.xyChart) == null ? void 0 : k.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((_ = this.xyChart) == null ? void 0 : _.plotColorPalette) || "#ECECFF,#8493A6,#FFC3A0,#DCDDE1,#B8E994,#D1A36F,#C3CDE6,#FFB6C1,#496078,#F8F3E3"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.labelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || S(this.primaryColor, { h: -30 }), this.git4 = this.git4 || S(this.primaryColor, { h: -60 }), this.git5 = this.git5 || S(this.primaryColor, { h: -90 }), this.git6 = this.git6 || S(this.primaryColor, { h: 60 }), this.git7 = this.git7 || S(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = q(this.git0, 25), this.git1 = q(this.git1, 25), this.git2 = q(this.git2, 25), this.git3 = q(this.git3, 25), this.git4 = q(this.git4, 25), this.git5 = q(this.git5, 25), this.git6 = q(this.git6, 25), this.git7 = q(this.git7, 25)) : (this.git0 = X(this.git0, 25), this.git1 = X(this.git1, 25), this.git2 = X(this.git2, 25), this.git3 = X(this.git3, 25), this.git4 = X(this.git4, 25), this.git5 = X(this.git5, 25), this.git6 = X(this.git6, 25), this.git7 = X(this.git7, 25)), this.gitInv0 = this.gitInv0 || X(P(this.git0), 25), this.gitInv1 = this.gitInv1 || P(this.git1), this.gitInv2 = this.gitInv2 || P(this.git2), this.gitInv3 = this.gitInv3 || P(this.git3), this.gitInv4 = this.gitInv4 || P(this.git4), this.gitInv5 = this.gitInv5 || P(this.git5), this.gitInv6 = this.gitInv6 || P(this.git6), this.gitInv7 = this.gitInv7 || P(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || P(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || P(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ln, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Mn;
  }
  calculate(t) {
    if (Object.keys(this).forEach((i) => {
      this[i] === "calculated" && (this[i] = void 0);
    }), typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(hr, "Theme"), hr), _g = /* @__PURE__ */ p((e) => {
  const t = new wg();
  return t.calculate(e), t;
}, "getThemeVariables"), ur, vg = (ur = class {
  constructor() {
    this.background = "#f4f4f4", this.primaryColor = "#cde498", this.secondaryColor = "#cdffb2", this.background = "white", this.mainBkg = "#cde498", this.secondBkg = "#cdffb2", this.lineColor = "green", this.border1 = "#13540c", this.border2 = "#6eaa49", this.arrowheadColor = "green", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.tertiaryColor = q("#cde498", 10), this.primaryBorderColor = Ft(this.primaryColor, this.darkMode), this.secondaryBorderColor = Ft(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Ft(this.tertiaryColor, this.darkMode), this.primaryTextColor = P(this.primaryColor), this.secondaryTextColor = P(this.secondaryColor), this.tertiaryTextColor = P(this.primaryColor), this.lineColor = P(this.background), this.textColor = P(this.background), this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "#333", this.edgeLabelBackground = "#e8e8e8", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "black", this.actorLineColor = "calculated", this.signalColor = "#333", this.signalTextColor = "#333", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "#326932", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "#fff5ad", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "#6eaa49", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "#6eaa49", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "#487e3a", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "black", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "lightgrey", this.doneTaskBkgColor = "lightgrey", this.doneTaskBorderColor = "grey", this.critBorderColor = "#ff8888", this.critBkgColor = "red", this.todayLineColor = "red", this.vertLineColor = "#00BFFF", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, d, g, m, x, y, b, w, k, _;
    this.actorBorder = X(this.mainBkg, 20), this.actorBkg = this.mainBkg, this.labelBoxBkgColor = this.actorBkg, this.labelTextColor = this.actorTextColor, this.loopTextColor = this.actorTextColor, this.noteBorderColor = this.border2, this.noteTextColor = this.actorTextColor, this.actorLineColor = this.actorBorder, this.cScale0 = this.cScale0 || this.primaryColor, this.cScale1 = this.cScale1 || this.secondaryColor, this.cScale2 = this.cScale2 || this.tertiaryColor, this.cScale3 = this.cScale3 || S(this.primaryColor, { h: 30 }), this.cScale4 = this.cScale4 || S(this.primaryColor, { h: 60 }), this.cScale5 = this.cScale5 || S(this.primaryColor, { h: 90 }), this.cScale6 = this.cScale6 || S(this.primaryColor, { h: 120 }), this.cScale7 = this.cScale7 || S(this.primaryColor, { h: 150 }), this.cScale8 = this.cScale8 || S(this.primaryColor, { h: 210 }), this.cScale9 = this.cScale9 || S(this.primaryColor, { h: 270 }), this.cScale10 = this.cScale10 || S(this.primaryColor, { h: 300 }), this.cScale11 = this.cScale11 || S(this.primaryColor, { h: 330 }), this.cScalePeer1 = this.cScalePeer1 || X(this.secondaryColor, 45), this.cScalePeer2 = this.cScalePeer2 || X(this.tertiaryColor, 40);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScale" + C] = X(this["cScale" + C], 10), this["cScalePeer" + C] = this["cScalePeer" + C] || X(this["cScale" + C], 25);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || S(this["cScale" + C], { h: 180 });
    this.scaleLabelColor = this.scaleLabelColor !== "calculated" && this.scaleLabelColor ? this.scaleLabelColor : this.labelTextColor;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || S(this.mainBkg, { h: 30, s: -30, l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || S(this.mainBkg, { h: 30, s: -30, l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.taskBorderColor = this.border1, this.taskTextColor = this.taskTextLightColor, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.rowOdd = this.rowOdd || q(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || q(this.mainBkg, 20), this.transitionColor = this.transitionColor || this.lineColor, this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f0f0f0", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.compositeBorder = this.compositeBorder || this.nodeBorder, this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = this.lineColor, this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.transitionColor = this.transitionColor || this.lineColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = S(this.primaryColor, { h: 64 }), this.fillType3 = S(this.secondaryColor, { h: 64 }), this.fillType4 = S(this.primaryColor, { h: -64 }), this.fillType5 = S(this.secondaryColor, { h: -64 }), this.fillType6 = S(this.primaryColor, { h: 128 }), this.fillType7 = S(this.secondaryColor, { h: 128 }), this.pie1 = this.pie1 || this.primaryColor, this.pie2 = this.pie2 || this.secondaryColor, this.pie3 = this.pie3 || this.tertiaryColor, this.pie4 = this.pie4 || S(this.primaryColor, { l: -30 }), this.pie5 = this.pie5 || S(this.secondaryColor, { l: -30 }), this.pie6 = this.pie6 || S(this.tertiaryColor, { h: 40, l: -40 }), this.pie7 = this.pie7 || S(this.primaryColor, { h: 60, l: -10 }), this.pie8 = this.pie8 || S(this.primaryColor, { h: -60, l: -10 }), this.pie9 = this.pie9 || S(this.primaryColor, { h: 120, l: 0 }), this.pie10 = this.pie10 || S(this.primaryColor, { h: 60, l: -50 }), this.pie11 = this.pie11 || S(this.primaryColor, { h: -60, l: -50 }), this.pie12 = this.pie12 || S(this.primaryColor, { h: 120, l: -50 }), this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || S(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || S(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || S(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || S(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || S(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || S(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ui(this.quadrant1Fill) ? q(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.packet = {
      startByteColor: this.primaryTextColor,
      endByteColor: this.primaryTextColor,
      labelColor: this.primaryTextColor,
      titleColor: this.primaryTextColor,
      blockStrokeColor: this.primaryTextColor,
      blockFillColor: this.mainBkg
    }, this.radar = {
      axisColor: ((t = this.radar) == null ? void 0 : t.axisColor) || this.lineColor,
      axisStrokeWidth: ((r = this.radar) == null ? void 0 : r.axisStrokeWidth) || 2,
      axisLabelFontSize: ((i = this.radar) == null ? void 0 : i.axisLabelFontSize) || 12,
      curveOpacity: ((n = this.radar) == null ? void 0 : n.curveOpacity) || 0.5,
      curveStrokeWidth: ((a = this.radar) == null ? void 0 : a.curveStrokeWidth) || 2,
      graticuleColor: ((o = this.radar) == null ? void 0 : o.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((s = this.radar) == null ? void 0 : s.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((l = this.radar) == null ? void 0 : l.graticuleOpacity) || 0.3,
      legendBoxSize: ((c = this.radar) == null ? void 0 : c.legendBoxSize) || 12,
      legendFontSize: ((h = this.radar) == null ? void 0 : h.legendFontSize) || 12
    }, this.xyChart = {
      backgroundColor: ((u = this.xyChart) == null ? void 0 : u.backgroundColor) || this.background,
      titleColor: ((f = this.xyChart) == null ? void 0 : f.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((d = this.xyChart) == null ? void 0 : d.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((g = this.xyChart) == null ? void 0 : g.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((m = this.xyChart) == null ? void 0 : m.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((x = this.xyChart) == null ? void 0 : x.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((y = this.xyChart) == null ? void 0 : y.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((b = this.xyChart) == null ? void 0 : b.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((w = this.xyChart) == null ? void 0 : w.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((k = this.xyChart) == null ? void 0 : k.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((_ = this.xyChart) == null ? void 0 : _.plotColorPalette) || "#CDE498,#FF6B6B,#A0D2DB,#D7BDE2,#F0F0F0,#FFC3A0,#7FD8BE,#FF9A8B,#FAF3E0,#FFF176"
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = this.git0 || this.primaryColor, this.git1 = this.git1 || this.secondaryColor, this.git2 = this.git2 || this.tertiaryColor, this.git3 = this.git3 || S(this.primaryColor, { h: -30 }), this.git4 = this.git4 || S(this.primaryColor, { h: -60 }), this.git5 = this.git5 || S(this.primaryColor, { h: -90 }), this.git6 = this.git6 || S(this.primaryColor, { h: 60 }), this.git7 = this.git7 || S(this.primaryColor, { h: 120 }), this.darkMode ? (this.git0 = q(this.git0, 25), this.git1 = q(this.git1, 25), this.git2 = q(this.git2, 25), this.git3 = q(this.git3, 25), this.git4 = q(this.git4, 25), this.git5 = q(this.git5, 25), this.git6 = q(this.git6, 25), this.git7 = q(this.git7, 25)) : (this.git0 = X(this.git0, 25), this.git1 = X(this.git1, 25), this.git2 = X(this.git2, 25), this.git3 = X(this.git3, 25), this.git4 = X(this.git4, 25), this.git5 = X(this.git5, 25), this.git6 = X(this.git6, 25), this.git7 = X(this.git7, 25)), this.gitInv0 = this.gitInv0 || P(this.git0), this.gitInv1 = this.gitInv1 || P(this.git1), this.gitInv2 = this.gitInv2 || P(this.git2), this.gitInv3 = this.gitInv3 || P(this.git3), this.gitInv4 = this.gitInv4 || P(this.git4), this.gitInv5 = this.gitInv5 || P(this.git5), this.gitInv6 = this.gitInv6 || P(this.git6), this.gitInv7 = this.gitInv7 || P(this.git7), this.gitBranchLabel0 = this.gitBranchLabel0 || P(this.labelTextColor), this.gitBranchLabel1 = this.gitBranchLabel1 || this.labelTextColor, this.gitBranchLabel2 = this.gitBranchLabel2 || this.labelTextColor, this.gitBranchLabel3 = this.gitBranchLabel3 || P(this.labelTextColor), this.gitBranchLabel4 = this.gitBranchLabel4 || this.labelTextColor, this.gitBranchLabel5 = this.gitBranchLabel5 || this.labelTextColor, this.gitBranchLabel6 = this.gitBranchLabel6 || this.labelTextColor, this.gitBranchLabel7 = this.gitBranchLabel7 || this.labelTextColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ln, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Mn;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(ur, "Theme"), ur), kg = /* @__PURE__ */ p((e) => {
  const t = new vg();
  return t.calculate(e), t;
}, "getThemeVariables"), fr, Sg = (fr = class {
  constructor() {
    this.primaryColor = "#eee", this.contrast = "#707070", this.secondaryColor = q(this.contrast, 55), this.background = "#ffffff", this.tertiaryColor = S(this.primaryColor, { h: -160 }), this.primaryBorderColor = Ft(this.primaryColor, this.darkMode), this.secondaryBorderColor = Ft(this.secondaryColor, this.darkMode), this.tertiaryBorderColor = Ft(this.tertiaryColor, this.darkMode), this.primaryTextColor = P(this.primaryColor), this.secondaryTextColor = P(this.secondaryColor), this.tertiaryTextColor = P(this.tertiaryColor), this.lineColor = P(this.background), this.textColor = P(this.background), this.mainBkg = "#eee", this.secondBkg = "calculated", this.lineColor = "#666", this.border1 = "#999", this.border2 = "calculated", this.note = "#ffa", this.text = "#333", this.critical = "#d42", this.done = "#bbb", this.arrowheadColor = "#333333", this.fontFamily = '"trebuchet ms", verdana, arial, sans-serif', this.fontSize = "16px", this.THEME_COLOR_LIMIT = 12, this.nodeBkg = "calculated", this.nodeBorder = "calculated", this.clusterBkg = "calculated", this.clusterBorder = "calculated", this.defaultLinkColor = "calculated", this.titleColor = "calculated", this.edgeLabelBackground = "white", this.actorBorder = "calculated", this.actorBkg = "calculated", this.actorTextColor = "calculated", this.actorLineColor = this.actorBorder, this.signalColor = "calculated", this.signalTextColor = "calculated", this.labelBoxBkgColor = "calculated", this.labelBoxBorderColor = "calculated", this.labelTextColor = "calculated", this.loopTextColor = "calculated", this.noteBorderColor = "calculated", this.noteBkgColor = "calculated", this.noteTextColor = "calculated", this.activationBorderColor = "#666", this.activationBkgColor = "#f4f4f4", this.sequenceNumberColor = "white", this.sectionBkgColor = "calculated", this.altSectionBkgColor = "white", this.sectionBkgColor2 = "calculated", this.excludeBkgColor = "#eeeeee", this.taskBorderColor = "calculated", this.taskBkgColor = "calculated", this.taskTextLightColor = "white", this.taskTextColor = "calculated", this.taskTextDarkColor = "calculated", this.taskTextOutsideColor = "calculated", this.taskTextClickableColor = "#003163", this.activeTaskBorderColor = "calculated", this.activeTaskBkgColor = "calculated", this.gridColor = "calculated", this.doneTaskBkgColor = "calculated", this.doneTaskBorderColor = "calculated", this.critBkgColor = "calculated", this.critBorderColor = "calculated", this.todayLineColor = "calculated", this.vertLineColor = "calculated", this.personBorder = this.primaryBorderColor, this.personBkg = this.mainBkg, this.archEdgeColor = "calculated", this.archEdgeArrowColor = "calculated", this.archEdgeWidth = "3", this.archGroupBorderColor = this.primaryBorderColor, this.archGroupBorderWidth = "2px", this.rowOdd = this.rowOdd || q(this.mainBkg, 75) || "#ffffff", this.rowEven = this.rowEven || "#f4f4f4", this.labelColor = "black", this.errorBkgColor = "#552222", this.errorTextColor = "#552222";
  }
  updateColors() {
    var t, r, i, n, a, o, s, l, c, h, u, f, d, g, m, x, y, b, w, k, _;
    this.secondBkg = q(this.contrast, 55), this.border2 = this.contrast, this.actorBorder = q(this.border1, 23), this.actorBkg = this.mainBkg, this.actorTextColor = this.text, this.actorLineColor = this.actorBorder, this.signalColor = this.text, this.signalTextColor = this.text, this.labelBoxBkgColor = this.actorBkg, this.labelBoxBorderColor = this.actorBorder, this.labelTextColor = this.text, this.loopTextColor = this.text, this.noteBorderColor = "#999", this.noteBkgColor = "#666", this.noteTextColor = "#fff", this.cScale0 = this.cScale0 || "#555", this.cScale1 = this.cScale1 || "#F4F4F4", this.cScale2 = this.cScale2 || "#555", this.cScale3 = this.cScale3 || "#BBB", this.cScale4 = this.cScale4 || "#777", this.cScale5 = this.cScale5 || "#999", this.cScale6 = this.cScale6 || "#DDD", this.cScale7 = this.cScale7 || "#FFF", this.cScale8 = this.cScale8 || "#DDD", this.cScale9 = this.cScale9 || "#BBB", this.cScale10 = this.cScale10 || "#999", this.cScale11 = this.cScale11 || "#777";
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleInv" + C] = this["cScaleInv" + C] || P(this["cScale" + C]);
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this.darkMode ? this["cScalePeer" + C] = this["cScalePeer" + C] || q(this["cScale" + C], 10) : this["cScalePeer" + C] = this["cScalePeer" + C] || X(this["cScale" + C], 10);
    this.scaleLabelColor = this.scaleLabelColor || (this.darkMode ? "black" : this.labelTextColor), this.cScaleLabel0 = this.cScaleLabel0 || this.cScale1, this.cScaleLabel2 = this.cScaleLabel2 || this.cScale1;
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["cScaleLabel" + C] = this["cScaleLabel" + C] || this.scaleLabelColor;
    for (let C = 0; C < 5; C++)
      this["surface" + C] = this["surface" + C] || S(this.mainBkg, { l: -(5 + C * 5) }), this["surfacePeer" + C] = this["surfacePeer" + C] || S(this.mainBkg, { l: -(8 + C * 5) });
    this.nodeBkg = this.mainBkg, this.nodeBorder = this.border1, this.clusterBkg = this.secondBkg, this.clusterBorder = this.border2, this.defaultLinkColor = this.lineColor, this.titleColor = this.text, this.sectionBkgColor = q(this.contrast, 30), this.sectionBkgColor2 = q(this.contrast, 30), this.taskBorderColor = X(this.contrast, 10), this.taskBkgColor = this.contrast, this.taskTextColor = this.taskTextLightColor, this.taskTextDarkColor = this.text, this.taskTextOutsideColor = this.taskTextDarkColor, this.activeTaskBorderColor = this.taskBorderColor, this.activeTaskBkgColor = this.mainBkg, this.gridColor = q(this.border1, 30), this.doneTaskBkgColor = this.done, this.doneTaskBorderColor = this.lineColor, this.critBkgColor = this.critical, this.critBorderColor = X(this.critBkgColor, 10), this.todayLineColor = this.critBkgColor, this.vertLineColor = this.critBkgColor, this.archEdgeColor = this.lineColor, this.archEdgeArrowColor = this.lineColor, this.transitionColor = this.transitionColor || "#000", this.transitionLabelColor = this.transitionLabelColor || this.textColor, this.stateLabelColor = this.stateLabelColor || this.stateBkg || this.primaryTextColor, this.stateBkg = this.stateBkg || this.mainBkg, this.labelBackgroundColor = this.labelBackgroundColor || this.stateBkg, this.compositeBackground = this.compositeBackground || this.background || this.tertiaryColor, this.altBackground = this.altBackground || "#f4f4f4", this.compositeTitleBackground = this.compositeTitleBackground || this.mainBkg, this.stateBorder = this.stateBorder || "#000", this.innerEndBackground = this.primaryBorderColor, this.specialStateColor = "#222", this.errorBkgColor = this.errorBkgColor || this.tertiaryColor, this.errorTextColor = this.errorTextColor || this.tertiaryTextColor, this.classText = this.primaryTextColor, this.fillType0 = this.primaryColor, this.fillType1 = this.secondaryColor, this.fillType2 = S(this.primaryColor, { h: 64 }), this.fillType3 = S(this.secondaryColor, { h: 64 }), this.fillType4 = S(this.primaryColor, { h: -64 }), this.fillType5 = S(this.secondaryColor, { h: -64 }), this.fillType6 = S(this.primaryColor, { h: 128 }), this.fillType7 = S(this.secondaryColor, { h: 128 });
    for (let C = 0; C < this.THEME_COLOR_LIMIT; C++)
      this["pie" + C] = this["cScale" + C];
    this.pie12 = this.pie0, this.pieTitleTextSize = this.pieTitleTextSize || "25px", this.pieTitleTextColor = this.pieTitleTextColor || this.taskTextDarkColor, this.pieSectionTextSize = this.pieSectionTextSize || "17px", this.pieSectionTextColor = this.pieSectionTextColor || this.textColor, this.pieLegendTextSize = this.pieLegendTextSize || "17px", this.pieLegendTextColor = this.pieLegendTextColor || this.taskTextDarkColor, this.pieStrokeColor = this.pieStrokeColor || "black", this.pieStrokeWidth = this.pieStrokeWidth || "2px", this.pieOuterStrokeWidth = this.pieOuterStrokeWidth || "2px", this.pieOuterStrokeColor = this.pieOuterStrokeColor || "black", this.pieOpacity = this.pieOpacity || "0.7", this.quadrant1Fill = this.quadrant1Fill || this.primaryColor, this.quadrant2Fill = this.quadrant2Fill || S(this.primaryColor, { r: 5, g: 5, b: 5 }), this.quadrant3Fill = this.quadrant3Fill || S(this.primaryColor, { r: 10, g: 10, b: 10 }), this.quadrant4Fill = this.quadrant4Fill || S(this.primaryColor, { r: 15, g: 15, b: 15 }), this.quadrant1TextFill = this.quadrant1TextFill || this.primaryTextColor, this.quadrant2TextFill = this.quadrant2TextFill || S(this.primaryTextColor, { r: -5, g: -5, b: -5 }), this.quadrant3TextFill = this.quadrant3TextFill || S(this.primaryTextColor, { r: -10, g: -10, b: -10 }), this.quadrant4TextFill = this.quadrant4TextFill || S(this.primaryTextColor, { r: -15, g: -15, b: -15 }), this.quadrantPointFill = this.quadrantPointFill || ui(this.quadrant1Fill) ? q(this.quadrant1Fill) : X(this.quadrant1Fill), this.quadrantPointTextFill = this.quadrantPointTextFill || this.primaryTextColor, this.quadrantXAxisTextFill = this.quadrantXAxisTextFill || this.primaryTextColor, this.quadrantYAxisTextFill = this.quadrantYAxisTextFill || this.primaryTextColor, this.quadrantInternalBorderStrokeFill = this.quadrantInternalBorderStrokeFill || this.primaryBorderColor, this.quadrantExternalBorderStrokeFill = this.quadrantExternalBorderStrokeFill || this.primaryBorderColor, this.quadrantTitleFill = this.quadrantTitleFill || this.primaryTextColor, this.xyChart = {
      backgroundColor: ((t = this.xyChart) == null ? void 0 : t.backgroundColor) || this.background,
      titleColor: ((r = this.xyChart) == null ? void 0 : r.titleColor) || this.primaryTextColor,
      xAxisTitleColor: ((i = this.xyChart) == null ? void 0 : i.xAxisTitleColor) || this.primaryTextColor,
      xAxisLabelColor: ((n = this.xyChart) == null ? void 0 : n.xAxisLabelColor) || this.primaryTextColor,
      xAxisTickColor: ((a = this.xyChart) == null ? void 0 : a.xAxisTickColor) || this.primaryTextColor,
      xAxisLineColor: ((o = this.xyChart) == null ? void 0 : o.xAxisLineColor) || this.primaryTextColor,
      yAxisTitleColor: ((s = this.xyChart) == null ? void 0 : s.yAxisTitleColor) || this.primaryTextColor,
      yAxisLabelColor: ((l = this.xyChart) == null ? void 0 : l.yAxisLabelColor) || this.primaryTextColor,
      yAxisTickColor: ((c = this.xyChart) == null ? void 0 : c.yAxisTickColor) || this.primaryTextColor,
      yAxisLineColor: ((h = this.xyChart) == null ? void 0 : h.yAxisLineColor) || this.primaryTextColor,
      plotColorPalette: ((u = this.xyChart) == null ? void 0 : u.plotColorPalette) || "#EEE,#6BB8E4,#8ACB88,#C7ACD6,#E8DCC2,#FFB2A8,#FFF380,#7E8D91,#FFD8B1,#FAF3E0"
    }, this.radar = {
      axisColor: ((f = this.radar) == null ? void 0 : f.axisColor) || this.lineColor,
      axisStrokeWidth: ((d = this.radar) == null ? void 0 : d.axisStrokeWidth) || 2,
      axisLabelFontSize: ((g = this.radar) == null ? void 0 : g.axisLabelFontSize) || 12,
      curveOpacity: ((m = this.radar) == null ? void 0 : m.curveOpacity) || 0.5,
      curveStrokeWidth: ((x = this.radar) == null ? void 0 : x.curveStrokeWidth) || 2,
      graticuleColor: ((y = this.radar) == null ? void 0 : y.graticuleColor) || "#DEDEDE",
      graticuleStrokeWidth: ((b = this.radar) == null ? void 0 : b.graticuleStrokeWidth) || 1,
      graticuleOpacity: ((w = this.radar) == null ? void 0 : w.graticuleOpacity) || 0.3,
      legendBoxSize: ((k = this.radar) == null ? void 0 : k.legendBoxSize) || 12,
      legendFontSize: ((_ = this.radar) == null ? void 0 : _.legendFontSize) || 12
    }, this.requirementBackground = this.requirementBackground || this.primaryColor, this.requirementBorderColor = this.requirementBorderColor || this.primaryBorderColor, this.requirementBorderSize = this.requirementBorderSize || "1", this.requirementTextColor = this.requirementTextColor || this.primaryTextColor, this.relationColor = this.relationColor || this.lineColor, this.relationLabelBackground = this.relationLabelBackground || this.edgeLabelBackground, this.relationLabelColor = this.relationLabelColor || this.actorTextColor, this.git0 = X(this.pie1, 25) || this.primaryColor, this.git1 = this.pie2 || this.secondaryColor, this.git2 = this.pie3 || this.tertiaryColor, this.git3 = this.pie4 || S(this.primaryColor, { h: -30 }), this.git4 = this.pie5 || S(this.primaryColor, { h: -60 }), this.git5 = this.pie6 || S(this.primaryColor, { h: -90 }), this.git6 = this.pie7 || S(this.primaryColor, { h: 60 }), this.git7 = this.pie8 || S(this.primaryColor, { h: 120 }), this.gitInv0 = this.gitInv0 || P(this.git0), this.gitInv1 = this.gitInv1 || P(this.git1), this.gitInv2 = this.gitInv2 || P(this.git2), this.gitInv3 = this.gitInv3 || P(this.git3), this.gitInv4 = this.gitInv4 || P(this.git4), this.gitInv5 = this.gitInv5 || P(this.git5), this.gitInv6 = this.gitInv6 || P(this.git6), this.gitInv7 = this.gitInv7 || P(this.git7), this.branchLabelColor = this.branchLabelColor || this.labelTextColor, this.gitBranchLabel0 = this.branchLabelColor, this.gitBranchLabel1 = "white", this.gitBranchLabel2 = this.branchLabelColor, this.gitBranchLabel3 = "white", this.gitBranchLabel4 = this.branchLabelColor, this.gitBranchLabel5 = this.branchLabelColor, this.gitBranchLabel6 = this.branchLabelColor, this.gitBranchLabel7 = this.branchLabelColor, this.tagLabelColor = this.tagLabelColor || this.primaryTextColor, this.tagLabelBackground = this.tagLabelBackground || this.primaryColor, this.tagLabelBorder = this.tagBorder || this.primaryBorderColor, this.tagLabelFontSize = this.tagLabelFontSize || "10px", this.commitLabelColor = this.commitLabelColor || this.secondaryTextColor, this.commitLabelBackground = this.commitLabelBackground || this.secondaryColor, this.commitLabelFontSize = this.commitLabelFontSize || "10px", this.attributeBackgroundColorOdd = this.attributeBackgroundColorOdd || Ln, this.attributeBackgroundColorEven = this.attributeBackgroundColorEven || Mn;
  }
  calculate(t) {
    if (typeof t != "object") {
      this.updateColors();
      return;
    }
    const r = Object.keys(t);
    r.forEach((i) => {
      this[i] = t[i];
    }), this.updateColors(), r.forEach((i) => {
      this[i] = t[i];
    });
  }
}, p(fr, "Theme"), fr), Tg = /* @__PURE__ */ p((e) => {
  const t = new Sg();
  return t.calculate(e), t;
}, "getThemeVariables"), fe = {
  base: {
    getThemeVariables: xg
  },
  dark: {
    getThemeVariables: Cg
  },
  default: {
    getThemeVariables: _g
  },
  forest: {
    getThemeVariables: kg
  },
  neutral: {
    getThemeVariables: Tg
  }
}, Kt = {
  flowchart: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    subGraphTitleMargin: {
      top: 0,
      bottom: 0
    },
    diagramPadding: 8,
    htmlLabels: !0,
    nodeSpacing: 50,
    rankSpacing: 50,
    curve: "basis",
    padding: 15,
    defaultRenderer: "dagre-wrapper",
    wrappingWidth: 200,
    inheritDir: !1
  },
  sequence: {
    useMaxWidth: !0,
    hideUnusedParticipants: !1,
    activationWidth: 10,
    diagramMarginX: 50,
    diagramMarginY: 10,
    actorMargin: 50,
    width: 150,
    height: 65,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    mirrorActors: !0,
    forceMenus: !1,
    bottomMarginAdj: 1,
    rightAngles: !1,
    showSequenceNumbers: !1,
    actorFontSize: 14,
    actorFontFamily: '"Open Sans", sans-serif',
    actorFontWeight: 400,
    noteFontSize: 14,
    noteFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    noteFontWeight: 400,
    noteAlign: "center",
    messageFontSize: 16,
    messageFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    messageFontWeight: 400,
    wrap: !1,
    wrapPadding: 10,
    labelBoxWidth: 50,
    labelBoxHeight: 20
  },
  gantt: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    barHeight: 20,
    barGap: 4,
    topPadding: 50,
    rightPadding: 75,
    leftPadding: 75,
    gridLineStartPadding: 35,
    fontSize: 11,
    sectionFontSize: 11,
    numberSectionStyles: 4,
    axisFormat: "%Y-%m-%d",
    topAxis: !1,
    displayMode: "",
    weekday: "sunday"
  },
  journey: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    maxLabelWidth: 360,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    titleColor: "",
    titleFontFamily: '"trebuchet ms", verdana, arial, sans-serif',
    titleFontSize: "4ex"
  },
  class: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    arrowMarkerAbsolute: !1,
    dividerMargin: 10,
    padding: 5,
    textHeight: 10,
    defaultRenderer: "dagre-wrapper",
    htmlLabels: !1,
    hideEmptyMembersBox: !1
  },
  state: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    dividerMargin: 10,
    sizeUnit: 5,
    padding: 8,
    textHeight: 10,
    titleShift: -15,
    noteMargin: 10,
    forkWidth: 70,
    forkHeight: 7,
    miniPadding: 2,
    fontSizeFactor: 5.02,
    fontSize: 24,
    labelHeight: 16,
    edgeLengthFactor: "20",
    compositTitleSize: 35,
    radius: 5,
    defaultRenderer: "dagre-wrapper"
  },
  er: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 20,
    layoutDirection: "TB",
    minEntityWidth: 100,
    minEntityHeight: 75,
    entityPadding: 15,
    nodeSpacing: 140,
    rankSpacing: 80,
    stroke: "gray",
    fill: "honeydew",
    fontSize: 12
  },
  pie: {
    useMaxWidth: !0,
    textPosition: 0.75
  },
  quadrantChart: {
    useMaxWidth: !0,
    chartWidth: 500,
    chartHeight: 500,
    titleFontSize: 20,
    titlePadding: 10,
    quadrantPadding: 5,
    xAxisLabelPadding: 5,
    yAxisLabelPadding: 5,
    xAxisLabelFontSize: 16,
    yAxisLabelFontSize: 16,
    quadrantLabelFontSize: 16,
    quadrantTextTopPadding: 5,
    pointTextPadding: 5,
    pointLabelFontSize: 12,
    pointRadius: 5,
    xAxisPosition: "top",
    yAxisPosition: "left",
    quadrantInternalBorderStrokeWidth: 1,
    quadrantExternalBorderStrokeWidth: 2
  },
  xyChart: {
    useMaxWidth: !0,
    width: 700,
    height: 500,
    titleFontSize: 20,
    titlePadding: 10,
    showDataLabel: !1,
    showTitle: !0,
    xAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    yAxis: {
      $ref: "#/$defs/XYChartAxisConfig",
      showLabel: !0,
      labelFontSize: 14,
      labelPadding: 5,
      showTitle: !0,
      titleFontSize: 16,
      titlePadding: 5,
      showTick: !0,
      tickLength: 5,
      tickWidth: 2,
      showAxisLine: !0,
      axisLineWidth: 2
    },
    chartOrientation: "vertical",
    plotReservedSpacePercent: 50
  },
  requirement: {
    useMaxWidth: !0,
    rect_fill: "#f9f9f9",
    text_color: "#333",
    rect_border_size: "0.5px",
    rect_border_color: "#bbb",
    rect_min_width: 200,
    rect_min_height: 200,
    fontSize: 14,
    rect_padding: 10,
    line_height: 20
  },
  mindmap: {
    useMaxWidth: !0,
    padding: 10,
    maxNodeWidth: 200,
    layoutAlgorithm: "cose-bilkent"
  },
  kanban: {
    useMaxWidth: !0,
    padding: 8,
    sectionWidth: 200,
    ticketBaseUrl: ""
  },
  timeline: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    leftMargin: 150,
    width: 150,
    height: 50,
    boxMargin: 10,
    boxTextMargin: 5,
    noteMargin: 10,
    messageMargin: 35,
    messageAlign: "center",
    bottomMarginAdj: 1,
    rightAngles: !1,
    taskFontSize: 14,
    taskFontFamily: '"Open Sans", sans-serif',
    taskMargin: 50,
    activationWidth: 10,
    textPlacement: "fo",
    actorColours: [
      "#8FBC8F",
      "#7CFC00",
      "#00FFFF",
      "#20B2AA",
      "#B0E0E6",
      "#FFFFE0"
    ],
    sectionFills: [
      "#191970",
      "#8B008B",
      "#4B0082",
      "#2F4F4F",
      "#800000",
      "#8B4513",
      "#00008B"
    ],
    sectionColours: [
      "#fff"
    ],
    disableMulticolor: !1
  },
  gitGraph: {
    useMaxWidth: !0,
    titleTopMargin: 25,
    diagramPadding: 8,
    nodeLabel: {
      width: 75,
      height: 100,
      x: -25,
      y: 0
    },
    mainBranchName: "main",
    mainBranchOrder: 0,
    showCommitLabel: !0,
    showBranches: !0,
    rotateCommitLabel: !0,
    parallelCommits: !1,
    arrowMarkerAbsolute: !1
  },
  c4: {
    useMaxWidth: !0,
    diagramMarginX: 50,
    diagramMarginY: 10,
    c4ShapeMargin: 50,
    c4ShapePadding: 20,
    width: 216,
    height: 60,
    boxMargin: 10,
    c4ShapeInRow: 4,
    nextLinePaddingX: 0,
    c4BoundaryInRow: 2,
    personFontSize: 14,
    personFontFamily: '"Open Sans", sans-serif',
    personFontWeight: "normal",
    external_personFontSize: 14,
    external_personFontFamily: '"Open Sans", sans-serif',
    external_personFontWeight: "normal",
    systemFontSize: 14,
    systemFontFamily: '"Open Sans", sans-serif',
    systemFontWeight: "normal",
    external_systemFontSize: 14,
    external_systemFontFamily: '"Open Sans", sans-serif',
    external_systemFontWeight: "normal",
    system_dbFontSize: 14,
    system_dbFontFamily: '"Open Sans", sans-serif',
    system_dbFontWeight: "normal",
    external_system_dbFontSize: 14,
    external_system_dbFontFamily: '"Open Sans", sans-serif',
    external_system_dbFontWeight: "normal",
    system_queueFontSize: 14,
    system_queueFontFamily: '"Open Sans", sans-serif',
    system_queueFontWeight: "normal",
    external_system_queueFontSize: 14,
    external_system_queueFontFamily: '"Open Sans", sans-serif',
    external_system_queueFontWeight: "normal",
    boundaryFontSize: 14,
    boundaryFontFamily: '"Open Sans", sans-serif',
    boundaryFontWeight: "normal",
    messageFontSize: 12,
    messageFontFamily: '"Open Sans", sans-serif',
    messageFontWeight: "normal",
    containerFontSize: 14,
    containerFontFamily: '"Open Sans", sans-serif',
    containerFontWeight: "normal",
    external_containerFontSize: 14,
    external_containerFontFamily: '"Open Sans", sans-serif',
    external_containerFontWeight: "normal",
    container_dbFontSize: 14,
    container_dbFontFamily: '"Open Sans", sans-serif',
    container_dbFontWeight: "normal",
    external_container_dbFontSize: 14,
    external_container_dbFontFamily: '"Open Sans", sans-serif',
    external_container_dbFontWeight: "normal",
    container_queueFontSize: 14,
    container_queueFontFamily: '"Open Sans", sans-serif',
    container_queueFontWeight: "normal",
    external_container_queueFontSize: 14,
    external_container_queueFontFamily: '"Open Sans", sans-serif',
    external_container_queueFontWeight: "normal",
    componentFontSize: 14,
    componentFontFamily: '"Open Sans", sans-serif',
    componentFontWeight: "normal",
    external_componentFontSize: 14,
    external_componentFontFamily: '"Open Sans", sans-serif',
    external_componentFontWeight: "normal",
    component_dbFontSize: 14,
    component_dbFontFamily: '"Open Sans", sans-serif',
    component_dbFontWeight: "normal",
    external_component_dbFontSize: 14,
    external_component_dbFontFamily: '"Open Sans", sans-serif',
    external_component_dbFontWeight: "normal",
    component_queueFontSize: 14,
    component_queueFontFamily: '"Open Sans", sans-serif',
    component_queueFontWeight: "normal",
    external_component_queueFontSize: 14,
    external_component_queueFontFamily: '"Open Sans", sans-serif',
    external_component_queueFontWeight: "normal",
    wrap: !0,
    wrapPadding: 10,
    person_bg_color: "#08427B",
    person_border_color: "#073B6F",
    external_person_bg_color: "#686868",
    external_person_border_color: "#8A8A8A",
    system_bg_color: "#1168BD",
    system_border_color: "#3C7FC0",
    system_db_bg_color: "#1168BD",
    system_db_border_color: "#3C7FC0",
    system_queue_bg_color: "#1168BD",
    system_queue_border_color: "#3C7FC0",
    external_system_bg_color: "#999999",
    external_system_border_color: "#8A8A8A",
    external_system_db_bg_color: "#999999",
    external_system_db_border_color: "#8A8A8A",
    external_system_queue_bg_color: "#999999",
    external_system_queue_border_color: "#8A8A8A",
    container_bg_color: "#438DD5",
    container_border_color: "#3C7FC0",
    container_db_bg_color: "#438DD5",
    container_db_border_color: "#3C7FC0",
    container_queue_bg_color: "#438DD5",
    container_queue_border_color: "#3C7FC0",
    external_container_bg_color: "#B3B3B3",
    external_container_border_color: "#A6A6A6",
    external_container_db_bg_color: "#B3B3B3",
    external_container_db_border_color: "#A6A6A6",
    external_container_queue_bg_color: "#B3B3B3",
    external_container_queue_border_color: "#A6A6A6",
    component_bg_color: "#85BBF0",
    component_border_color: "#78A8D8",
    component_db_bg_color: "#85BBF0",
    component_db_border_color: "#78A8D8",
    component_queue_bg_color: "#85BBF0",
    component_queue_border_color: "#78A8D8",
    external_component_bg_color: "#CCCCCC",
    external_component_border_color: "#BFBFBF",
    external_component_db_bg_color: "#CCCCCC",
    external_component_db_border_color: "#BFBFBF",
    external_component_queue_bg_color: "#CCCCCC",
    external_component_queue_border_color: "#BFBFBF"
  },
  sankey: {
    useMaxWidth: !0,
    width: 600,
    height: 400,
    linkColor: "gradient",
    nodeAlignment: "justify",
    showValues: !0,
    prefix: "",
    suffix: ""
  },
  block: {
    useMaxWidth: !0,
    padding: 8
  },
  packet: {
    useMaxWidth: !0,
    rowHeight: 32,
    bitWidth: 32,
    bitsPerRow: 32,
    showBits: !0,
    paddingX: 5,
    paddingY: 5
  },
  architecture: {
    useMaxWidth: !0,
    padding: 40,
    iconSize: 80,
    fontSize: 16
  },
  radar: {
    useMaxWidth: !0,
    width: 600,
    height: 600,
    marginTop: 50,
    marginRight: 50,
    marginBottom: 50,
    marginLeft: 50,
    axisScaleFactor: 1,
    axisLabelFactor: 1.05,
    curveTension: 0.17
  },
  theme: "default",
  look: "classic",
  handDrawnSeed: 0,
  layout: "dagre",
  maxTextSize: 5e4,
  maxEdges: 500,
  darkMode: !1,
  fontFamily: '"trebuchet ms", verdana, arial, sans-serif;',
  logLevel: 5,
  securityLevel: "strict",
  startOnLoad: !0,
  arrowMarkerAbsolute: !1,
  secure: [
    "secure",
    "securityLevel",
    "startOnLoad",
    "maxTextSize",
    "suppressErrorRendering",
    "maxEdges"
  ],
  legacyMathML: !1,
  forceLegacyMathML: !1,
  deterministicIds: !1,
  fontSize: 16,
  markdownAutoWrap: !0,
  suppressErrorRendering: !1
}, Gl = {
  ...Kt,
  // Set, even though they're `undefined` so that `configKeys` finds these keys
  // TODO: Should we replace these with `null` so that they can go in the JSON Schema?
  deterministicIDSeed: void 0,
  elk: {
    // mergeEdges is needed here to be considered
    mergeEdges: !1,
    nodePlacementStrategy: "BRANDES_KOEPF",
    forceNodeModelOrder: !1,
    considerModelOrder: "NODES_AND_EDGES"
  },
  themeCSS: void 0,
  // add non-JSON default config values
  themeVariables: fe.default.getThemeVariables(),
  sequence: {
    ...Kt.sequence,
    messageFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont"),
    noteFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.noteFontFamily,
        fontSize: this.noteFontSize,
        fontWeight: this.noteFontWeight
      };
    }, "noteFont"),
    actorFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.actorFontFamily,
        fontSize: this.actorFontSize,
        fontWeight: this.actorFontWeight
      };
    }, "actorFont")
  },
  class: {
    hideEmptyMembersBox: !1
  },
  gantt: {
    ...Kt.gantt,
    tickInterval: void 0,
    useWidth: void 0
    // can probably be removed since `configKeys` already includes this
  },
  c4: {
    ...Kt.c4,
    useWidth: void 0,
    personFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.personFontFamily,
        fontSize: this.personFontSize,
        fontWeight: this.personFontWeight
      };
    }, "personFont"),
    flowchart: {
      ...Kt.flowchart,
      inheritDir: !1
      // default to legacy behavior
    },
    external_personFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_personFontFamily,
        fontSize: this.external_personFontSize,
        fontWeight: this.external_personFontWeight
      };
    }, "external_personFont"),
    systemFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.systemFontFamily,
        fontSize: this.systemFontSize,
        fontWeight: this.systemFontWeight
      };
    }, "systemFont"),
    external_systemFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_systemFontFamily,
        fontSize: this.external_systemFontSize,
        fontWeight: this.external_systemFontWeight
      };
    }, "external_systemFont"),
    system_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.system_dbFontFamily,
        fontSize: this.system_dbFontSize,
        fontWeight: this.system_dbFontWeight
      };
    }, "system_dbFont"),
    external_system_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_system_dbFontFamily,
        fontSize: this.external_system_dbFontSize,
        fontWeight: this.external_system_dbFontWeight
      };
    }, "external_system_dbFont"),
    system_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.system_queueFontFamily,
        fontSize: this.system_queueFontSize,
        fontWeight: this.system_queueFontWeight
      };
    }, "system_queueFont"),
    external_system_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_system_queueFontFamily,
        fontSize: this.external_system_queueFontSize,
        fontWeight: this.external_system_queueFontWeight
      };
    }, "external_system_queueFont"),
    containerFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.containerFontFamily,
        fontSize: this.containerFontSize,
        fontWeight: this.containerFontWeight
      };
    }, "containerFont"),
    external_containerFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_containerFontFamily,
        fontSize: this.external_containerFontSize,
        fontWeight: this.external_containerFontWeight
      };
    }, "external_containerFont"),
    container_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.container_dbFontFamily,
        fontSize: this.container_dbFontSize,
        fontWeight: this.container_dbFontWeight
      };
    }, "container_dbFont"),
    external_container_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_container_dbFontFamily,
        fontSize: this.external_container_dbFontSize,
        fontWeight: this.external_container_dbFontWeight
      };
    }, "external_container_dbFont"),
    container_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.container_queueFontFamily,
        fontSize: this.container_queueFontSize,
        fontWeight: this.container_queueFontWeight
      };
    }, "container_queueFont"),
    external_container_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_container_queueFontFamily,
        fontSize: this.external_container_queueFontSize,
        fontWeight: this.external_container_queueFontWeight
      };
    }, "external_container_queueFont"),
    componentFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.componentFontFamily,
        fontSize: this.componentFontSize,
        fontWeight: this.componentFontWeight
      };
    }, "componentFont"),
    external_componentFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_componentFontFamily,
        fontSize: this.external_componentFontSize,
        fontWeight: this.external_componentFontWeight
      };
    }, "external_componentFont"),
    component_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.component_dbFontFamily,
        fontSize: this.component_dbFontSize,
        fontWeight: this.component_dbFontWeight
      };
    }, "component_dbFont"),
    external_component_dbFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_component_dbFontFamily,
        fontSize: this.external_component_dbFontSize,
        fontWeight: this.external_component_dbFontWeight
      };
    }, "external_component_dbFont"),
    component_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.component_queueFontFamily,
        fontSize: this.component_queueFontSize,
        fontWeight: this.component_queueFontWeight
      };
    }, "component_queueFont"),
    external_component_queueFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.external_component_queueFontFamily,
        fontSize: this.external_component_queueFontSize,
        fontWeight: this.external_component_queueFontWeight
      };
    }, "external_component_queueFont"),
    boundaryFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.boundaryFontFamily,
        fontSize: this.boundaryFontSize,
        fontWeight: this.boundaryFontWeight
      };
    }, "boundaryFont"),
    messageFont: /* @__PURE__ */ p(function() {
      return {
        fontFamily: this.messageFontFamily,
        fontSize: this.messageFontSize,
        fontWeight: this.messageFontWeight
      };
    }, "messageFont")
  },
  pie: {
    ...Kt.pie,
    useWidth: 984
  },
  xyChart: {
    ...Kt.xyChart,
    useWidth: void 0
  },
  requirement: {
    ...Kt.requirement,
    useWidth: void 0
  },
  packet: {
    ...Kt.packet
  },
  radar: {
    ...Kt.radar
  },
  treemap: {
    useMaxWidth: !0,
    padding: 10,
    diagramPadding: 8,
    showValues: !0,
    nodeWidth: 100,
    nodeHeight: 40,
    borderWidth: 1,
    valueFontSize: 12,
    labelFontSize: 14,
    valueFormat: ","
  }
}, Ul = /* @__PURE__ */ p((e, t = "") => Object.keys(e).reduce((r, i) => Array.isArray(e[i]) ? r : typeof e[i] == "object" && e[i] !== null ? [...r, t + i, ...Ul(e[i], "")] : [...r, t + i], []), "keyify"), Bg = new Set(Ul(Gl, "")), Xl = Gl, ji = /* @__PURE__ */ p((e) => {
  if (F.debug("sanitizeDirective called with", e), !(typeof e != "object" || e == null)) {
    if (Array.isArray(e)) {
      e.forEach((t) => ji(t));
      return;
    }
    for (const t of Object.keys(e)) {
      if (F.debug("Checking key", t), t.startsWith("__") || t.includes("proto") || t.includes("constr") || !Bg.has(t) || e[t] == null) {
        F.debug("sanitize deleting key: ", t), delete e[t];
        continue;
      }
      if (typeof e[t] == "object") {
        F.debug("sanitizing object", t), ji(e[t]);
        continue;
      }
      const r = ["themeCSS", "fontFamily", "altFontFamily"];
      for (const i of r)
        t.includes(i) && (F.debug("sanitizing css option", t), e[t] = Lg(e[t]));
    }
    if (e.themeVariables)
      for (const t of Object.keys(e.themeVariables)) {
        const r = e.themeVariables[t];
        r != null && r.match && !r.match(/^[\d "#%(),.;A-Za-z]+$/) && (e.themeVariables[t] = "");
      }
    F.debug("After sanitization", e);
  }
}, "sanitizeDirective"), Lg = /* @__PURE__ */ p((e) => {
  let t = 0, r = 0;
  for (const i of e) {
    if (t < r)
      return "{ /* ERROR: Unbalanced CSS */ }";
    i === "{" ? t++ : i === "}" && r++;
  }
  return t !== r ? "{ /* ERROR: Unbalanced CSS */ }" : e;
}, "sanitizeCss"), mr = Object.freeze(Xl), Rt = xt({}, mr), Yi, We = [], Vr = xt({}, mr), $n = /* @__PURE__ */ p((e, t) => {
  let r = xt({}, e), i = {};
  for (const n of t)
    Kl(n), i = xt(i, n);
  if (r = xt(r, i), i.theme && i.theme in fe) {
    const n = xt({}, Yi), a = xt(
      n.themeVariables || {},
      i.themeVariables
    );
    r.theme && r.theme in fe && (r.themeVariables = fe[r.theme].getThemeVariables(a));
  }
  return Vr = r, Ql(Vr), Vr;
}, "updateCurrentConfig"), Mg = /* @__PURE__ */ p((e) => (Rt = xt({}, mr), Rt = xt(Rt, e), e.theme && fe[e.theme] && (Rt.themeVariables = fe[e.theme].getThemeVariables(e.themeVariables)), $n(Rt, We), Rt), "setSiteConfig"), $g = /* @__PURE__ */ p((e) => {
  Yi = xt({}, e);
}, "saveConfigFromInitialize"), Ag = /* @__PURE__ */ p((e) => (Rt = xt(Rt, e), $n(Rt, We), Rt), "updateSiteConfig"), Vl = /* @__PURE__ */ p(() => xt({}, Rt), "getSiteConfig"), Zl = /* @__PURE__ */ p((e) => (Ql(e), xt(Vr, e), Bt()), "setConfig"), Bt = /* @__PURE__ */ p(() => xt({}, Vr), "getConfig"), Kl = /* @__PURE__ */ p((e) => {
  e && (["secure", ...Rt.secure ?? []].forEach((t) => {
    Object.hasOwn(e, t) && (F.debug(`Denied attempt to modify a secure key ${t}`, e[t]), delete e[t]);
  }), Object.keys(e).forEach((t) => {
    t.startsWith("__") && delete e[t];
  }), Object.keys(e).forEach((t) => {
    typeof e[t] == "string" && (e[t].includes("<") || e[t].includes(">") || e[t].includes("url(data:")) && delete e[t], typeof e[t] == "object" && Kl(e[t]);
  }));
}, "sanitize"), Fg = /* @__PURE__ */ p((e) => {
  var t;
  ji(e), e.fontFamily && !((t = e.themeVariables) != null && t.fontFamily) && (e.themeVariables = {
    ...e.themeVariables,
    fontFamily: e.fontFamily
  }), We.push(e), $n(Rt, We);
}, "addDirective"), Gi = /* @__PURE__ */ p((e = Rt) => {
  We = [], $n(e, We);
}, "reset"), Eg = {
  LAZY_LOAD_DEPRECATED: "The configuration options lazyLoadedDiagrams and loadExternalDiagramsAtStartup are deprecated. Please use registerExternalDiagrams instead."
}, yo = {}, Dg = /* @__PURE__ */ p((e) => {
  yo[e] || (F.warn(Eg[e]), yo[e] = !0);
}, "issueWarning"), Ql = /* @__PURE__ */ p((e) => {
  e && (e.lazyLoadedDiagrams || e.loadExternalDiagramsAtStartup) && Dg("LAZY_LOAD_DEPRECATED");
}, "checkConfig"), $T = /* @__PURE__ */ p(() => {
  let e = {};
  Yi && (e = xt(e, Yi));
  for (const t of We)
    e = xt(e, t);
  return e;
}, "getUserDefinedConfig"), fi = /<br\s*\/?>/gi, Og = /* @__PURE__ */ p((e) => e ? ec(e).replace(/\\n/g, "#br#").split("#br#") : [""], "getRows"), Rg = /* @__PURE__ */ (() => {
  let e = !1;
  return () => {
    e || (Jl(), e = !0);
  };
})();
function Jl() {
  const e = "data-temp-href-target";
  gr.addHook("beforeSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute("target") && t.setAttribute(e, t.getAttribute("target") ?? "");
  }), gr.addHook("afterSanitizeAttributes", (t) => {
    t.tagName === "A" && t.hasAttribute(e) && (t.setAttribute("target", t.getAttribute(e) ?? ""), t.removeAttribute(e), t.getAttribute("target") === "_blank" && t.setAttribute("rel", "noopener"));
  });
}
p(Jl, "setupDompurifyHooks");
var tc = /* @__PURE__ */ p((e) => (Rg(), gr.sanitize(e)), "removeScript"), xo = /* @__PURE__ */ p((e, t) => {
  var r;
  if (((r = t.flowchart) == null ? void 0 : r.htmlLabels) !== !1) {
    const i = t.securityLevel;
    i === "antiscript" || i === "strict" ? e = tc(e) : i !== "loose" && (e = ec(e), e = e.replace(/</g, "&lt;").replace(/>/g, "&gt;"), e = e.replace(/=/g, "&equals;"), e = zg(e));
  }
  return e;
}, "sanitizeMore"), jt = /* @__PURE__ */ p((e, t) => e && (t.dompurifyConfig ? e = gr.sanitize(xo(e, t), t.dompurifyConfig).toString() : e = gr.sanitize(xo(e, t), {
  FORBID_TAGS: ["style"]
}).toString(), e), "sanitizeText"), Ig = /* @__PURE__ */ p((e, t) => typeof e == "string" ? jt(e, t) : e.flat().map((r) => jt(r, t)), "sanitizeTextOrArray"), Pg = /* @__PURE__ */ p((e) => fi.test(e), "hasBreaks"), Ng = /* @__PURE__ */ p((e) => e.split(fi), "splitBreaks"), zg = /* @__PURE__ */ p((e) => e.replace(/#br#/g, "<br/>"), "placeholderToBreak"), ec = /* @__PURE__ */ p((e) => e.replace(fi, "#br#"), "breakToPlaceholder"), rc = /* @__PURE__ */ p((e) => {
  let t = "";
  return e && (t = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, t = CSS.escape(t)), t;
}, "getUrl"), Ct = /* @__PURE__ */ p((e) => !(e === !1 || ["false", "null", "0"].includes(String(e).trim().toLowerCase())), "evaluate"), qg = /* @__PURE__ */ p(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.max(...t);
}, "getMax"), Wg = /* @__PURE__ */ p(function(...e) {
  const t = e.filter((r) => !isNaN(r));
  return Math.min(...t);
}, "getMin"), bo = /* @__PURE__ */ p(function(e) {
  const t = e.split(/(,)/), r = [];
  for (let i = 0; i < t.length; i++) {
    let n = t[i];
    if (n === "," && i > 0 && i + 1 < t.length) {
      const a = t[i - 1], o = t[i + 1];
      Hg(a, o) && (n = a + "," + o, i++, r.pop());
    }
    r.push(jg(n));
  }
  return r.join("");
}, "parseGenericTypes"), ba = /* @__PURE__ */ p((e, t) => Math.max(0, e.split(t).length - 1), "countOccurrence"), Hg = /* @__PURE__ */ p((e, t) => {
  const r = ba(e, "~"), i = ba(t, "~");
  return r === 1 && i === 1;
}, "shouldCombineSets"), jg = /* @__PURE__ */ p((e) => {
  const t = ba(e, "~");
  let r = !1;
  if (t <= 1)
    return e;
  t % 2 !== 0 && e.startsWith("~") && (e = e.substring(1), r = !0);
  const i = [...e];
  let n = i.indexOf("~"), a = i.lastIndexOf("~");
  for (; n !== -1 && a !== -1 && n !== a; )
    i[n] = "<", i[a] = ">", n = i.indexOf("~"), a = i.lastIndexOf("~");
  return r && i.unshift("~"), i.join("");
}, "processSet"), Co = /* @__PURE__ */ p(() => window.MathMLElement !== void 0, "isMathMLSupported"), Ca = /\$\$(.*)\$\$/g, yr = /* @__PURE__ */ p((e) => {
  var t;
  return (((t = e.match(Ca)) == null ? void 0 : t.length) ?? 0) > 0;
}, "hasKatex"), AT = /* @__PURE__ */ p(async (e, t) => {
  const r = document.createElement("div");
  r.innerHTML = await ps(e, t), r.id = "katex-temp", r.style.visibility = "hidden", r.style.position = "absolute", r.style.top = "0";
  const i = document.querySelector("body");
  i == null || i.insertAdjacentElement("beforeend", r);
  const n = { width: r.clientWidth, height: r.clientHeight };
  return r.remove(), n;
}, "calculateMathMLDimensions"), Yg = /* @__PURE__ */ p(async (e, t) => {
  if (!yr(e))
    return e;
  if (!(Co() || t.legacyMathML || t.forceLegacyMathML))
    return e.replace(Ca, "MathML is unsupported in this environment.");
  {
    const { default: r } = await import("./index-Bt-EZqiV.js").then((n) => n.e), i = t.forceLegacyMathML || !Co() && t.legacyMathML ? "htmlAndMathml" : "mathml";
    return e.split(fi).map(
      (n) => yr(n) ? `<div style="display: flex; align-items: center; justify-content: center; white-space: nowrap;">${n}</div>` : `<div>${n}</div>`
    ).join("").replace(
      Ca,
      (n, a) => r.renderToString(a, {
        throwOnError: !0,
        displayMode: !0,
        output: i
      }).replace(/\n/g, " ").replace(/<annotation.*<\/annotation>/g, "")
    );
  }
}, "renderKatexUnsanitized"), ps = /* @__PURE__ */ p(async (e, t) => jt(await Yg(e, t), t), "renderKatexSanitized"), kr = {
  getRows: Og,
  sanitizeText: jt,
  sanitizeTextOrArray: Ig,
  hasBreaks: Pg,
  splitBreaks: Ng,
  lineBreakRegex: fi,
  removeScript: tc,
  getUrl: rc,
  evaluate: Ct,
  getMax: qg,
  getMin: Wg
}, Gg = /* @__PURE__ */ p(function(e, t) {
  for (let r of t)
    e.attr(r[0], r[1]);
}, "d3Attrs"), Ug = /* @__PURE__ */ p(function(e, t, r) {
  let i = /* @__PURE__ */ new Map();
  return r ? (i.set("width", "100%"), i.set("style", `max-width: ${t}px;`)) : (i.set("height", e), i.set("width", t)), i;
}, "calculateSvgSizeAttrs"), ic = /* @__PURE__ */ p(function(e, t, r, i) {
  const n = Ug(t, r, i);
  Gg(e, n);
}, "configureSvgSize"), Xg = /* @__PURE__ */ p(function(e, t, r, i) {
  const n = t.node().getBBox(), a = n.width, o = n.height;
  F.info(`SVG bounds: ${a}x${o}`, n);
  let s = 0, l = 0;
  F.info(`Graph bounds: ${s}x${l}`, e), s = a + r * 2, l = o + r * 2, F.info(`Calculated bounds: ${s}x${l}`), ic(t, l, s, i);
  const c = `${n.x - r} ${n.y - r} ${n.width + 2 * r} ${n.height + 2 * r}`;
  t.attr("viewBox", c);
}, "setupGraphViewbox"), Ai = {}, Vg = /* @__PURE__ */ p((e, t, r) => {
  let i = "";
  return e in Ai && Ai[e] ? i = Ai[e](r) : F.warn(`No theme found for ${e}`), ` & {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
    fill: ${r.textColor}
  }
  @keyframes edge-animation-frame {
    from {
      stroke-dashoffset: 0;
    }
  }
  @keyframes dash {
    to {
      stroke-dashoffset: 0;
    }
  }
  & .edge-animation-slow {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 50s linear infinite;
    stroke-linecap: round;
  }
  & .edge-animation-fast {
    stroke-dasharray: 9,5 !important;
    stroke-dashoffset: 900;
    animation: dash 20s linear infinite;
    stroke-linecap: round;
  }
  /* Classes common for multiple diagrams */

  & .error-icon {
    fill: ${r.errorBkgColor};
  }
  & .error-text {
    fill: ${r.errorTextColor};
    stroke: ${r.errorTextColor};
  }

  & .edge-thickness-normal {
    stroke-width: 1px;
  }
  & .edge-thickness-thick {
    stroke-width: 3.5px
  }
  & .edge-pattern-solid {
    stroke-dasharray: 0;
  }
  & .edge-thickness-invisible {
    stroke-width: 0;
    fill: none;
  }
  & .edge-pattern-dashed{
    stroke-dasharray: 3;
  }
  .edge-pattern-dotted {
    stroke-dasharray: 2;
  }

  & .marker {
    fill: ${r.lineColor};
    stroke: ${r.lineColor};
  }
  & .marker.cross {
    stroke: ${r.lineColor};
  }

  & svg {
    font-family: ${r.fontFamily};
    font-size: ${r.fontSize};
  }
   & p {
    margin: 0
   }

  ${i}

  ${t}
`;
}, "getStyles"), Zg = /* @__PURE__ */ p((e, t) => {
  t !== void 0 && (Ai[e] = t);
}, "addStylesForDiagram"), Kg = Vg, nc = {};
og(nc, {
  clear: () => Qg,
  getAccDescription: () => r0,
  getAccTitle: () => t0,
  getDiagramTitle: () => n0,
  setAccDescription: () => e0,
  setAccTitle: () => Jg,
  setDiagramTitle: () => i0
});
var gs = "", ms = "", ys = "", xs = /* @__PURE__ */ p((e) => jt(e, Bt()), "sanitizeText"), Qg = /* @__PURE__ */ p(() => {
  gs = "", ys = "", ms = "";
}, "clear"), Jg = /* @__PURE__ */ p((e) => {
  gs = xs(e).replace(/^\s+/g, "");
}, "setAccTitle"), t0 = /* @__PURE__ */ p(() => gs, "getAccTitle"), e0 = /* @__PURE__ */ p((e) => {
  ys = xs(e).replace(/\n\s+/g, `
`);
}, "setAccDescription"), r0 = /* @__PURE__ */ p(() => ys, "getAccDescription"), i0 = /* @__PURE__ */ p((e) => {
  ms = xs(e);
}, "setDiagramTitle"), n0 = /* @__PURE__ */ p(() => ms, "getDiagramTitle"), wo = F, a0 = fs, nt = Bt, FT = Zl, ET = mr, bs = /* @__PURE__ */ p((e) => jt(e, nt()), "sanitizeText"), s0 = Xg, o0 = /* @__PURE__ */ p(() => nc, "getCommonDb"), Ui = {}, Xi = /* @__PURE__ */ p((e, t, r) => {
  var i;
  Ui[e] && wo.warn(`Diagram with id ${e} already registered. Overwriting.`), Ui[e] = t, r && Yl(e, r), Zg(e, t.styles), (i = t.injectUtils) == null || i.call(
    t,
    wo,
    a0,
    nt,
    bs,
    s0,
    o0(),
    () => {
    }
  );
}, "registerDiagram"), wa = /* @__PURE__ */ p((e) => {
  if (e in Ui)
    return Ui[e];
  throw new l0(e);
}, "getDiagram"), dr, l0 = (dr = class extends Error {
  constructor(t) {
    super(`Diagram ${t} not found.`);
  }
}, p(dr, "DiagramNotFoundError"), dr), c0 = { value: () => {
} };
function ac() {
  for (var e = 0, t = arguments.length, r = {}, i; e < t; ++e) {
    if (!(i = arguments[e] + "") || i in r || /[\s.]/.test(i)) throw new Error("illegal type: " + i);
    r[i] = [];
  }
  return new Fi(r);
}
function Fi(e) {
  this._ = e;
}
function h0(e, t) {
  return e.trim().split(/^|\s+/).map(function(r) {
    var i = "", n = r.indexOf(".");
    if (n >= 0 && (i = r.slice(n + 1), r = r.slice(0, n)), r && !t.hasOwnProperty(r)) throw new Error("unknown type: " + r);
    return { type: r, name: i };
  });
}
Fi.prototype = ac.prototype = {
  constructor: Fi,
  on: function(e, t) {
    var r = this._, i = h0(e + "", r), n, a = -1, o = i.length;
    if (arguments.length < 2) {
      for (; ++a < o; ) if ((n = (e = i[a]).type) && (n = u0(r[n], e.name))) return n;
      return;
    }
    if (t != null && typeof t != "function") throw new Error("invalid callback: " + t);
    for (; ++a < o; )
      if (n = (e = i[a]).type) r[n] = _o(r[n], e.name, t);
      else if (t == null) for (n in r) r[n] = _o(r[n], e.name, null);
    return this;
  },
  copy: function() {
    var e = {}, t = this._;
    for (var r in t) e[r] = t[r].slice();
    return new Fi(e);
  },
  call: function(e, t) {
    if ((n = arguments.length - 2) > 0) for (var r = new Array(n), i = 0, n, a; i < n; ++i) r[i] = arguments[i + 2];
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (a = this._[e], i = 0, n = a.length; i < n; ++i) a[i].value.apply(t, r);
  },
  apply: function(e, t, r) {
    if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
    for (var i = this._[e], n = 0, a = i.length; n < a; ++n) i[n].value.apply(t, r);
  }
};
function u0(e, t) {
  for (var r = 0, i = e.length, n; r < i; ++r)
    if ((n = e[r]).name === t)
      return n.value;
}
function _o(e, t, r) {
  for (var i = 0, n = e.length; i < n; ++i)
    if (e[i].name === t) {
      e[i] = c0, e = e.slice(0, i).concat(e.slice(i + 1));
      break;
    }
  return r != null && e.push({ name: t, value: r }), e;
}
var _a = "http://www.w3.org/1999/xhtml";
const vo = {
  svg: "http://www.w3.org/2000/svg",
  xhtml: _a,
  xlink: "http://www.w3.org/1999/xlink",
  xml: "http://www.w3.org/XML/1998/namespace",
  xmlns: "http://www.w3.org/2000/xmlns/"
};
function An(e) {
  var t = e += "", r = t.indexOf(":");
  return r >= 0 && (t = e.slice(0, r)) !== "xmlns" && (e = e.slice(r + 1)), vo.hasOwnProperty(t) ? { space: vo[t], local: e } : e;
}
function f0(e) {
  return function() {
    var t = this.ownerDocument, r = this.namespaceURI;
    return r === _a && t.documentElement.namespaceURI === _a ? t.createElement(e) : t.createElementNS(r, e);
  };
}
function d0(e) {
  return function() {
    return this.ownerDocument.createElementNS(e.space, e.local);
  };
}
function sc(e) {
  var t = An(e);
  return (t.local ? d0 : f0)(t);
}
function p0() {
}
function Cs(e) {
  return e == null ? p0 : function() {
    return this.querySelector(e);
  };
}
function g0(e) {
  typeof e != "function" && (e = Cs(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = new Array(o), l, c, h = 0; h < o; ++h)
      (l = a[h]) && (c = e.call(l, l.__data__, h, a)) && ("__data__" in l && (c.__data__ = l.__data__), s[h] = c);
  return new qt(i, this._parents);
}
function m0(e) {
  return e == null ? [] : Array.isArray(e) ? e : Array.from(e);
}
function y0() {
  return [];
}
function oc(e) {
  return e == null ? y0 : function() {
    return this.querySelectorAll(e);
  };
}
function x0(e) {
  return function() {
    return m0(e.apply(this, arguments));
  };
}
function b0(e) {
  typeof e == "function" ? e = x0(e) : e = oc(e);
  for (var t = this._groups, r = t.length, i = [], n = [], a = 0; a < r; ++a)
    for (var o = t[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && (i.push(e.call(l, l.__data__, c, o)), n.push(l));
  return new qt(i, n);
}
function lc(e) {
  return function() {
    return this.matches(e);
  };
}
function cc(e) {
  return function(t) {
    return t.matches(e);
  };
}
var C0 = Array.prototype.find;
function w0(e) {
  return function() {
    return C0.call(this.children, e);
  };
}
function _0() {
  return this.firstElementChild;
}
function v0(e) {
  return this.select(e == null ? _0 : w0(typeof e == "function" ? e : cc(e)));
}
var k0 = Array.prototype.filter;
function S0() {
  return Array.from(this.children);
}
function T0(e) {
  return function() {
    return k0.call(this.children, e);
  };
}
function B0(e) {
  return this.selectAll(e == null ? S0 : T0(typeof e == "function" ? e : cc(e)));
}
function L0(e) {
  typeof e != "function" && (e = lc(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new qt(i, this._parents);
}
function hc(e) {
  return new Array(e.length);
}
function M0() {
  return new qt(this._enter || this._groups.map(hc), this._parents);
}
function Vi(e, t) {
  this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t;
}
Vi.prototype = {
  constructor: Vi,
  appendChild: function(e) {
    return this._parent.insertBefore(e, this._next);
  },
  insertBefore: function(e, t) {
    return this._parent.insertBefore(e, t);
  },
  querySelector: function(e) {
    return this._parent.querySelector(e);
  },
  querySelectorAll: function(e) {
    return this._parent.querySelectorAll(e);
  }
};
function $0(e) {
  return function() {
    return e;
  };
}
function A0(e, t, r, i, n, a) {
  for (var o = 0, s, l = t.length, c = a.length; o < c; ++o)
    (s = t[o]) ? (s.__data__ = a[o], i[o] = s) : r[o] = new Vi(e, a[o]);
  for (; o < l; ++o)
    (s = t[o]) && (n[o] = s);
}
function F0(e, t, r, i, n, a, o) {
  var s, l, c = /* @__PURE__ */ new Map(), h = t.length, u = a.length, f = new Array(h), d;
  for (s = 0; s < h; ++s)
    (l = t[s]) && (f[s] = d = o.call(l, l.__data__, s, t) + "", c.has(d) ? n[s] = l : c.set(d, l));
  for (s = 0; s < u; ++s)
    d = o.call(e, a[s], s, a) + "", (l = c.get(d)) ? (i[s] = l, l.__data__ = a[s], c.delete(d)) : r[s] = new Vi(e, a[s]);
  for (s = 0; s < h; ++s)
    (l = t[s]) && c.get(f[s]) === l && (n[s] = l);
}
function E0(e) {
  return e.__data__;
}
function D0(e, t) {
  if (!arguments.length) return Array.from(this, E0);
  var r = t ? F0 : A0, i = this._parents, n = this._groups;
  typeof e != "function" && (e = $0(e));
  for (var a = n.length, o = new Array(a), s = new Array(a), l = new Array(a), c = 0; c < a; ++c) {
    var h = i[c], u = n[c], f = u.length, d = O0(e.call(h, h && h.__data__, c, i)), g = d.length, m = s[c] = new Array(g), x = o[c] = new Array(g), y = l[c] = new Array(f);
    r(h, u, m, x, y, d, t);
    for (var b = 0, w = 0, k, _; b < g; ++b)
      if (k = m[b]) {
        for (b >= w && (w = b + 1); !(_ = x[w]) && ++w < g; ) ;
        k._next = _ || null;
      }
  }
  return o = new qt(o, i), o._enter = s, o._exit = l, o;
}
function O0(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function R0() {
  return new qt(this._exit || this._groups.map(hc), this._parents);
}
function I0(e, t, r) {
  var i = this.enter(), n = this, a = this.exit();
  return typeof e == "function" ? (i = e(i), i && (i = i.selection())) : i = i.append(e + ""), t != null && (n = t(n), n && (n = n.selection())), r == null ? a.remove() : r(a), i && n ? i.merge(n).order() : n;
}
function P0(e) {
  for (var t = e.selection ? e.selection() : e, r = this._groups, i = t._groups, n = r.length, a = i.length, o = Math.min(n, a), s = new Array(n), l = 0; l < o; ++l)
    for (var c = r[l], h = i[l], u = c.length, f = s[l] = new Array(u), d, g = 0; g < u; ++g)
      (d = c[g] || h[g]) && (f[g] = d);
  for (; l < n; ++l)
    s[l] = r[l];
  return new qt(s, this._parents);
}
function N0() {
  for (var e = this._groups, t = -1, r = e.length; ++t < r; )
    for (var i = e[t], n = i.length - 1, a = i[n], o; --n >= 0; )
      (o = i[n]) && (a && o.compareDocumentPosition(a) ^ 4 && a.parentNode.insertBefore(o, a), a = o);
  return this;
}
function z0(e) {
  e || (e = q0);
  function t(u, f) {
    return u && f ? e(u.__data__, f.__data__) : !u - !f;
  }
  for (var r = this._groups, i = r.length, n = new Array(i), a = 0; a < i; ++a) {
    for (var o = r[a], s = o.length, l = n[a] = new Array(s), c, h = 0; h < s; ++h)
      (c = o[h]) && (l[h] = c);
    l.sort(t);
  }
  return new qt(n, this._parents).order();
}
function q0(e, t) {
  return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN;
}
function W0() {
  var e = arguments[0];
  return arguments[0] = this, e.apply(null, arguments), this;
}
function H0() {
  return Array.from(this);
}
function j0() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length; n < a; ++n) {
      var o = i[n];
      if (o) return o;
    }
  return null;
}
function Y0() {
  let e = 0;
  for (const t of this) ++e;
  return e;
}
function G0() {
  return !this.node();
}
function U0(e) {
  for (var t = this._groups, r = 0, i = t.length; r < i; ++r)
    for (var n = t[r], a = 0, o = n.length, s; a < o; ++a)
      (s = n[a]) && e.call(s, s.__data__, a, n);
  return this;
}
function X0(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function V0(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Z0(e, t) {
  return function() {
    this.setAttribute(e, t);
  };
}
function K0(e, t) {
  return function() {
    this.setAttributeNS(e.space, e.local, t);
  };
}
function Q0(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttribute(e) : this.setAttribute(e, r);
  };
}
function J0(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, r);
  };
}
function tm(e, t) {
  var r = An(e);
  if (arguments.length < 2) {
    var i = this.node();
    return r.local ? i.getAttributeNS(r.space, r.local) : i.getAttribute(r);
  }
  return this.each((t == null ? r.local ? V0 : X0 : typeof t == "function" ? r.local ? J0 : Q0 : r.local ? K0 : Z0)(r, t));
}
function uc(e) {
  return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView;
}
function em(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function rm(e, t, r) {
  return function() {
    this.style.setProperty(e, t, r);
  };
}
function im(e, t, r) {
  return function() {
    var i = t.apply(this, arguments);
    i == null ? this.style.removeProperty(e) : this.style.setProperty(e, i, r);
  };
}
function nm(e, t, r) {
  return arguments.length > 1 ? this.each((t == null ? em : typeof t == "function" ? im : rm)(e, t, r ?? "")) : xr(this.node(), e);
}
function xr(e, t) {
  return e.style.getPropertyValue(t) || uc(e).getComputedStyle(e, null).getPropertyValue(t);
}
function am(e) {
  return function() {
    delete this[e];
  };
}
function sm(e, t) {
  return function() {
    this[e] = t;
  };
}
function om(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    r == null ? delete this[e] : this[e] = r;
  };
}
function lm(e, t) {
  return arguments.length > 1 ? this.each((t == null ? am : typeof t == "function" ? om : sm)(e, t)) : this.node()[e];
}
function fc(e) {
  return e.trim().split(/^|\s+/);
}
function ws(e) {
  return e.classList || new dc(e);
}
function dc(e) {
  this._node = e, this._names = fc(e.getAttribute("class") || "");
}
dc.prototype = {
  add: function(e) {
    var t = this._names.indexOf(e);
    t < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")));
  },
  remove: function(e) {
    var t = this._names.indexOf(e);
    t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")));
  },
  contains: function(e) {
    return this._names.indexOf(e) >= 0;
  }
};
function pc(e, t) {
  for (var r = ws(e), i = -1, n = t.length; ++i < n; ) r.add(t[i]);
}
function gc(e, t) {
  for (var r = ws(e), i = -1, n = t.length; ++i < n; ) r.remove(t[i]);
}
function cm(e) {
  return function() {
    pc(this, e);
  };
}
function hm(e) {
  return function() {
    gc(this, e);
  };
}
function um(e, t) {
  return function() {
    (t.apply(this, arguments) ? pc : gc)(this, e);
  };
}
function fm(e, t) {
  var r = fc(e + "");
  if (arguments.length < 2) {
    for (var i = ws(this.node()), n = -1, a = r.length; ++n < a; ) if (!i.contains(r[n])) return !1;
    return !0;
  }
  return this.each((typeof t == "function" ? um : t ? cm : hm)(r, t));
}
function dm() {
  this.textContent = "";
}
function pm(e) {
  return function() {
    this.textContent = e;
  };
}
function gm(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.textContent = t ?? "";
  };
}
function mm(e) {
  return arguments.length ? this.each(e == null ? dm : (typeof e == "function" ? gm : pm)(e)) : this.node().textContent;
}
function ym() {
  this.innerHTML = "";
}
function xm(e) {
  return function() {
    this.innerHTML = e;
  };
}
function bm(e) {
  return function() {
    var t = e.apply(this, arguments);
    this.innerHTML = t ?? "";
  };
}
function Cm(e) {
  return arguments.length ? this.each(e == null ? ym : (typeof e == "function" ? bm : xm)(e)) : this.node().innerHTML;
}
function wm() {
  this.nextSibling && this.parentNode.appendChild(this);
}
function _m() {
  return this.each(wm);
}
function vm() {
  this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild);
}
function km() {
  return this.each(vm);
}
function Sm(e) {
  var t = typeof e == "function" ? e : sc(e);
  return this.select(function() {
    return this.appendChild(t.apply(this, arguments));
  });
}
function Tm() {
  return null;
}
function Bm(e, t) {
  var r = typeof e == "function" ? e : sc(e), i = t == null ? Tm : typeof t == "function" ? t : Cs(t);
  return this.select(function() {
    return this.insertBefore(r.apply(this, arguments), i.apply(this, arguments) || null);
  });
}
function Lm() {
  var e = this.parentNode;
  e && e.removeChild(this);
}
function Mm() {
  return this.each(Lm);
}
function $m() {
  var e = this.cloneNode(!1), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Am() {
  var e = this.cloneNode(!0), t = this.parentNode;
  return t ? t.insertBefore(e, this.nextSibling) : e;
}
function Fm(e) {
  return this.select(e ? Am : $m);
}
function Em(e) {
  return arguments.length ? this.property("__data__", e) : this.node().__data__;
}
function Dm(e) {
  return function(t) {
    e.call(this, t, this.__data__);
  };
}
function Om(e) {
  return e.trim().split(/^|\s+/).map(function(t) {
    var r = "", i = t.indexOf(".");
    return i >= 0 && (r = t.slice(i + 1), t = t.slice(0, i)), { type: t, name: r };
  });
}
function Rm(e) {
  return function() {
    var t = this.__on;
    if (t) {
      for (var r = 0, i = -1, n = t.length, a; r < n; ++r)
        a = t[r], (!e.type || a.type === e.type) && a.name === e.name ? this.removeEventListener(a.type, a.listener, a.options) : t[++i] = a;
      ++i ? t.length = i : delete this.__on;
    }
  };
}
function Im(e, t, r) {
  return function() {
    var i = this.__on, n, a = Dm(t);
    if (i) {
      for (var o = 0, s = i.length; o < s; ++o)
        if ((n = i[o]).type === e.type && n.name === e.name) {
          this.removeEventListener(n.type, n.listener, n.options), this.addEventListener(n.type, n.listener = a, n.options = r), n.value = t;
          return;
        }
    }
    this.addEventListener(e.type, a, r), n = { type: e.type, name: e.name, value: t, listener: a, options: r }, i ? i.push(n) : this.__on = [n];
  };
}
function Pm(e, t, r) {
  var i = Om(e + ""), n, a = i.length, o;
  if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
      for (var l = 0, c = s.length, h; l < c; ++l)
        for (n = 0, h = s[l]; n < a; ++n)
          if ((o = i[n]).type === h.type && o.name === h.name)
            return h.value;
    }
    return;
  }
  for (s = t ? Im : Rm, n = 0; n < a; ++n) this.each(s(i[n], t, r));
  return this;
}
function mc(e, t, r) {
  var i = uc(e), n = i.CustomEvent;
  typeof n == "function" ? n = new n(t, r) : (n = i.document.createEvent("Event"), r ? (n.initEvent(t, r.bubbles, r.cancelable), n.detail = r.detail) : n.initEvent(t, !1, !1)), e.dispatchEvent(n);
}
function Nm(e, t) {
  return function() {
    return mc(this, e, t);
  };
}
function zm(e, t) {
  return function() {
    return mc(this, e, t.apply(this, arguments));
  };
}
function qm(e, t) {
  return this.each((typeof t == "function" ? zm : Nm)(e, t));
}
function* Wm() {
  for (var e = this._groups, t = 0, r = e.length; t < r; ++t)
    for (var i = e[t], n = 0, a = i.length, o; n < a; ++n)
      (o = i[n]) && (yield o);
}
var yc = [null];
function qt(e, t) {
  this._groups = e, this._parents = t;
}
function di() {
  return new qt([[document.documentElement]], yc);
}
function Hm() {
  return this;
}
qt.prototype = di.prototype = {
  constructor: qt,
  select: g0,
  selectAll: b0,
  selectChild: v0,
  selectChildren: B0,
  filter: L0,
  data: D0,
  enter: M0,
  exit: R0,
  join: I0,
  merge: P0,
  selection: Hm,
  order: N0,
  sort: z0,
  call: W0,
  nodes: H0,
  node: j0,
  size: Y0,
  empty: G0,
  each: U0,
  attr: tm,
  style: nm,
  property: lm,
  classed: fm,
  text: mm,
  html: Cm,
  raise: _m,
  lower: km,
  append: Sm,
  insert: Bm,
  remove: Mm,
  clone: Fm,
  datum: Em,
  on: Pm,
  dispatch: qm,
  [Symbol.iterator]: Wm
};
function rt(e) {
  return typeof e == "string" ? new qt([[document.querySelector(e)]], [document.documentElement]) : new qt([[e]], yc);
}
function _s(e, t, r) {
  e.prototype = t.prototype = r, r.constructor = e;
}
function xc(e, t) {
  var r = Object.create(e.prototype);
  for (var i in t) r[i] = t[i];
  return r;
}
function pi() {
}
var Qr = 0.7, Zi = 1 / Qr, ar = "\\s*([+-]?\\d+)\\s*", Jr = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", ee = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", jm = /^#([0-9a-f]{3,8})$/, Ym = new RegExp(`^rgb\\(${ar},${ar},${ar}\\)$`), Gm = new RegExp(`^rgb\\(${ee},${ee},${ee}\\)$`), Um = new RegExp(`^rgba\\(${ar},${ar},${ar},${Jr}\\)$`), Xm = new RegExp(`^rgba\\(${ee},${ee},${ee},${Jr}\\)$`), Vm = new RegExp(`^hsl\\(${Jr},${ee},${ee}\\)$`), Zm = new RegExp(`^hsla\\(${Jr},${ee},${ee},${Jr}\\)$`), ko = {
  aliceblue: 15792383,
  antiquewhite: 16444375,
  aqua: 65535,
  aquamarine: 8388564,
  azure: 15794175,
  beige: 16119260,
  bisque: 16770244,
  black: 0,
  blanchedalmond: 16772045,
  blue: 255,
  blueviolet: 9055202,
  brown: 10824234,
  burlywood: 14596231,
  cadetblue: 6266528,
  chartreuse: 8388352,
  chocolate: 13789470,
  coral: 16744272,
  cornflowerblue: 6591981,
  cornsilk: 16775388,
  crimson: 14423100,
  cyan: 65535,
  darkblue: 139,
  darkcyan: 35723,
  darkgoldenrod: 12092939,
  darkgray: 11119017,
  darkgreen: 25600,
  darkgrey: 11119017,
  darkkhaki: 12433259,
  darkmagenta: 9109643,
  darkolivegreen: 5597999,
  darkorange: 16747520,
  darkorchid: 10040012,
  darkred: 9109504,
  darksalmon: 15308410,
  darkseagreen: 9419919,
  darkslateblue: 4734347,
  darkslategray: 3100495,
  darkslategrey: 3100495,
  darkturquoise: 52945,
  darkviolet: 9699539,
  deeppink: 16716947,
  deepskyblue: 49151,
  dimgray: 6908265,
  dimgrey: 6908265,
  dodgerblue: 2003199,
  firebrick: 11674146,
  floralwhite: 16775920,
  forestgreen: 2263842,
  fuchsia: 16711935,
  gainsboro: 14474460,
  ghostwhite: 16316671,
  gold: 16766720,
  goldenrod: 14329120,
  gray: 8421504,
  green: 32768,
  greenyellow: 11403055,
  grey: 8421504,
  honeydew: 15794160,
  hotpink: 16738740,
  indianred: 13458524,
  indigo: 4915330,
  ivory: 16777200,
  khaki: 15787660,
  lavender: 15132410,
  lavenderblush: 16773365,
  lawngreen: 8190976,
  lemonchiffon: 16775885,
  lightblue: 11393254,
  lightcoral: 15761536,
  lightcyan: 14745599,
  lightgoldenrodyellow: 16448210,
  lightgray: 13882323,
  lightgreen: 9498256,
  lightgrey: 13882323,
  lightpink: 16758465,
  lightsalmon: 16752762,
  lightseagreen: 2142890,
  lightskyblue: 8900346,
  lightslategray: 7833753,
  lightslategrey: 7833753,
  lightsteelblue: 11584734,
  lightyellow: 16777184,
  lime: 65280,
  limegreen: 3329330,
  linen: 16445670,
  magenta: 16711935,
  maroon: 8388608,
  mediumaquamarine: 6737322,
  mediumblue: 205,
  mediumorchid: 12211667,
  mediumpurple: 9662683,
  mediumseagreen: 3978097,
  mediumslateblue: 8087790,
  mediumspringgreen: 64154,
  mediumturquoise: 4772300,
  mediumvioletred: 13047173,
  midnightblue: 1644912,
  mintcream: 16121850,
  mistyrose: 16770273,
  moccasin: 16770229,
  navajowhite: 16768685,
  navy: 128,
  oldlace: 16643558,
  olive: 8421376,
  olivedrab: 7048739,
  orange: 16753920,
  orangered: 16729344,
  orchid: 14315734,
  palegoldenrod: 15657130,
  palegreen: 10025880,
  paleturquoise: 11529966,
  palevioletred: 14381203,
  papayawhip: 16773077,
  peachpuff: 16767673,
  peru: 13468991,
  pink: 16761035,
  plum: 14524637,
  powderblue: 11591910,
  purple: 8388736,
  rebeccapurple: 6697881,
  red: 16711680,
  rosybrown: 12357519,
  royalblue: 4286945,
  saddlebrown: 9127187,
  salmon: 16416882,
  sandybrown: 16032864,
  seagreen: 3050327,
  seashell: 16774638,
  sienna: 10506797,
  silver: 12632256,
  skyblue: 8900331,
  slateblue: 6970061,
  slategray: 7372944,
  slategrey: 7372944,
  snow: 16775930,
  springgreen: 65407,
  steelblue: 4620980,
  tan: 13808780,
  teal: 32896,
  thistle: 14204888,
  tomato: 16737095,
  turquoise: 4251856,
  violet: 15631086,
  wheat: 16113331,
  white: 16777215,
  whitesmoke: 16119285,
  yellow: 16776960,
  yellowgreen: 10145074
};
_s(pi, ti, {
  copy(e) {
    return Object.assign(new this.constructor(), this, e);
  },
  displayable() {
    return this.rgb().displayable();
  },
  hex: So,
  // Deprecated! Use color.formatHex.
  formatHex: So,
  formatHex8: Km,
  formatHsl: Qm,
  formatRgb: To,
  toString: To
});
function So() {
  return this.rgb().formatHex();
}
function Km() {
  return this.rgb().formatHex8();
}
function Qm() {
  return bc(this).formatHsl();
}
function To() {
  return this.rgb().formatRgb();
}
function ti(e) {
  var t, r;
  return e = (e + "").trim().toLowerCase(), (t = jm.exec(e)) ? (r = t[1].length, t = parseInt(t[1], 16), r === 6 ? Bo(t) : r === 3 ? new Pt(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, (t & 15) << 4 | t & 15, 1) : r === 8 ? wi(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (t & 255) / 255) : r === 4 ? wi(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | t & 240, ((t & 15) << 4 | t & 15) / 255) : null) : (t = Ym.exec(e)) ? new Pt(t[1], t[2], t[3], 1) : (t = Gm.exec(e)) ? new Pt(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, 1) : (t = Um.exec(e)) ? wi(t[1], t[2], t[3], t[4]) : (t = Xm.exec(e)) ? wi(t[1] * 255 / 100, t[2] * 255 / 100, t[3] * 255 / 100, t[4]) : (t = Vm.exec(e)) ? $o(t[1], t[2] / 100, t[3] / 100, 1) : (t = Zm.exec(e)) ? $o(t[1], t[2] / 100, t[3] / 100, t[4]) : ko.hasOwnProperty(e) ? Bo(ko[e]) : e === "transparent" ? new Pt(NaN, NaN, NaN, 0) : null;
}
function Bo(e) {
  return new Pt(e >> 16 & 255, e >> 8 & 255, e & 255, 1);
}
function wi(e, t, r, i) {
  return i <= 0 && (e = t = r = NaN), new Pt(e, t, r, i);
}
function Jm(e) {
  return e instanceof pi || (e = ti(e)), e ? (e = e.rgb(), new Pt(e.r, e.g, e.b, e.opacity)) : new Pt();
}
function va(e, t, r, i) {
  return arguments.length === 1 ? Jm(e) : new Pt(e, t, r, i ?? 1);
}
function Pt(e, t, r, i) {
  this.r = +e, this.g = +t, this.b = +r, this.opacity = +i;
}
_s(Pt, va, xc(pi, {
  brighter(e) {
    return e = e == null ? Zi : Math.pow(Zi, e), new Pt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Qr : Math.pow(Qr, e), new Pt(this.r * e, this.g * e, this.b * e, this.opacity);
  },
  rgb() {
    return this;
  },
  clamp() {
    return new Pt(Ne(this.r), Ne(this.g), Ne(this.b), Ki(this.opacity));
  },
  displayable() {
    return -0.5 <= this.r && this.r < 255.5 && -0.5 <= this.g && this.g < 255.5 && -0.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1;
  },
  hex: Lo,
  // Deprecated! Use color.formatHex.
  formatHex: Lo,
  formatHex8: ty,
  formatRgb: Mo,
  toString: Mo
}));
function Lo() {
  return `#${Oe(this.r)}${Oe(this.g)}${Oe(this.b)}`;
}
function ty() {
  return `#${Oe(this.r)}${Oe(this.g)}${Oe(this.b)}${Oe((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`;
}
function Mo() {
  const e = Ki(this.opacity);
  return `${e === 1 ? "rgb(" : "rgba("}${Ne(this.r)}, ${Ne(this.g)}, ${Ne(this.b)}${e === 1 ? ")" : `, ${e})`}`;
}
function Ki(e) {
  return isNaN(e) ? 1 : Math.max(0, Math.min(1, e));
}
function Ne(e) {
  return Math.max(0, Math.min(255, Math.round(e) || 0));
}
function Oe(e) {
  return e = Ne(e), (e < 16 ? "0" : "") + e.toString(16);
}
function $o(e, t, r, i) {
  return i <= 0 ? e = t = r = NaN : r <= 0 || r >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new Gt(e, t, r, i);
}
function bc(e) {
  if (e instanceof Gt) return new Gt(e.h, e.s, e.l, e.opacity);
  if (e instanceof pi || (e = ti(e)), !e) return new Gt();
  if (e instanceof Gt) return e;
  e = e.rgb();
  var t = e.r / 255, r = e.g / 255, i = e.b / 255, n = Math.min(t, r, i), a = Math.max(t, r, i), o = NaN, s = a - n, l = (a + n) / 2;
  return s ? (t === a ? o = (r - i) / s + (r < i) * 6 : r === a ? o = (i - t) / s + 2 : o = (t - r) / s + 4, s /= l < 0.5 ? a + n : 2 - a - n, o *= 60) : s = l > 0 && l < 1 ? 0 : o, new Gt(o, s, l, e.opacity);
}
function ey(e, t, r, i) {
  return arguments.length === 1 ? bc(e) : new Gt(e, t, r, i ?? 1);
}
function Gt(e, t, r, i) {
  this.h = +e, this.s = +t, this.l = +r, this.opacity = +i;
}
_s(Gt, ey, xc(pi, {
  brighter(e) {
    return e = e == null ? Zi : Math.pow(Zi, e), new Gt(this.h, this.s, this.l * e, this.opacity);
  },
  darker(e) {
    return e = e == null ? Qr : Math.pow(Qr, e), new Gt(this.h, this.s, this.l * e, this.opacity);
  },
  rgb() {
    var e = this.h % 360 + (this.h < 0) * 360, t = isNaN(e) || isNaN(this.s) ? 0 : this.s, r = this.l, i = r + (r < 0.5 ? r : 1 - r) * t, n = 2 * r - i;
    return new Pt(
      ea(e >= 240 ? e - 240 : e + 120, n, i),
      ea(e, n, i),
      ea(e < 120 ? e + 240 : e - 120, n, i),
      this.opacity
    );
  },
  clamp() {
    return new Gt(Ao(this.h), _i(this.s), _i(this.l), Ki(this.opacity));
  },
  displayable() {
    return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1;
  },
  formatHsl() {
    const e = Ki(this.opacity);
    return `${e === 1 ? "hsl(" : "hsla("}${Ao(this.h)}, ${_i(this.s) * 100}%, ${_i(this.l) * 100}%${e === 1 ? ")" : `, ${e})`}`;
  }
}));
function Ao(e) {
  return e = (e || 0) % 360, e < 0 ? e + 360 : e;
}
function _i(e) {
  return Math.max(0, Math.min(1, e || 0));
}
function ea(e, t, r) {
  return (e < 60 ? t + (r - t) * e / 60 : e < 180 ? r : e < 240 ? t + (r - t) * (240 - e) / 60 : t) * 255;
}
const vs = (e) => () => e;
function Cc(e, t) {
  return function(r) {
    return e + r * t;
  };
}
function ry(e, t, r) {
  return e = Math.pow(e, r), t = Math.pow(t, r) - e, r = 1 / r, function(i) {
    return Math.pow(e + i * t, r);
  };
}
function DT(e, t) {
  var r = t - e;
  return r ? Cc(e, r > 180 || r < -180 ? r - 360 * Math.round(r / 360) : r) : vs(isNaN(e) ? t : e);
}
function iy(e) {
  return (e = +e) == 1 ? wc : function(t, r) {
    return r - t ? ry(t, r, e) : vs(isNaN(t) ? r : t);
  };
}
function wc(e, t) {
  var r = t - e;
  return r ? Cc(e, r) : vs(isNaN(e) ? t : e);
}
const Fo = function e(t) {
  var r = iy(t);
  function i(n, a) {
    var o = r((n = va(n)).r, (a = va(a)).r), s = r(n.g, a.g), l = r(n.b, a.b), c = wc(n.opacity, a.opacity);
    return function(h) {
      return n.r = o(h), n.g = s(h), n.b = l(h), n.opacity = c(h), n + "";
    };
  }
  return i.gamma = e, i;
}(1);
function be(e, t) {
  return e = +e, t = +t, function(r) {
    return e * (1 - r) + t * r;
  };
}
var ka = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, ra = new RegExp(ka.source, "g");
function ny(e) {
  return function() {
    return e;
  };
}
function ay(e) {
  return function(t) {
    return e(t) + "";
  };
}
function sy(e, t) {
  var r = ka.lastIndex = ra.lastIndex = 0, i, n, a, o = -1, s = [], l = [];
  for (e = e + "", t = t + ""; (i = ka.exec(e)) && (n = ra.exec(t)); )
    (a = n.index) > r && (a = t.slice(r, a), s[o] ? s[o] += a : s[++o] = a), (i = i[0]) === (n = n[0]) ? s[o] ? s[o] += n : s[++o] = n : (s[++o] = null, l.push({ i: o, x: be(i, n) })), r = ra.lastIndex;
  return r < t.length && (a = t.slice(r), s[o] ? s[o] += a : s[++o] = a), s.length < 2 ? l[0] ? ay(l[0].x) : ny(t) : (t = l.length, function(c) {
    for (var h = 0, u; h < t; ++h) s[(u = l[h]).i] = u.x(c);
    return s.join("");
  });
}
var Eo = 180 / Math.PI, Sa = {
  translateX: 0,
  translateY: 0,
  rotate: 0,
  skewX: 0,
  scaleX: 1,
  scaleY: 1
};
function _c(e, t, r, i, n, a) {
  var o, s, l;
  return (o = Math.sqrt(e * e + t * t)) && (e /= o, t /= o), (l = e * r + t * i) && (r -= e * l, i -= t * l), (s = Math.sqrt(r * r + i * i)) && (r /= s, i /= s, l /= s), e * i < t * r && (e = -e, t = -t, l = -l, o = -o), {
    translateX: n,
    translateY: a,
    rotate: Math.atan2(t, e) * Eo,
    skewX: Math.atan(l) * Eo,
    scaleX: o,
    scaleY: s
  };
}
var vi;
function oy(e) {
  const t = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(e + "");
  return t.isIdentity ? Sa : _c(t.a, t.b, t.c, t.d, t.e, t.f);
}
function ly(e) {
  return e == null || (vi || (vi = document.createElementNS("http://www.w3.org/2000/svg", "g")), vi.setAttribute("transform", e), !(e = vi.transform.baseVal.consolidate())) ? Sa : (e = e.matrix, _c(e.a, e.b, e.c, e.d, e.e, e.f));
}
function vc(e, t, r, i) {
  function n(c) {
    return c.length ? c.pop() + " " : "";
  }
  function a(c, h, u, f, d, g) {
    if (c !== u || h !== f) {
      var m = d.push("translate(", null, t, null, r);
      g.push({ i: m - 4, x: be(c, u) }, { i: m - 2, x: be(h, f) });
    } else (u || f) && d.push("translate(" + u + t + f + r);
  }
  function o(c, h, u, f) {
    c !== h ? (c - h > 180 ? h += 360 : h - c > 180 && (c += 360), f.push({ i: u.push(n(u) + "rotate(", null, i) - 2, x: be(c, h) })) : h && u.push(n(u) + "rotate(" + h + i);
  }
  function s(c, h, u, f) {
    c !== h ? f.push({ i: u.push(n(u) + "skewX(", null, i) - 2, x: be(c, h) }) : h && u.push(n(u) + "skewX(" + h + i);
  }
  function l(c, h, u, f, d, g) {
    if (c !== u || h !== f) {
      var m = d.push(n(d) + "scale(", null, ",", null, ")");
      g.push({ i: m - 4, x: be(c, u) }, { i: m - 2, x: be(h, f) });
    } else (u !== 1 || f !== 1) && d.push(n(d) + "scale(" + u + "," + f + ")");
  }
  return function(c, h) {
    var u = [], f = [];
    return c = e(c), h = e(h), a(c.translateX, c.translateY, h.translateX, h.translateY, u, f), o(c.rotate, h.rotate, u, f), s(c.skewX, h.skewX, u, f), l(c.scaleX, c.scaleY, h.scaleX, h.scaleY, u, f), c = h = null, function(d) {
      for (var g = -1, m = f.length, x; ++g < m; ) u[(x = f[g]).i] = x.x(d);
      return u.join("");
    };
  };
}
var cy = vc(oy, "px, ", "px)", "deg)"), hy = vc(ly, ", ", ")", ")"), br = 0, Nr = 0, Ar = 0, kc = 1e3, Qi, zr, Ji = 0, He = 0, Fn = 0, ei = typeof performance == "object" && performance.now ? performance : Date, Sc = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
  setTimeout(e, 17);
};
function ks() {
  return He || (Sc(uy), He = ei.now() + Fn);
}
function uy() {
  He = 0;
}
function tn() {
  this._call = this._time = this._next = null;
}
tn.prototype = Tc.prototype = {
  constructor: tn,
  restart: function(e, t, r) {
    if (typeof e != "function") throw new TypeError("callback is not a function");
    r = (r == null ? ks() : +r) + (t == null ? 0 : +t), !this._next && zr !== this && (zr ? zr._next = this : Qi = this, zr = this), this._call = e, this._time = r, Ta();
  },
  stop: function() {
    this._call && (this._call = null, this._time = 1 / 0, Ta());
  }
};
function Tc(e, t, r) {
  var i = new tn();
  return i.restart(e, t, r), i;
}
function fy() {
  ks(), ++br;
  for (var e = Qi, t; e; )
    (t = He - e._time) >= 0 && e._call.call(void 0, t), e = e._next;
  --br;
}
function Do() {
  He = (Ji = ei.now()) + Fn, br = Nr = 0;
  try {
    fy();
  } finally {
    br = 0, py(), He = 0;
  }
}
function dy() {
  var e = ei.now(), t = e - Ji;
  t > kc && (Fn -= t, Ji = e);
}
function py() {
  for (var e, t = Qi, r, i = 1 / 0; t; )
    t._call ? (i > t._time && (i = t._time), e = t, t = t._next) : (r = t._next, t._next = null, t = e ? e._next = r : Qi = r);
  zr = e, Ta(i);
}
function Ta(e) {
  if (!br) {
    Nr && (Nr = clearTimeout(Nr));
    var t = e - He;
    t > 24 ? (e < 1 / 0 && (Nr = setTimeout(Do, e - ei.now() - Fn)), Ar && (Ar = clearInterval(Ar))) : (Ar || (Ji = ei.now(), Ar = setInterval(dy, kc)), br = 1, Sc(Do));
  }
}
function Oo(e, t, r) {
  var i = new tn();
  return t = t == null ? 0 : +t, i.restart((n) => {
    i.stop(), e(n + t);
  }, t, r), i;
}
var gy = ac("start", "end", "cancel", "interrupt"), my = [], Bc = 0, Ro = 1, Ba = 2, Ei = 3, Io = 4, La = 5, Di = 6;
function En(e, t, r, i, n, a) {
  var o = e.__transition;
  if (!o) e.__transition = {};
  else if (r in o) return;
  yy(e, r, {
    name: t,
    index: i,
    // For context during callback.
    group: n,
    // For context during callback.
    on: gy,
    tween: my,
    time: a.time,
    delay: a.delay,
    duration: a.duration,
    ease: a.ease,
    timer: null,
    state: Bc
  });
}
function Ss(e, t) {
  var r = Zt(e, t);
  if (r.state > Bc) throw new Error("too late; already scheduled");
  return r;
}
function ne(e, t) {
  var r = Zt(e, t);
  if (r.state > Ei) throw new Error("too late; already running");
  return r;
}
function Zt(e, t) {
  var r = e.__transition;
  if (!r || !(r = r[t])) throw new Error("transition not found");
  return r;
}
function yy(e, t, r) {
  var i = e.__transition, n;
  i[t] = r, r.timer = Tc(a, 0, r.time);
  function a(c) {
    r.state = Ro, r.timer.restart(o, r.delay, r.time), r.delay <= c && o(c - r.delay);
  }
  function o(c) {
    var h, u, f, d;
    if (r.state !== Ro) return l();
    for (h in i)
      if (d = i[h], d.name === r.name) {
        if (d.state === Ei) return Oo(o);
        d.state === Io ? (d.state = Di, d.timer.stop(), d.on.call("interrupt", e, e.__data__, d.index, d.group), delete i[h]) : +h < t && (d.state = Di, d.timer.stop(), d.on.call("cancel", e, e.__data__, d.index, d.group), delete i[h]);
      }
    if (Oo(function() {
      r.state === Ei && (r.state = Io, r.timer.restart(s, r.delay, r.time), s(c));
    }), r.state = Ba, r.on.call("start", e, e.__data__, r.index, r.group), r.state === Ba) {
      for (r.state = Ei, n = new Array(f = r.tween.length), h = 0, u = -1; h < f; ++h)
        (d = r.tween[h].value.call(e, e.__data__, r.index, r.group)) && (n[++u] = d);
      n.length = u + 1;
    }
  }
  function s(c) {
    for (var h = c < r.duration ? r.ease.call(null, c / r.duration) : (r.timer.restart(l), r.state = La, 1), u = -1, f = n.length; ++u < f; )
      n[u].call(e, h);
    r.state === La && (r.on.call("end", e, e.__data__, r.index, r.group), l());
  }
  function l() {
    r.state = Di, r.timer.stop(), delete i[t];
    for (var c in i) return;
    delete e.__transition;
  }
}
function xy(e, t) {
  var r = e.__transition, i, n, a = !0, o;
  if (r) {
    t = t == null ? null : t + "";
    for (o in r) {
      if ((i = r[o]).name !== t) {
        a = !1;
        continue;
      }
      n = i.state > Ba && i.state < La, i.state = Di, i.timer.stop(), i.on.call(n ? "interrupt" : "cancel", e, e.__data__, i.index, i.group), delete r[o];
    }
    a && delete e.__transition;
  }
}
function by(e) {
  return this.each(function() {
    xy(this, e);
  });
}
function Cy(e, t) {
  var r, i;
  return function() {
    var n = ne(this, e), a = n.tween;
    if (a !== r) {
      i = r = a;
      for (var o = 0, s = i.length; o < s; ++o)
        if (i[o].name === t) {
          i = i.slice(), i.splice(o, 1);
          break;
        }
    }
    n.tween = i;
  };
}
function wy(e, t, r) {
  var i, n;
  if (typeof r != "function") throw new Error();
  return function() {
    var a = ne(this, e), o = a.tween;
    if (o !== i) {
      n = (i = o).slice();
      for (var s = { name: t, value: r }, l = 0, c = n.length; l < c; ++l)
        if (n[l].name === t) {
          n[l] = s;
          break;
        }
      l === c && n.push(s);
    }
    a.tween = n;
  };
}
function _y(e, t) {
  var r = this._id;
  if (e += "", arguments.length < 2) {
    for (var i = Zt(this.node(), r).tween, n = 0, a = i.length, o; n < a; ++n)
      if ((o = i[n]).name === e)
        return o.value;
    return null;
  }
  return this.each((t == null ? Cy : wy)(r, e, t));
}
function Ts(e, t, r) {
  var i = e._id;
  return e.each(function() {
    var n = ne(this, i);
    (n.value || (n.value = {}))[t] = r.apply(this, arguments);
  }), function(n) {
    return Zt(n, i).value[t];
  };
}
function Lc(e, t) {
  var r;
  return (typeof t == "number" ? be : t instanceof ti ? Fo : (r = ti(t)) ? (t = r, Fo) : sy)(e, t);
}
function vy(e) {
  return function() {
    this.removeAttribute(e);
  };
}
function ky(e) {
  return function() {
    this.removeAttributeNS(e.space, e.local);
  };
}
function Sy(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttribute(e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function Ty(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = this.getAttributeNS(e.space, e.local);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function By(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttribute(e) : (o = this.getAttribute(e), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function Ly(e, t, r) {
  var i, n, a;
  return function() {
    var o, s = r(this), l;
    return s == null ? void this.removeAttributeNS(e.space, e.local) : (o = this.getAttributeNS(e.space, e.local), l = s + "", o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s)));
  };
}
function My(e, t) {
  var r = An(e), i = r === "transform" ? hy : Lc;
  return this.attrTween(e, typeof t == "function" ? (r.local ? Ly : By)(r, i, Ts(this, "attr." + e, t)) : t == null ? (r.local ? ky : vy)(r) : (r.local ? Ty : Sy)(r, i, t));
}
function $y(e, t) {
  return function(r) {
    this.setAttribute(e, t.call(this, r));
  };
}
function Ay(e, t) {
  return function(r) {
    this.setAttributeNS(e.space, e.local, t.call(this, r));
  };
}
function Fy(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && Ay(e, a)), r;
  }
  return n._value = t, n;
}
function Ey(e, t) {
  var r, i;
  function n() {
    var a = t.apply(this, arguments);
    return a !== i && (r = (i = a) && $y(e, a)), r;
  }
  return n._value = t, n;
}
function Dy(e, t) {
  var r = "attr." + e;
  if (arguments.length < 2) return (r = this.tween(r)) && r._value;
  if (t == null) return this.tween(r, null);
  if (typeof t != "function") throw new Error();
  var i = An(e);
  return this.tween(r, (i.local ? Fy : Ey)(i, t));
}
function Oy(e, t) {
  return function() {
    Ss(this, e).delay = +t.apply(this, arguments);
  };
}
function Ry(e, t) {
  return t = +t, function() {
    Ss(this, e).delay = t;
  };
}
function Iy(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Oy : Ry)(t, e)) : Zt(this.node(), t).delay;
}
function Py(e, t) {
  return function() {
    ne(this, e).duration = +t.apply(this, arguments);
  };
}
function Ny(e, t) {
  return t = +t, function() {
    ne(this, e).duration = t;
  };
}
function zy(e) {
  var t = this._id;
  return arguments.length ? this.each((typeof e == "function" ? Py : Ny)(t, e)) : Zt(this.node(), t).duration;
}
function qy(e, t) {
  if (typeof t != "function") throw new Error();
  return function() {
    ne(this, e).ease = t;
  };
}
function Wy(e) {
  var t = this._id;
  return arguments.length ? this.each(qy(t, e)) : Zt(this.node(), t).ease;
}
function Hy(e, t) {
  return function() {
    var r = t.apply(this, arguments);
    if (typeof r != "function") throw new Error();
    ne(this, e).ease = r;
  };
}
function jy(e) {
  if (typeof e != "function") throw new Error();
  return this.each(Hy(this._id, e));
}
function Yy(e) {
  typeof e != "function" && (e = lc(e));
  for (var t = this._groups, r = t.length, i = new Array(r), n = 0; n < r; ++n)
    for (var a = t[n], o = a.length, s = i[n] = [], l, c = 0; c < o; ++c)
      (l = a[c]) && e.call(l, l.__data__, c, a) && s.push(l);
  return new pe(i, this._parents, this._name, this._id);
}
function Gy(e) {
  if (e._id !== this._id) throw new Error();
  for (var t = this._groups, r = e._groups, i = t.length, n = r.length, a = Math.min(i, n), o = new Array(i), s = 0; s < a; ++s)
    for (var l = t[s], c = r[s], h = l.length, u = o[s] = new Array(h), f, d = 0; d < h; ++d)
      (f = l[d] || c[d]) && (u[d] = f);
  for (; s < i; ++s)
    o[s] = t[s];
  return new pe(o, this._parents, this._name, this._id);
}
function Uy(e) {
  return (e + "").trim().split(/^|\s+/).every(function(t) {
    var r = t.indexOf(".");
    return r >= 0 && (t = t.slice(0, r)), !t || t === "start";
  });
}
function Xy(e, t, r) {
  var i, n, a = Uy(t) ? Ss : ne;
  return function() {
    var o = a(this, e), s = o.on;
    s !== i && (n = (i = s).copy()).on(t, r), o.on = n;
  };
}
function Vy(e, t) {
  var r = this._id;
  return arguments.length < 2 ? Zt(this.node(), r).on.on(e) : this.each(Xy(r, e, t));
}
function Zy(e) {
  return function() {
    var t = this.parentNode;
    for (var r in this.__transition) if (+r !== e) return;
    t && t.removeChild(this);
  };
}
function Ky() {
  return this.on("end.remove", Zy(this._id));
}
function Qy(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = Cs(e));
  for (var i = this._groups, n = i.length, a = new Array(n), o = 0; o < n; ++o)
    for (var s = i[o], l = s.length, c = a[o] = new Array(l), h, u, f = 0; f < l; ++f)
      (h = s[f]) && (u = e.call(h, h.__data__, f, s)) && ("__data__" in h && (u.__data__ = h.__data__), c[f] = u, En(c[f], t, r, f, c, Zt(h, r)));
  return new pe(a, this._parents, t, r);
}
function Jy(e) {
  var t = this._name, r = this._id;
  typeof e != "function" && (e = oc(e));
  for (var i = this._groups, n = i.length, a = [], o = [], s = 0; s < n; ++s)
    for (var l = i[s], c = l.length, h, u = 0; u < c; ++u)
      if (h = l[u]) {
        for (var f = e.call(h, h.__data__, u, l), d, g = Zt(h, r), m = 0, x = f.length; m < x; ++m)
          (d = f[m]) && En(d, t, r, m, f, g);
        a.push(f), o.push(h);
      }
  return new pe(a, o, t, r);
}
var tx = di.prototype.constructor;
function ex() {
  return new tx(this._groups, this._parents);
}
function rx(e, t) {
  var r, i, n;
  return function() {
    var a = xr(this, e), o = (this.style.removeProperty(e), xr(this, e));
    return a === o ? null : a === r && o === i ? n : n = t(r = a, i = o);
  };
}
function Mc(e) {
  return function() {
    this.style.removeProperty(e);
  };
}
function ix(e, t, r) {
  var i, n = r + "", a;
  return function() {
    var o = xr(this, e);
    return o === n ? null : o === i ? a : a = t(i = o, r);
  };
}
function nx(e, t, r) {
  var i, n, a;
  return function() {
    var o = xr(this, e), s = r(this), l = s + "";
    return s == null && (l = s = (this.style.removeProperty(e), xr(this, e))), o === l ? null : o === i && l === n ? a : (n = l, a = t(i = o, s));
  };
}
function ax(e, t) {
  var r, i, n, a = "style." + t, o = "end." + a, s;
  return function() {
    var l = ne(this, e), c = l.on, h = l.value[a] == null ? s || (s = Mc(t)) : void 0;
    (c !== r || n !== h) && (i = (r = c).copy()).on(o, n = h), l.on = i;
  };
}
function sx(e, t, r) {
  var i = (e += "") == "transform" ? cy : Lc;
  return t == null ? this.styleTween(e, rx(e, i)).on("end.style." + e, Mc(e)) : typeof t == "function" ? this.styleTween(e, nx(e, i, Ts(this, "style." + e, t))).each(ax(this._id, e)) : this.styleTween(e, ix(e, i, t), r).on("end.style." + e, null);
}
function ox(e, t, r) {
  return function(i) {
    this.style.setProperty(e, t.call(this, i), r);
  };
}
function lx(e, t, r) {
  var i, n;
  function a() {
    var o = t.apply(this, arguments);
    return o !== n && (i = (n = o) && ox(e, o, r)), i;
  }
  return a._value = t, a;
}
function cx(e, t, r) {
  var i = "style." + (e += "");
  if (arguments.length < 2) return (i = this.tween(i)) && i._value;
  if (t == null) return this.tween(i, null);
  if (typeof t != "function") throw new Error();
  return this.tween(i, lx(e, t, r ?? ""));
}
function hx(e) {
  return function() {
    this.textContent = e;
  };
}
function ux(e) {
  return function() {
    var t = e(this);
    this.textContent = t ?? "";
  };
}
function fx(e) {
  return this.tween("text", typeof e == "function" ? ux(Ts(this, "text", e)) : hx(e == null ? "" : e + ""));
}
function dx(e) {
  return function(t) {
    this.textContent = e.call(this, t);
  };
}
function px(e) {
  var t, r;
  function i() {
    var n = e.apply(this, arguments);
    return n !== r && (t = (r = n) && dx(n)), t;
  }
  return i._value = e, i;
}
function gx(e) {
  var t = "text";
  if (arguments.length < 1) return (t = this.tween(t)) && t._value;
  if (e == null) return this.tween(t, null);
  if (typeof e != "function") throw new Error();
  return this.tween(t, px(e));
}
function mx() {
  for (var e = this._name, t = this._id, r = $c(), i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      if (l = o[c]) {
        var h = Zt(l, t);
        En(l, e, r, c, o, {
          time: h.time + h.delay + h.duration,
          delay: 0,
          duration: h.duration,
          ease: h.ease
        });
      }
  return new pe(i, this._parents, e, r);
}
function yx() {
  var e, t, r = this, i = r._id, n = r.size();
  return new Promise(function(a, o) {
    var s = { value: o }, l = { value: function() {
      --n === 0 && a();
    } };
    r.each(function() {
      var c = ne(this, i), h = c.on;
      h !== e && (t = (e = h).copy(), t._.cancel.push(s), t._.interrupt.push(s), t._.end.push(l)), c.on = t;
    }), n === 0 && a();
  });
}
var xx = 0;
function pe(e, t, r, i) {
  this._groups = e, this._parents = t, this._name = r, this._id = i;
}
function $c() {
  return ++xx;
}
var oe = di.prototype;
pe.prototype = {
  constructor: pe,
  select: Qy,
  selectAll: Jy,
  selectChild: oe.selectChild,
  selectChildren: oe.selectChildren,
  filter: Yy,
  merge: Gy,
  selection: ex,
  transition: mx,
  call: oe.call,
  nodes: oe.nodes,
  node: oe.node,
  size: oe.size,
  empty: oe.empty,
  each: oe.each,
  on: Vy,
  attr: My,
  attrTween: Dy,
  style: sx,
  styleTween: cx,
  text: fx,
  textTween: gx,
  remove: Ky,
  tween: _y,
  delay: Iy,
  duration: zy,
  ease: Wy,
  easeVarying: jy,
  end: yx,
  [Symbol.iterator]: oe[Symbol.iterator]
};
function bx(e) {
  return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2;
}
var Cx = {
  time: null,
  // Set on use.
  delay: 0,
  duration: 250,
  ease: bx
};
function wx(e, t) {
  for (var r; !(r = e.__transition) || !(r = r[t]); )
    if (!(e = e.parentNode))
      throw new Error(`transition ${t} not found`);
  return r;
}
function _x(e) {
  var t, r;
  e instanceof pe ? (t = e._id, e = e._name) : (t = $c(), (r = Cx).time = ks(), e = e == null ? null : e + "");
  for (var i = this._groups, n = i.length, a = 0; a < n; ++a)
    for (var o = i[a], s = o.length, l, c = 0; c < s; ++c)
      (l = o[c]) && En(l, e, t, c, o, r || wx(l, t));
  return new pe(i, this._parents, e, t);
}
di.prototype.interrupt = by;
di.prototype.transition = _x;
const Ma = Math.PI, $a = 2 * Ma, Ae = 1e-6, vx = $a - Ae;
function Ac(e) {
  this._ += e[0];
  for (let t = 1, r = e.length; t < r; ++t)
    this._ += arguments[t] + e[t];
}
function kx(e) {
  let t = Math.floor(e);
  if (!(t >= 0)) throw new Error(`invalid digits: ${e}`);
  if (t > 15) return Ac;
  const r = 10 ** t;
  return function(i) {
    this._ += i[0];
    for (let n = 1, a = i.length; n < a; ++n)
      this._ += Math.round(arguments[n] * r) / r + i[n];
  };
}
class Sx {
  constructor(t) {
    this._x0 = this._y0 = // start of current subpath
    this._x1 = this._y1 = null, this._ = "", this._append = t == null ? Ac : kx(t);
  }
  moveTo(t, r) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}`;
  }
  closePath() {
    this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append`Z`);
  }
  lineTo(t, r) {
    this._append`L${this._x1 = +t},${this._y1 = +r}`;
  }
  quadraticCurveTo(t, r, i, n) {
    this._append`Q${+t},${+r},${this._x1 = +i},${this._y1 = +n}`;
  }
  bezierCurveTo(t, r, i, n, a, o) {
    this._append`C${+t},${+r},${+i},${+n},${this._x1 = +a},${this._y1 = +o}`;
  }
  arcTo(t, r, i, n, a) {
    if (t = +t, r = +r, i = +i, n = +n, a = +a, a < 0) throw new Error(`negative radius: ${a}`);
    let o = this._x1, s = this._y1, l = i - t, c = n - r, h = o - t, u = s - r, f = h * h + u * u;
    if (this._x1 === null)
      this._append`M${this._x1 = t},${this._y1 = r}`;
    else if (f > Ae) if (!(Math.abs(u * l - c * h) > Ae) || !a)
      this._append`L${this._x1 = t},${this._y1 = r}`;
    else {
      let d = i - o, g = n - s, m = l * l + c * c, x = d * d + g * g, y = Math.sqrt(m), b = Math.sqrt(f), w = a * Math.tan((Ma - Math.acos((m + f - x) / (2 * y * b))) / 2), k = w / b, _ = w / y;
      Math.abs(k - 1) > Ae && this._append`L${t + k * h},${r + k * u}`, this._append`A${a},${a},0,0,${+(u * d > h * g)},${this._x1 = t + _ * l},${this._y1 = r + _ * c}`;
    }
  }
  arc(t, r, i, n, a, o) {
    if (t = +t, r = +r, i = +i, o = !!o, i < 0) throw new Error(`negative radius: ${i}`);
    let s = i * Math.cos(n), l = i * Math.sin(n), c = t + s, h = r + l, u = 1 ^ o, f = o ? n - a : a - n;
    this._x1 === null ? this._append`M${c},${h}` : (Math.abs(this._x1 - c) > Ae || Math.abs(this._y1 - h) > Ae) && this._append`L${c},${h}`, i && (f < 0 && (f = f % $a + $a), f > vx ? this._append`A${i},${i},0,1,${u},${t - s},${r - l}A${i},${i},0,1,${u},${this._x1 = c},${this._y1 = h}` : f > Ae && this._append`A${i},${i},0,${+(f >= Ma)},${u},${this._x1 = t + i * Math.cos(a)},${this._y1 = r + i * Math.sin(a)}`);
  }
  rect(t, r, i, n) {
    this._append`M${this._x0 = this._x1 = +t},${this._y0 = this._y1 = +r}h${i = +i}v${+n}h${-i}Z`;
  }
  toString() {
    return this._;
  }
}
function Je(e) {
  return function() {
    return e;
  };
}
const OT = Math.abs, RT = Math.atan2, IT = Math.cos, PT = Math.max, NT = Math.min, zT = Math.sin, qT = Math.sqrt, Po = 1e-12, Bs = Math.PI, No = Bs / 2, WT = 2 * Bs;
function HT(e) {
  return e > 1 ? 0 : e < -1 ? Bs : Math.acos(e);
}
function jT(e) {
  return e >= 1 ? No : e <= -1 ? -No : Math.asin(e);
}
function Tx(e) {
  let t = 3;
  return e.digits = function(r) {
    if (!arguments.length) return t;
    if (r == null)
      t = null;
    else {
      const i = Math.floor(r);
      if (!(i >= 0)) throw new RangeError(`invalid digits: ${r}`);
      t = i;
    }
    return e;
  }, () => new Sx(t);
}
function Bx(e) {
  return typeof e == "object" && "length" in e ? e : Array.from(e);
}
function Fc(e) {
  this._context = e;
}
Fc.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default:
        this._context.lineTo(e, t);
        break;
    }
  }
};
function en(e) {
  return new Fc(e);
}
function Lx(e) {
  return e[0];
}
function Mx(e) {
  return e[1];
}
function $x(e, t) {
  var r = Je(!0), i = null, n = en, a = null, o = Tx(s);
  e = typeof e == "function" ? e : e === void 0 ? Lx : Je(e), t = typeof t == "function" ? t : t === void 0 ? Mx : Je(t);
  function s(l) {
    var c, h = (l = Bx(l)).length, u, f = !1, d;
    for (i == null && (a = n(d = o())), c = 0; c <= h; ++c)
      !(c < h && r(u = l[c], c, l)) === f && ((f = !f) ? a.lineStart() : a.lineEnd()), f && a.point(+e(u, c, l), +t(u, c, l));
    if (d) return a = null, d + "" || null;
  }
  return s.x = function(l) {
    return arguments.length ? (e = typeof l == "function" ? l : Je(+l), s) : e;
  }, s.y = function(l) {
    return arguments.length ? (t = typeof l == "function" ? l : Je(+l), s) : t;
  }, s.defined = function(l) {
    return arguments.length ? (r = typeof l == "function" ? l : Je(!!l), s) : r;
  }, s.curve = function(l) {
    return arguments.length ? (n = l, i != null && (a = n(i)), s) : n;
  }, s.context = function(l) {
    return arguments.length ? (l == null ? i = a = null : a = n(i = l), s) : i;
  }, s;
}
class Ec {
  constructor(t, r) {
    this._context = t, this._x = r;
  }
  areaStart() {
    this._line = 0;
  }
  areaEnd() {
    this._line = NaN;
  }
  lineStart() {
    this._point = 0;
  }
  lineEnd() {
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  }
  point(t, r) {
    switch (t = +t, r = +r, this._point) {
      case 0: {
        this._point = 1, this._line ? this._context.lineTo(t, r) : this._context.moveTo(t, r);
        break;
      }
      case 1:
        this._point = 2;
      default: {
        this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + t) / 2, this._y0, this._x0, r, t, r) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + r) / 2, t, this._y0, t, r);
        break;
      }
    }
    this._x0 = t, this._y0 = r;
  }
}
function Dc(e) {
  return new Ec(e, !0);
}
function Oc(e) {
  return new Ec(e, !1);
}
function _e() {
}
function rn(e, t, r) {
  e._context.bezierCurveTo(
    (2 * e._x0 + e._x1) / 3,
    (2 * e._y0 + e._y1) / 3,
    (e._x0 + 2 * e._x1) / 3,
    (e._y0 + 2 * e._y1) / 3,
    (e._x0 + 4 * e._x1 + t) / 6,
    (e._y0 + 4 * e._y1 + r) / 6
  );
}
function Dn(e) {
  this._context = e;
}
Dn.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 3:
        rn(this, this._x1, this._y1);
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
      default:
        rn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Oi(e) {
  return new Dn(e);
}
function Rc(e) {
  this._context = e;
}
Rc.prototype = {
  areaStart: _e,
  areaEnd: _e,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x2, this._y2), this._context.closePath();
        break;
      }
      case 2: {
        this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x2 = e, this._y2 = t;
        break;
      case 1:
        this._point = 2, this._x3 = e, this._y3 = t;
        break;
      case 2:
        this._point = 3, this._x4 = e, this._y4 = t, this._context.moveTo((this._x0 + 4 * this._x1 + e) / 6, (this._y0 + 4 * this._y1 + t) / 6);
        break;
      default:
        rn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Ax(e) {
  return new Rc(e);
}
function Ic(e) {
  this._context = e;
}
Ic.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
        var r = (this._x0 + 4 * this._x1 + e) / 6, i = (this._y0 + 4 * this._y1 + t) / 6;
        this._line ? this._context.lineTo(r, i) : this._context.moveTo(r, i);
        break;
      case 3:
        this._point = 4;
      default:
        rn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t;
  }
};
function Fx(e) {
  return new Ic(e);
}
function Pc(e, t) {
  this._basis = new Dn(e), this._beta = t;
}
Pc.prototype = {
  lineStart: function() {
    this._x = [], this._y = [], this._basis.lineStart();
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length - 1;
    if (r > 0)
      for (var i = e[0], n = t[0], a = e[r] - i, o = t[r] - n, s = -1, l; ++s <= r; )
        l = s / r, this._basis.point(
          this._beta * e[s] + (1 - this._beta) * (i + l * a),
          this._beta * t[s] + (1 - this._beta) * (n + l * o)
        );
    this._x = this._y = null, this._basis.lineEnd();
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
const Ex = function e(t) {
  function r(i) {
    return t === 1 ? new Dn(i) : new Pc(i, t);
  }
  return r.beta = function(i) {
    return e(+i);
  }, r;
}(0.85);
function nn(e, t, r) {
  e._context.bezierCurveTo(
    e._x1 + e._k * (e._x2 - e._x0),
    e._y1 + e._k * (e._y2 - e._y0),
    e._x2 + e._k * (e._x1 - t),
    e._y2 + e._k * (e._y1 - r),
    e._x2,
    e._y2
  );
}
function Ls(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Ls.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        nn(this, this._x1, this._y1);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2, this._x1 = e, this._y1 = t;
        break;
      case 2:
        this._point = 3;
      default:
        nn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Nc = function e(t) {
  function r(i) {
    return new Ls(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function Ms(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
Ms.prototype = {
  areaStart: _e,
  areaEnd: _e,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        nn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Dx = function e(t) {
  function r(i) {
    return new Ms(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function $s(e, t) {
  this._context = e, this._k = (1 - t) / 6;
}
$s.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        nn(this, e, t);
        break;
    }
    this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Ox = function e(t) {
  function r(i) {
    return new $s(i, t);
  }
  return r.tension = function(i) {
    return e(+i);
  }, r;
}(0);
function As(e, t, r) {
  var i = e._x1, n = e._y1, a = e._x2, o = e._y2;
  if (e._l01_a > Po) {
    var s = 2 * e._l01_2a + 3 * e._l01_a * e._l12_a + e._l12_2a, l = 3 * e._l01_a * (e._l01_a + e._l12_a);
    i = (i * s - e._x0 * e._l12_2a + e._x2 * e._l01_2a) / l, n = (n * s - e._y0 * e._l12_2a + e._y2 * e._l01_2a) / l;
  }
  if (e._l23_a > Po) {
    var c = 2 * e._l23_2a + 3 * e._l23_a * e._l12_a + e._l12_2a, h = 3 * e._l23_a * (e._l23_a + e._l12_a);
    a = (a * c + e._x1 * e._l23_2a - t * e._l12_2a) / h, o = (o * c + e._y1 * e._l23_2a - r * e._l12_2a) / h;
  }
  e._context.bezierCurveTo(i, n, a, o, e._x2, e._y2);
}
function zc(e, t) {
  this._context = e, this._alpha = t;
}
zc.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x2, this._y2);
        break;
      case 3:
        this.point(this._x2, this._y2);
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3;
      default:
        As(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const qc = function e(t) {
  function r(i) {
    return t ? new zc(i, t) : new Ls(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Wc(e, t) {
  this._context = e, this._alpha = t;
}
Wc.prototype = {
  areaStart: _e,
  areaEnd: _e,
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 1: {
        this._context.moveTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 2: {
        this._context.lineTo(this._x3, this._y3), this._context.closePath();
        break;
      }
      case 3: {
        this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
        break;
      }
    }
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1, this._x3 = e, this._y3 = t;
        break;
      case 1:
        this._point = 2, this._context.moveTo(this._x4 = e, this._y4 = t);
        break;
      case 2:
        this._point = 3, this._x5 = e, this._y5 = t;
        break;
      default:
        As(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Rx = function e(t) {
  function r(i) {
    return t ? new Wc(i, t) : new Ms(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function Hc(e, t) {
  this._context = e, this._alpha = t;
}
Hc.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0;
  },
  lineEnd: function() {
    (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    if (e = +e, t = +t, this._point) {
      var r = this._x2 - e, i = this._y2 - t;
      this._l23_a = Math.sqrt(this._l23_2a = Math.pow(r * r + i * i, this._alpha));
    }
    switch (this._point) {
      case 0:
        this._point = 1;
        break;
      case 1:
        this._point = 2;
        break;
      case 2:
        this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
        break;
      case 3:
        this._point = 4;
      default:
        As(this, e, t);
        break;
    }
    this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = e, this._y0 = this._y1, this._y1 = this._y2, this._y2 = t;
  }
};
const Ix = function e(t) {
  function r(i) {
    return t ? new Hc(i, t) : new $s(i, 0);
  }
  return r.alpha = function(i) {
    return e(+i);
  }, r;
}(0.5);
function jc(e) {
  this._context = e;
}
jc.prototype = {
  areaStart: _e,
  areaEnd: _e,
  lineStart: function() {
    this._point = 0;
  },
  lineEnd: function() {
    this._point && this._context.closePath();
  },
  point: function(e, t) {
    e = +e, t = +t, this._point ? this._context.lineTo(e, t) : (this._point = 1, this._context.moveTo(e, t));
  }
};
function Px(e) {
  return new jc(e);
}
function zo(e) {
  return e < 0 ? -1 : 1;
}
function qo(e, t, r) {
  var i = e._x1 - e._x0, n = t - e._x1, a = (e._y1 - e._y0) / (i || n < 0 && -0), o = (r - e._y1) / (n || i < 0 && -0), s = (a * n + o * i) / (i + n);
  return (zo(a) + zo(o)) * Math.min(Math.abs(a), Math.abs(o), 0.5 * Math.abs(s)) || 0;
}
function Wo(e, t) {
  var r = e._x1 - e._x0;
  return r ? (3 * (e._y1 - e._y0) / r - t) / 2 : t;
}
function ia(e, t, r) {
  var i = e._x0, n = e._y0, a = e._x1, o = e._y1, s = (a - i) / 3;
  e._context.bezierCurveTo(i + s, n + s * t, a - s, o - s * r, a, o);
}
function an(e) {
  this._context = e;
}
an.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0;
  },
  lineEnd: function() {
    switch (this._point) {
      case 2:
        this._context.lineTo(this._x1, this._y1);
        break;
      case 3:
        ia(this, this._t0, Wo(this, this._t0));
        break;
    }
    (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line;
  },
  point: function(e, t) {
    var r = NaN;
    if (e = +e, t = +t, !(e === this._x1 && t === this._y1)) {
      switch (this._point) {
        case 0:
          this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
          break;
        case 1:
          this._point = 2;
          break;
        case 2:
          this._point = 3, ia(this, Wo(this, r = qo(this, e, t)), r);
          break;
        default:
          ia(this, this._t0, r = qo(this, e, t));
          break;
      }
      this._x0 = this._x1, this._x1 = e, this._y0 = this._y1, this._y1 = t, this._t0 = r;
    }
  }
};
function Yc(e) {
  this._context = new Gc(e);
}
(Yc.prototype = Object.create(an.prototype)).point = function(e, t) {
  an.prototype.point.call(this, t, e);
};
function Gc(e) {
  this._context = e;
}
Gc.prototype = {
  moveTo: function(e, t) {
    this._context.moveTo(t, e);
  },
  closePath: function() {
    this._context.closePath();
  },
  lineTo: function(e, t) {
    this._context.lineTo(t, e);
  },
  bezierCurveTo: function(e, t, r, i, n, a) {
    this._context.bezierCurveTo(t, e, i, r, a, n);
  }
};
function Uc(e) {
  return new an(e);
}
function Xc(e) {
  return new Yc(e);
}
function Vc(e) {
  this._context = e;
}
Vc.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = [], this._y = [];
  },
  lineEnd: function() {
    var e = this._x, t = this._y, r = e.length;
    if (r)
      if (this._line ? this._context.lineTo(e[0], t[0]) : this._context.moveTo(e[0], t[0]), r === 2)
        this._context.lineTo(e[1], t[1]);
      else
        for (var i = Ho(e), n = Ho(t), a = 0, o = 1; o < r; ++a, ++o)
          this._context.bezierCurveTo(i[0][a], n[0][a], i[1][a], n[1][a], e[o], t[o]);
    (this._line || this._line !== 0 && r === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null;
  },
  point: function(e, t) {
    this._x.push(+e), this._y.push(+t);
  }
};
function Ho(e) {
  var t, r = e.length - 1, i, n = new Array(r), a = new Array(r), o = new Array(r);
  for (n[0] = 0, a[0] = 2, o[0] = e[0] + 2 * e[1], t = 1; t < r - 1; ++t) n[t] = 1, a[t] = 4, o[t] = 4 * e[t] + 2 * e[t + 1];
  for (n[r - 1] = 2, a[r - 1] = 7, o[r - 1] = 8 * e[r - 1] + e[r], t = 1; t < r; ++t) i = n[t] / a[t - 1], a[t] -= i, o[t] -= i * o[t - 1];
  for (n[r - 1] = o[r - 1] / a[r - 1], t = r - 2; t >= 0; --t) n[t] = (o[t] - n[t + 1]) / a[t];
  for (a[r - 1] = (e[r] + n[r - 1]) / 2, t = 0; t < r - 1; ++t) a[t] = 2 * e[t + 1] - n[t + 1];
  return [n, a];
}
function Zc(e) {
  return new Vc(e);
}
function On(e, t) {
  this._context = e, this._t = t;
}
On.prototype = {
  areaStart: function() {
    this._line = 0;
  },
  areaEnd: function() {
    this._line = NaN;
  },
  lineStart: function() {
    this._x = this._y = NaN, this._point = 0;
  },
  lineEnd: function() {
    0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line);
  },
  point: function(e, t) {
    switch (e = +e, t = +t, this._point) {
      case 0:
        this._point = 1, this._line ? this._context.lineTo(e, t) : this._context.moveTo(e, t);
        break;
      case 1:
        this._point = 2;
      default: {
        if (this._t <= 0)
          this._context.lineTo(this._x, t), this._context.lineTo(e, t);
        else {
          var r = this._x * (1 - this._t) + e * this._t;
          this._context.lineTo(r, this._y), this._context.lineTo(r, t);
        }
        break;
      }
    }
    this._x = e, this._y = t;
  }
};
function Kc(e) {
  return new On(e, 0.5);
}
function Qc(e) {
  return new On(e, 0);
}
function Jc(e) {
  return new On(e, 1);
}
function qr(e, t, r) {
  this.k = e, this.x = t, this.y = r;
}
qr.prototype = {
  constructor: qr,
  scale: function(e) {
    return e === 1 ? this : new qr(this.k * e, this.x, this.y);
  },
  translate: function(e, t) {
    return e === 0 & t === 0 ? this : new qr(this.k, this.x + this.k * e, this.y + this.k * t);
  },
  apply: function(e) {
    return [e[0] * this.k + this.x, e[1] * this.k + this.y];
  },
  applyX: function(e) {
    return e * this.k + this.x;
  },
  applyY: function(e) {
    return e * this.k + this.y;
  },
  invert: function(e) {
    return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k];
  },
  invertX: function(e) {
    return (e - this.x) / this.k;
  },
  invertY: function(e) {
    return (e - this.y) / this.k;
  },
  rescaleX: function(e) {
    return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e));
  },
  rescaleY: function(e) {
    return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e));
  },
  toString: function() {
    return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")";
  }
};
qr.prototype;
var Nx = /* @__PURE__ */ p((e) => {
  var n;
  const { securityLevel: t } = nt();
  let r = rt("body");
  if (t === "sandbox") {
    const o = ((n = rt(`#i${e}`).node()) == null ? void 0 : n.contentDocument) ?? document;
    r = rt(o.body);
  }
  return r.select(`#${e}`);
}, "selectSvgElement");
function Fs(e) {
  return typeof e > "u" || e === null;
}
p(Fs, "isNothing");
function th(e) {
  return typeof e == "object" && e !== null;
}
p(th, "isObject");
function eh(e) {
  return Array.isArray(e) ? e : Fs(e) ? [] : [e];
}
p(eh, "toArray");
function rh(e, t) {
  var r, i, n, a;
  if (t)
    for (a = Object.keys(t), r = 0, i = a.length; r < i; r += 1)
      n = a[r], e[n] = t[n];
  return e;
}
p(rh, "extend");
function ih(e, t) {
  var r = "", i;
  for (i = 0; i < t; i += 1)
    r += e;
  return r;
}
p(ih, "repeat");
function nh(e) {
  return e === 0 && Number.NEGATIVE_INFINITY === 1 / e;
}
p(nh, "isNegativeZero");
var zx = Fs, qx = th, Wx = eh, Hx = ih, jx = nh, Yx = rh, bt = {
  isNothing: zx,
  isObject: qx,
  toArray: Wx,
  repeat: Hx,
  isNegativeZero: jx,
  extend: Yx
};
function Es(e, t) {
  var r = "", i = e.reason || "(unknown reason)";
  return e.mark ? (e.mark.name && (r += 'in "' + e.mark.name + '" '), r += "(" + (e.mark.line + 1) + ":" + (e.mark.column + 1) + ")", !t && e.mark.snippet && (r += `

` + e.mark.snippet), i + " " + r) : i;
}
p(Es, "formatError");
function Cr(e, t) {
  Error.call(this), this.name = "YAMLException", this.reason = e, this.mark = t, this.message = Es(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || "";
}
p(Cr, "YAMLException$1");
Cr.prototype = Object.create(Error.prototype);
Cr.prototype.constructor = Cr;
Cr.prototype.toString = /* @__PURE__ */ p(function(t) {
  return this.name + ": " + Es(this, t);
}, "toString");
var It = Cr;
function Ri(e, t, r, i, n) {
  var a = "", o = "", s = Math.floor(n / 2) - 1;
  return i - t > s && (a = " ... ", t = i - s + a.length), r - i > s && (o = " ...", r = i + s - o.length), {
    str: a + e.slice(t, r).replace(/\t/g, "→") + o,
    pos: i - t + a.length
    // relative position
  };
}
p(Ri, "getLine");
function Ii(e, t) {
  return bt.repeat(" ", t - e.length) + e;
}
p(Ii, "padStart");
function ah(e, t) {
  if (t = Object.create(t || null), !e.buffer) return null;
  t.maxLength || (t.maxLength = 79), typeof t.indent != "number" && (t.indent = 1), typeof t.linesBefore != "number" && (t.linesBefore = 3), typeof t.linesAfter != "number" && (t.linesAfter = 2);
  for (var r = /\r?\n|\r|\0/g, i = [0], n = [], a, o = -1; a = r.exec(e.buffer); )
    n.push(a.index), i.push(a.index + a[0].length), e.position <= a.index && o < 0 && (o = i.length - 2);
  o < 0 && (o = i.length - 1);
  var s = "", l, c, h = Math.min(e.line + t.linesAfter, n.length).toString().length, u = t.maxLength - (t.indent + h + 3);
  for (l = 1; l <= t.linesBefore && !(o - l < 0); l++)
    c = Ri(
      e.buffer,
      i[o - l],
      n[o - l],
      e.position - (i[o] - i[o - l]),
      u
    ), s = bt.repeat(" ", t.indent) + Ii((e.line - l + 1).toString(), h) + " | " + c.str + `
` + s;
  for (c = Ri(e.buffer, i[o], n[o], e.position, u), s += bt.repeat(" ", t.indent) + Ii((e.line + 1).toString(), h) + " | " + c.str + `
`, s += bt.repeat("-", t.indent + h + 3 + c.pos) + `^
`, l = 1; l <= t.linesAfter && !(o + l >= n.length); l++)
    c = Ri(
      e.buffer,
      i[o + l],
      n[o + l],
      e.position - (i[o] - i[o + l]),
      u
    ), s += bt.repeat(" ", t.indent) + Ii((e.line + l + 1).toString(), h) + " | " + c.str + `
`;
  return s.replace(/\n$/, "");
}
p(ah, "makeSnippet");
var Gx = ah, Ux = [
  "kind",
  "multi",
  "resolve",
  "construct",
  "instanceOf",
  "predicate",
  "represent",
  "representName",
  "defaultStyle",
  "styleAliases"
], Xx = [
  "scalar",
  "sequence",
  "mapping"
];
function sh(e) {
  var t = {};
  return e !== null && Object.keys(e).forEach(function(r) {
    e[r].forEach(function(i) {
      t[String(i)] = r;
    });
  }), t;
}
p(sh, "compileStyleAliases");
function oh(e, t) {
  if (t = t || {}, Object.keys(t).forEach(function(r) {
    if (Ux.indexOf(r) === -1)
      throw new It('Unknown option "' + r + '" is met in definition of "' + e + '" YAML type.');
  }), this.options = t, this.tag = e, this.kind = t.kind || null, this.resolve = t.resolve || function() {
    return !0;
  }, this.construct = t.construct || function(r) {
    return r;
  }, this.instanceOf = t.instanceOf || null, this.predicate = t.predicate || null, this.represent = t.represent || null, this.representName = t.representName || null, this.defaultStyle = t.defaultStyle || null, this.multi = t.multi || !1, this.styleAliases = sh(t.styleAliases || null), Xx.indexOf(this.kind) === -1)
    throw new It('Unknown kind "' + this.kind + '" is specified for "' + e + '" YAML type.');
}
p(oh, "Type$1");
var Lt = oh;
function Aa(e, t) {
  var r = [];
  return e[t].forEach(function(i) {
    var n = r.length;
    r.forEach(function(a, o) {
      a.tag === i.tag && a.kind === i.kind && a.multi === i.multi && (n = o);
    }), r[n] = i;
  }), r;
}
p(Aa, "compileList");
function lh() {
  var e = {
    scalar: {},
    sequence: {},
    mapping: {},
    fallback: {},
    multi: {
      scalar: [],
      sequence: [],
      mapping: [],
      fallback: []
    }
  }, t, r;
  function i(n) {
    n.multi ? (e.multi[n.kind].push(n), e.multi.fallback.push(n)) : e[n.kind][n.tag] = e.fallback[n.tag] = n;
  }
  for (p(i, "collectType"), t = 0, r = arguments.length; t < r; t += 1)
    arguments[t].forEach(i);
  return e;
}
p(lh, "compileMap");
function sn(e) {
  return this.extend(e);
}
p(sn, "Schema$1");
sn.prototype.extend = /* @__PURE__ */ p(function(t) {
  var r = [], i = [];
  if (t instanceof Lt)
    i.push(t);
  else if (Array.isArray(t))
    i = i.concat(t);
  else if (t && (Array.isArray(t.implicit) || Array.isArray(t.explicit)))
    t.implicit && (r = r.concat(t.implicit)), t.explicit && (i = i.concat(t.explicit));
  else
    throw new It("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })");
  r.forEach(function(a) {
    if (!(a instanceof Lt))
      throw new It("Specified list of YAML types (or a single Type object) contains a non-Type object.");
    if (a.loadKind && a.loadKind !== "scalar")
      throw new It("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported.");
    if (a.multi)
      throw new It("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit.");
  }), i.forEach(function(a) {
    if (!(a instanceof Lt))
      throw new It("Specified list of YAML types (or a single Type object) contains a non-Type object.");
  });
  var n = Object.create(sn.prototype);
  return n.implicit = (this.implicit || []).concat(r), n.explicit = (this.explicit || []).concat(i), n.compiledImplicit = Aa(n, "implicit"), n.compiledExplicit = Aa(n, "explicit"), n.compiledTypeMap = lh(n.compiledImplicit, n.compiledExplicit), n;
}, "extend");
var Vx = sn, Zx = new Lt("tag:yaml.org,2002:str", {
  kind: "scalar",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : "";
  }, "construct")
}), Kx = new Lt("tag:yaml.org,2002:seq", {
  kind: "sequence",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : [];
  }, "construct")
}), Qx = new Lt("tag:yaml.org,2002:map", {
  kind: "mapping",
  construct: /* @__PURE__ */ p(function(e) {
    return e !== null ? e : {};
  }, "construct")
}), Jx = new Vx({
  explicit: [
    Zx,
    Kx,
    Qx
  ]
});
function ch(e) {
  if (e === null) return !0;
  var t = e.length;
  return t === 1 && e === "~" || t === 4 && (e === "null" || e === "Null" || e === "NULL");
}
p(ch, "resolveYamlNull");
function hh() {
  return null;
}
p(hh, "constructYamlNull");
function uh(e) {
  return e === null;
}
p(uh, "isNull");
var tb = new Lt("tag:yaml.org,2002:null", {
  kind: "scalar",
  resolve: ch,
  construct: hh,
  predicate: uh,
  represent: {
    canonical: /* @__PURE__ */ p(function() {
      return "~";
    }, "canonical"),
    lowercase: /* @__PURE__ */ p(function() {
      return "null";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ p(function() {
      return "NULL";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ p(function() {
      return "Null";
    }, "camelcase"),
    empty: /* @__PURE__ */ p(function() {
      return "";
    }, "empty")
  },
  defaultStyle: "lowercase"
});
function fh(e) {
  if (e === null) return !1;
  var t = e.length;
  return t === 4 && (e === "true" || e === "True" || e === "TRUE") || t === 5 && (e === "false" || e === "False" || e === "FALSE");
}
p(fh, "resolveYamlBoolean");
function dh(e) {
  return e === "true" || e === "True" || e === "TRUE";
}
p(dh, "constructYamlBoolean");
function ph(e) {
  return Object.prototype.toString.call(e) === "[object Boolean]";
}
p(ph, "isBoolean");
var eb = new Lt("tag:yaml.org,2002:bool", {
  kind: "scalar",
  resolve: fh,
  construct: dh,
  predicate: ph,
  represent: {
    lowercase: /* @__PURE__ */ p(function(e) {
      return e ? "true" : "false";
    }, "lowercase"),
    uppercase: /* @__PURE__ */ p(function(e) {
      return e ? "TRUE" : "FALSE";
    }, "uppercase"),
    camelcase: /* @__PURE__ */ p(function(e) {
      return e ? "True" : "False";
    }, "camelcase")
  },
  defaultStyle: "lowercase"
});
function gh(e) {
  return 48 <= e && e <= 57 || 65 <= e && e <= 70 || 97 <= e && e <= 102;
}
p(gh, "isHexCode");
function mh(e) {
  return 48 <= e && e <= 55;
}
p(mh, "isOctCode");
function yh(e) {
  return 48 <= e && e <= 57;
}
p(yh, "isDecCode");
function xh(e) {
  if (e === null) return !1;
  var t = e.length, r = 0, i = !1, n;
  if (!t) return !1;
  if (n = e[r], (n === "-" || n === "+") && (n = e[++r]), n === "0") {
    if (r + 1 === t) return !0;
    if (n = e[++r], n === "b") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (n !== "0" && n !== "1") return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "x") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!gh(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
    if (n === "o") {
      for (r++; r < t; r++)
        if (n = e[r], n !== "_") {
          if (!mh(e.charCodeAt(r))) return !1;
          i = !0;
        }
      return i && n !== "_";
    }
  }
  if (n === "_") return !1;
  for (; r < t; r++)
    if (n = e[r], n !== "_") {
      if (!yh(e.charCodeAt(r)))
        return !1;
      i = !0;
    }
  return !(!i || n === "_");
}
p(xh, "resolveYamlInteger");
function bh(e) {
  var t = e, r = 1, i;
  if (t.indexOf("_") !== -1 && (t = t.replace(/_/g, "")), i = t[0], (i === "-" || i === "+") && (i === "-" && (r = -1), t = t.slice(1), i = t[0]), t === "0") return 0;
  if (i === "0") {
    if (t[1] === "b") return r * parseInt(t.slice(2), 2);
    if (t[1] === "x") return r * parseInt(t.slice(2), 16);
    if (t[1] === "o") return r * parseInt(t.slice(2), 8);
  }
  return r * parseInt(t, 10);
}
p(bh, "constructYamlInteger");
function Ch(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && e % 1 === 0 && !bt.isNegativeZero(e);
}
p(Ch, "isInteger");
var rb = new Lt("tag:yaml.org,2002:int", {
  kind: "scalar",
  resolve: xh,
  construct: bh,
  predicate: Ch,
  represent: {
    binary: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0b" + e.toString(2) : "-0b" + e.toString(2).slice(1);
    }, "binary"),
    octal: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0o" + e.toString(8) : "-0o" + e.toString(8).slice(1);
    }, "octal"),
    decimal: /* @__PURE__ */ p(function(e) {
      return e.toString(10);
    }, "decimal"),
    /* eslint-disable max-len */
    hexadecimal: /* @__PURE__ */ p(function(e) {
      return e >= 0 ? "0x" + e.toString(16).toUpperCase() : "-0x" + e.toString(16).toUpperCase().slice(1);
    }, "hexadecimal")
  },
  defaultStyle: "decimal",
  styleAliases: {
    binary: [2, "bin"],
    octal: [8, "oct"],
    decimal: [10, "dec"],
    hexadecimal: [16, "hex"]
  }
}), ib = new RegExp(
  // 2.5e4, 2.5 and integers
  "^(?:[-+]?(?:[0-9][0-9_]*)(?:\\.[0-9_]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9_]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"
);
function wh(e) {
  return !(e === null || !ib.test(e) || // Quick hack to not allow integers end with `_`
  // Probably should update regexp & check speed
  e[e.length - 1] === "_");
}
p(wh, "resolveYamlFloat");
function _h(e) {
  var t, r;
  return t = e.replace(/_/g, "").toLowerCase(), r = t[0] === "-" ? -1 : 1, "+-".indexOf(t[0]) >= 0 && (t = t.slice(1)), t === ".inf" ? r === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : t === ".nan" ? NaN : r * parseFloat(t, 10);
}
p(_h, "constructYamlFloat");
var nb = /^[-+]?[0-9]+e/;
function vh(e, t) {
  var r;
  if (isNaN(e))
    switch (t) {
      case "lowercase":
        return ".nan";
      case "uppercase":
        return ".NAN";
      case "camelcase":
        return ".NaN";
    }
  else if (Number.POSITIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return ".inf";
      case "uppercase":
        return ".INF";
      case "camelcase":
        return ".Inf";
    }
  else if (Number.NEGATIVE_INFINITY === e)
    switch (t) {
      case "lowercase":
        return "-.inf";
      case "uppercase":
        return "-.INF";
      case "camelcase":
        return "-.Inf";
    }
  else if (bt.isNegativeZero(e))
    return "-0.0";
  return r = e.toString(10), nb.test(r) ? r.replace("e", ".e") : r;
}
p(vh, "representYamlFloat");
function kh(e) {
  return Object.prototype.toString.call(e) === "[object Number]" && (e % 1 !== 0 || bt.isNegativeZero(e));
}
p(kh, "isFloat");
var ab = new Lt("tag:yaml.org,2002:float", {
  kind: "scalar",
  resolve: wh,
  construct: _h,
  predicate: kh,
  represent: vh,
  defaultStyle: "lowercase"
}), Sh = Jx.extend({
  implicit: [
    tb,
    eb,
    rb,
    ab
  ]
}), sb = Sh, Th = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"
), Bh = new RegExp(
  "^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"
);
function Lh(e) {
  return e === null ? !1 : Th.exec(e) !== null || Bh.exec(e) !== null;
}
p(Lh, "resolveYamlTimestamp");
function Mh(e) {
  var t, r, i, n, a, o, s, l = 0, c = null, h, u, f;
  if (t = Th.exec(e), t === null && (t = Bh.exec(e)), t === null) throw new Error("Date resolve error");
  if (r = +t[1], i = +t[2] - 1, n = +t[3], !t[4])
    return new Date(Date.UTC(r, i, n));
  if (a = +t[4], o = +t[5], s = +t[6], t[7]) {
    for (l = t[7].slice(0, 3); l.length < 3; )
      l += "0";
    l = +l;
  }
  return t[9] && (h = +t[10], u = +(t[11] || 0), c = (h * 60 + u) * 6e4, t[9] === "-" && (c = -c)), f = new Date(Date.UTC(r, i, n, a, o, s, l)), c && f.setTime(f.getTime() - c), f;
}
p(Mh, "constructYamlTimestamp");
function $h(e) {
  return e.toISOString();
}
p($h, "representYamlTimestamp");
var ob = new Lt("tag:yaml.org,2002:timestamp", {
  kind: "scalar",
  resolve: Lh,
  construct: Mh,
  instanceOf: Date,
  represent: $h
});
function Ah(e) {
  return e === "<<" || e === null;
}
p(Ah, "resolveYamlMerge");
var lb = new Lt("tag:yaml.org,2002:merge", {
  kind: "scalar",
  resolve: Ah
}), Ds = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
function Fh(e) {
  if (e === null) return !1;
  var t, r, i = 0, n = e.length, a = Ds;
  for (r = 0; r < n; r++)
    if (t = a.indexOf(e.charAt(r)), !(t > 64)) {
      if (t < 0) return !1;
      i += 6;
    }
  return i % 8 === 0;
}
p(Fh, "resolveYamlBinary");
function Eh(e) {
  var t, r, i = e.replace(/[\r\n=]/g, ""), n = i.length, a = Ds, o = 0, s = [];
  for (t = 0; t < n; t++)
    t % 4 === 0 && t && (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)), o = o << 6 | a.indexOf(i.charAt(t));
  return r = n % 4 * 6, r === 0 ? (s.push(o >> 16 & 255), s.push(o >> 8 & 255), s.push(o & 255)) : r === 18 ? (s.push(o >> 10 & 255), s.push(o >> 2 & 255)) : r === 12 && s.push(o >> 4 & 255), new Uint8Array(s);
}
p(Eh, "constructYamlBinary");
function Dh(e) {
  var t = "", r = 0, i, n, a = e.length, o = Ds;
  for (i = 0; i < a; i++)
    i % 3 === 0 && i && (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]), r = (r << 8) + e[i];
  return n = a % 3, n === 0 ? (t += o[r >> 18 & 63], t += o[r >> 12 & 63], t += o[r >> 6 & 63], t += o[r & 63]) : n === 2 ? (t += o[r >> 10 & 63], t += o[r >> 4 & 63], t += o[r << 2 & 63], t += o[64]) : n === 1 && (t += o[r >> 2 & 63], t += o[r << 4 & 63], t += o[64], t += o[64]), t;
}
p(Dh, "representYamlBinary");
function Oh(e) {
  return Object.prototype.toString.call(e) === "[object Uint8Array]";
}
p(Oh, "isBinary");
var cb = new Lt("tag:yaml.org,2002:binary", {
  kind: "scalar",
  resolve: Fh,
  construct: Eh,
  predicate: Oh,
  represent: Dh
}), hb = Object.prototype.hasOwnProperty, ub = Object.prototype.toString;
function Rh(e) {
  if (e === null) return !0;
  var t = [], r, i, n, a, o, s = e;
  for (r = 0, i = s.length; r < i; r += 1) {
    if (n = s[r], o = !1, ub.call(n) !== "[object Object]") return !1;
    for (a in n)
      if (hb.call(n, a))
        if (!o) o = !0;
        else return !1;
    if (!o) return !1;
    if (t.indexOf(a) === -1) t.push(a);
    else return !1;
  }
  return !0;
}
p(Rh, "resolveYamlOmap");
function Ih(e) {
  return e !== null ? e : [];
}
p(Ih, "constructYamlOmap");
var fb = new Lt("tag:yaml.org,2002:omap", {
  kind: "sequence",
  resolve: Rh,
  construct: Ih
}), db = Object.prototype.toString;
function Ph(e) {
  if (e === null) return !0;
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1) {
    if (i = o[t], db.call(i) !== "[object Object]" || (n = Object.keys(i), n.length !== 1)) return !1;
    a[t] = [n[0], i[n[0]]];
  }
  return !0;
}
p(Ph, "resolveYamlPairs");
function Nh(e) {
  if (e === null) return [];
  var t, r, i, n, a, o = e;
  for (a = new Array(o.length), t = 0, r = o.length; t < r; t += 1)
    i = o[t], n = Object.keys(i), a[t] = [n[0], i[n[0]]];
  return a;
}
p(Nh, "constructYamlPairs");
var pb = new Lt("tag:yaml.org,2002:pairs", {
  kind: "sequence",
  resolve: Ph,
  construct: Nh
}), gb = Object.prototype.hasOwnProperty;
function zh(e) {
  if (e === null) return !0;
  var t, r = e;
  for (t in r)
    if (gb.call(r, t) && r[t] !== null)
      return !1;
  return !0;
}
p(zh, "resolveYamlSet");
function qh(e) {
  return e !== null ? e : {};
}
p(qh, "constructYamlSet");
var mb = new Lt("tag:yaml.org,2002:set", {
  kind: "mapping",
  resolve: zh,
  construct: qh
}), Wh = sb.extend({
  implicit: [
    ob,
    lb
  ],
  explicit: [
    cb,
    fb,
    pb,
    mb
  ]
}), ve = Object.prototype.hasOwnProperty, on = 1, Hh = 2, jh = 3, ln = 4, na = 1, yb = 2, jo = 3, xb = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, bb = /[\x85\u2028\u2029]/, Cb = /[,\[\]\{\}]/, Yh = /^(?:!|!!|![a-z\-]+!)$/i, Gh = /^(?:!|[^,\[\]\{\}])(?:%[0-9a-f]{2}|[0-9a-z\-#;\/\?:@&=\+\$,_\.!~\*'\(\)\[\]])*$/i;
function Fa(e) {
  return Object.prototype.toString.call(e);
}
p(Fa, "_class");
function Xt(e) {
  return e === 10 || e === 13;
}
p(Xt, "is_EOL");
function we(e) {
  return e === 9 || e === 32;
}
p(we, "is_WHITE_SPACE");
function Et(e) {
  return e === 9 || e === 32 || e === 10 || e === 13;
}
p(Et, "is_WS_OR_EOL");
function Re(e) {
  return e === 44 || e === 91 || e === 93 || e === 123 || e === 125;
}
p(Re, "is_FLOW_INDICATOR");
function Uh(e) {
  var t;
  return 48 <= e && e <= 57 ? e - 48 : (t = e | 32, 97 <= t && t <= 102 ? t - 97 + 10 : -1);
}
p(Uh, "fromHexCode");
function Xh(e) {
  return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0;
}
p(Xh, "escapedHexLen");
function Vh(e) {
  return 48 <= e && e <= 57 ? e - 48 : -1;
}
p(Vh, "fromDecimalCode");
function Ea(e) {
  return e === 48 ? "\0" : e === 97 ? "\x07" : e === 98 ? "\b" : e === 116 || e === 9 ? "	" : e === 110 ? `
` : e === 118 ? "\v" : e === 102 ? "\f" : e === 114 ? "\r" : e === 101 ? "\x1B" : e === 32 ? " " : e === 34 ? '"' : e === 47 ? "/" : e === 92 ? "\\" : e === 78 ? "" : e === 95 ? " " : e === 76 ? "\u2028" : e === 80 ? "\u2029" : "";
}
p(Ea, "simpleEscapeSequence");
function Zh(e) {
  return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode(
    (e - 65536 >> 10) + 55296,
    (e - 65536 & 1023) + 56320
  );
}
p(Zh, "charFromCodepoint");
var Kh = new Array(256), Qh = new Array(256);
for ($e = 0; $e < 256; $e++)
  Kh[$e] = Ea($e) ? 1 : 0, Qh[$e] = Ea($e);
var $e;
function Jh(e, t) {
  this.input = e, this.filename = t.filename || null, this.schema = t.schema || Wh, this.onWarning = t.onWarning || null, this.legacy = t.legacy || !1, this.json = t.json || !1, this.listener = t.listener || null, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.firstTabInLine = -1, this.documents = [];
}
p(Jh, "State$1");
function Os(e, t) {
  var r = {
    name: e.filename,
    buffer: e.input.slice(0, -1),
    // omit trailing \0
    position: e.position,
    line: e.line,
    column: e.position - e.lineStart
  };
  return r.snippet = Gx(r), new It(t, r);
}
p(Os, "generateError");
function G(e, t) {
  throw Os(e, t);
}
p(G, "throwError");
function ri(e, t) {
  e.onWarning && e.onWarning.call(null, Os(e, t));
}
p(ri, "throwWarning");
var Yo = {
  YAML: /* @__PURE__ */ p(function(t, r, i) {
    var n, a, o;
    t.version !== null && G(t, "duplication of %YAML directive"), i.length !== 1 && G(t, "YAML directive accepts exactly one argument"), n = /^([0-9]+)\.([0-9]+)$/.exec(i[0]), n === null && G(t, "ill-formed argument of the YAML directive"), a = parseInt(n[1], 10), o = parseInt(n[2], 10), a !== 1 && G(t, "unacceptable YAML version of the document"), t.version = i[0], t.checkLineBreaks = o < 2, o !== 1 && o !== 2 && ri(t, "unsupported YAML version of the document");
  }, "handleYamlDirective"),
  TAG: /* @__PURE__ */ p(function(t, r, i) {
    var n, a;
    i.length !== 2 && G(t, "TAG directive accepts exactly two arguments"), n = i[0], a = i[1], Yh.test(n) || G(t, "ill-formed tag handle (first argument) of the TAG directive"), ve.call(t.tagMap, n) && G(t, 'there is a previously declared suffix for "' + n + '" tag handle'), Gh.test(a) || G(t, "ill-formed tag prefix (second argument) of the TAG directive");
    try {
      a = decodeURIComponent(a);
    } catch {
      G(t, "tag prefix is malformed: " + a);
    }
    t.tagMap[n] = a;
  }, "handleTagDirective")
};
function de(e, t, r, i) {
  var n, a, o, s;
  if (t < r) {
    if (s = e.input.slice(t, r), i)
      for (n = 0, a = s.length; n < a; n += 1)
        o = s.charCodeAt(n), o === 9 || 32 <= o && o <= 1114111 || G(e, "expected valid JSON character");
    else xb.test(s) && G(e, "the stream contains non-printable characters");
    e.result += s;
  }
}
p(de, "captureSegment");
function Da(e, t, r, i) {
  var n, a, o, s;
  for (bt.isObject(r) || G(e, "cannot merge mappings; the provided source object is unacceptable"), n = Object.keys(r), o = 0, s = n.length; o < s; o += 1)
    a = n[o], ve.call(t, a) || (t[a] = r[a], i[a] = !0);
}
p(Da, "mergeMappings");
function Ie(e, t, r, i, n, a, o, s, l) {
  var c, h;
  if (Array.isArray(n))
    for (n = Array.prototype.slice.call(n), c = 0, h = n.length; c < h; c += 1)
      Array.isArray(n[c]) && G(e, "nested arrays are not supported inside keys"), typeof n == "object" && Fa(n[c]) === "[object Object]" && (n[c] = "[object Object]");
  if (typeof n == "object" && Fa(n) === "[object Object]" && (n = "[object Object]"), n = String(n), t === null && (t = {}), i === "tag:yaml.org,2002:merge")
    if (Array.isArray(a))
      for (c = 0, h = a.length; c < h; c += 1)
        Da(e, t, a[c], r);
    else
      Da(e, t, a, r);
  else
    !e.json && !ve.call(r, n) && ve.call(t, n) && (e.line = o || e.line, e.lineStart = s || e.lineStart, e.position = l || e.position, G(e, "duplicated mapping key")), n === "__proto__" ? Object.defineProperty(t, n, {
      configurable: !0,
      enumerable: !0,
      writable: !0,
      value: a
    }) : t[n] = a, delete r[n];
  return t;
}
p(Ie, "storeMappingPair");
function Rn(e) {
  var t;
  t = e.input.charCodeAt(e.position), t === 10 ? e.position++ : t === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : G(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1;
}
p(Rn, "readLineBreak");
function pt(e, t, r) {
  for (var i = 0, n = e.input.charCodeAt(e.position); n !== 0; ) {
    for (; we(n); )
      n === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), n = e.input.charCodeAt(++e.position);
    if (t && n === 35)
      do
        n = e.input.charCodeAt(++e.position);
      while (n !== 10 && n !== 13 && n !== 0);
    if (Xt(n))
      for (Rn(e), n = e.input.charCodeAt(e.position), i++, e.lineIndent = 0; n === 32; )
        e.lineIndent++, n = e.input.charCodeAt(++e.position);
    else
      break;
  }
  return r !== -1 && i !== 0 && e.lineIndent < r && ri(e, "deficient indentation"), i;
}
p(pt, "skipSeparationSpace");
function gi(e) {
  var t = e.position, r;
  return r = e.input.charCodeAt(t), !!((r === 45 || r === 46) && r === e.input.charCodeAt(t + 1) && r === e.input.charCodeAt(t + 2) && (t += 3, r = e.input.charCodeAt(t), r === 0 || Et(r)));
}
p(gi, "testDocumentSeparator");
function In(e, t) {
  t === 1 ? e.result += " " : t > 1 && (e.result += bt.repeat(`
`, t - 1));
}
p(In, "writeFoldedLines");
function tu(e, t, r) {
  var i, n, a, o, s, l, c, h, u = e.kind, f = e.result, d;
  if (d = e.input.charCodeAt(e.position), Et(d) || Re(d) || d === 35 || d === 38 || d === 42 || d === 33 || d === 124 || d === 62 || d === 39 || d === 34 || d === 37 || d === 64 || d === 96 || (d === 63 || d === 45) && (n = e.input.charCodeAt(e.position + 1), Et(n) || r && Re(n)))
    return !1;
  for (e.kind = "scalar", e.result = "", a = o = e.position, s = !1; d !== 0; ) {
    if (d === 58) {
      if (n = e.input.charCodeAt(e.position + 1), Et(n) || r && Re(n))
        break;
    } else if (d === 35) {
      if (i = e.input.charCodeAt(e.position - 1), Et(i))
        break;
    } else {
      if (e.position === e.lineStart && gi(e) || r && Re(d))
        break;
      if (Xt(d))
        if (l = e.line, c = e.lineStart, h = e.lineIndent, pt(e, !1, -1), e.lineIndent >= t) {
          s = !0, d = e.input.charCodeAt(e.position);
          continue;
        } else {
          e.position = o, e.line = l, e.lineStart = c, e.lineIndent = h;
          break;
        }
    }
    s && (de(e, a, o, !1), In(e, e.line - l), a = o = e.position, s = !1), we(d) || (o = e.position + 1), d = e.input.charCodeAt(++e.position);
  }
  return de(e, a, o, !1), e.result ? !0 : (e.kind = u, e.result = f, !1);
}
p(tu, "readPlainScalar");
function eu(e, t) {
  var r, i, n;
  if (r = e.input.charCodeAt(e.position), r !== 39)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, i = n = e.position; (r = e.input.charCodeAt(e.position)) !== 0; )
    if (r === 39)
      if (de(e, i, e.position, !0), r = e.input.charCodeAt(++e.position), r === 39)
        i = e.position, e.position++, n = e.position;
      else
        return !0;
    else Xt(r) ? (de(e, i, n, !0), In(e, pt(e, !1, t)), i = n = e.position) : e.position === e.lineStart && gi(e) ? G(e, "unexpected end of the document within a single quoted scalar") : (e.position++, n = e.position);
  G(e, "unexpected end of the stream within a single quoted scalar");
}
p(eu, "readSingleQuotedScalar");
function ru(e, t) {
  var r, i, n, a, o, s;
  if (s = e.input.charCodeAt(e.position), s !== 34)
    return !1;
  for (e.kind = "scalar", e.result = "", e.position++, r = i = e.position; (s = e.input.charCodeAt(e.position)) !== 0; ) {
    if (s === 34)
      return de(e, r, e.position, !0), e.position++, !0;
    if (s === 92) {
      if (de(e, r, e.position, !0), s = e.input.charCodeAt(++e.position), Xt(s))
        pt(e, !1, t);
      else if (s < 256 && Kh[s])
        e.result += Qh[s], e.position++;
      else if ((o = Xh(s)) > 0) {
        for (n = o, a = 0; n > 0; n--)
          s = e.input.charCodeAt(++e.position), (o = Uh(s)) >= 0 ? a = (a << 4) + o : G(e, "expected hexadecimal character");
        e.result += Zh(a), e.position++;
      } else
        G(e, "unknown escape sequence");
      r = i = e.position;
    } else Xt(s) ? (de(e, r, i, !0), In(e, pt(e, !1, t)), r = i = e.position) : e.position === e.lineStart && gi(e) ? G(e, "unexpected end of the document within a double quoted scalar") : (e.position++, i = e.position);
  }
  G(e, "unexpected end of the stream within a double quoted scalar");
}
p(ru, "readDoubleQuotedScalar");
function iu(e, t) {
  var r = !0, i, n, a, o = e.tag, s, l = e.anchor, c, h, u, f, d, g = /* @__PURE__ */ Object.create(null), m, x, y, b;
  if (b = e.input.charCodeAt(e.position), b === 91)
    h = 93, d = !1, s = [];
  else if (b === 123)
    h = 125, d = !0, s = {};
  else
    return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = s), b = e.input.charCodeAt(++e.position); b !== 0; ) {
    if (pt(e, !0, t), b = e.input.charCodeAt(e.position), b === h)
      return e.position++, e.tag = o, e.anchor = l, e.kind = d ? "mapping" : "sequence", e.result = s, !0;
    r ? b === 44 && G(e, "expected the node content, but found ','") : G(e, "missed comma between flow collection entries"), x = m = y = null, u = f = !1, b === 63 && (c = e.input.charCodeAt(e.position + 1), Et(c) && (u = f = !0, e.position++, pt(e, !0, t))), i = e.line, n = e.lineStart, a = e.position, je(e, t, on, !1, !0), x = e.tag, m = e.result, pt(e, !0, t), b = e.input.charCodeAt(e.position), (f || e.line === i) && b === 58 && (u = !0, b = e.input.charCodeAt(++e.position), pt(e, !0, t), je(e, t, on, !1, !0), y = e.result), d ? Ie(e, s, g, x, m, y, i, n, a) : u ? s.push(Ie(e, null, g, x, m, y, i, n, a)) : s.push(m), pt(e, !0, t), b = e.input.charCodeAt(e.position), b === 44 ? (r = !0, b = e.input.charCodeAt(++e.position)) : r = !1;
  }
  G(e, "unexpected end of the stream within a flow collection");
}
p(iu, "readFlowCollection");
function nu(e, t) {
  var r, i, n = na, a = !1, o = !1, s = t, l = 0, c = !1, h, u;
  if (u = e.input.charCodeAt(e.position), u === 124)
    i = !1;
  else if (u === 62)
    i = !0;
  else
    return !1;
  for (e.kind = "scalar", e.result = ""; u !== 0; )
    if (u = e.input.charCodeAt(++e.position), u === 43 || u === 45)
      na === n ? n = u === 43 ? jo : yb : G(e, "repeat of a chomping mode identifier");
    else if ((h = Vh(u)) >= 0)
      h === 0 ? G(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : o ? G(e, "repeat of an indentation width identifier") : (s = t + h - 1, o = !0);
    else
      break;
  if (we(u)) {
    do
      u = e.input.charCodeAt(++e.position);
    while (we(u));
    if (u === 35)
      do
        u = e.input.charCodeAt(++e.position);
      while (!Xt(u) && u !== 0);
  }
  for (; u !== 0; ) {
    for (Rn(e), e.lineIndent = 0, u = e.input.charCodeAt(e.position); (!o || e.lineIndent < s) && u === 32; )
      e.lineIndent++, u = e.input.charCodeAt(++e.position);
    if (!o && e.lineIndent > s && (s = e.lineIndent), Xt(u)) {
      l++;
      continue;
    }
    if (e.lineIndent < s) {
      n === jo ? e.result += bt.repeat(`
`, a ? 1 + l : l) : n === na && a && (e.result += `
`);
      break;
    }
    for (i ? we(u) ? (c = !0, e.result += bt.repeat(`
`, a ? 1 + l : l)) : c ? (c = !1, e.result += bt.repeat(`
`, l + 1)) : l === 0 ? a && (e.result += " ") : e.result += bt.repeat(`
`, l) : e.result += bt.repeat(`
`, a ? 1 + l : l), a = !0, o = !0, l = 0, r = e.position; !Xt(u) && u !== 0; )
      u = e.input.charCodeAt(++e.position);
    de(e, r, e.position, !1);
  }
  return !0;
}
p(nu, "readBlockScalar");
function Oa(e, t) {
  var r, i = e.tag, n = e.anchor, a = [], o, s = !1, l;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = a), l = e.input.charCodeAt(e.position); l !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, G(e, "tab characters must not be used in indentation")), !(l !== 45 || (o = e.input.charCodeAt(e.position + 1), !Et(o)))); ) {
    if (s = !0, e.position++, pt(e, !0, -1) && e.lineIndent <= t) {
      a.push(null), l = e.input.charCodeAt(e.position);
      continue;
    }
    if (r = e.line, je(e, t, jh, !1, !0), a.push(e.result), pt(e, !0, -1), l = e.input.charCodeAt(e.position), (e.line === r || e.lineIndent > t) && l !== 0)
      G(e, "bad indentation of a sequence entry");
    else if (e.lineIndent < t)
      break;
  }
  return s ? (e.tag = i, e.anchor = n, e.kind = "sequence", e.result = a, !0) : !1;
}
p(Oa, "readBlockSequence");
function au(e, t, r) {
  var i, n, a, o, s, l, c = e.tag, h = e.anchor, u = {}, f = /* @__PURE__ */ Object.create(null), d = null, g = null, m = null, x = !1, y = !1, b;
  if (e.firstTabInLine !== -1) return !1;
  for (e.anchor !== null && (e.anchorMap[e.anchor] = u), b = e.input.charCodeAt(e.position); b !== 0; ) {
    if (!x && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, G(e, "tab characters must not be used in indentation")), i = e.input.charCodeAt(e.position + 1), a = e.line, (b === 63 || b === 58) && Et(i))
      b === 63 ? (x && (Ie(e, u, f, d, g, null, o, s, l), d = g = m = null), y = !0, x = !0, n = !0) : x ? (x = !1, n = !0) : G(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, b = i;
    else {
      if (o = e.line, s = e.lineStart, l = e.position, !je(e, r, Hh, !1, !0))
        break;
      if (e.line === a) {
        for (b = e.input.charCodeAt(e.position); we(b); )
          b = e.input.charCodeAt(++e.position);
        if (b === 58)
          b = e.input.charCodeAt(++e.position), Et(b) || G(e, "a whitespace character is expected after the key-value separator within a block mapping"), x && (Ie(e, u, f, d, g, null, o, s, l), d = g = m = null), y = !0, x = !1, n = !1, d = e.tag, g = e.result;
        else if (y)
          G(e, "can not read an implicit mapping pair; a colon is missed");
        else
          return e.tag = c, e.anchor = h, !0;
      } else if (y)
        G(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
      else
        return e.tag = c, e.anchor = h, !0;
    }
    if ((e.line === a || e.lineIndent > t) && (x && (o = e.line, s = e.lineStart, l = e.position), je(e, t, ln, !0, n) && (x ? g = e.result : m = e.result), x || (Ie(e, u, f, d, g, m, o, s, l), d = g = m = null), pt(e, !0, -1), b = e.input.charCodeAt(e.position)), (e.line === a || e.lineIndent > t) && b !== 0)
      G(e, "bad indentation of a mapping entry");
    else if (e.lineIndent < t)
      break;
  }
  return x && Ie(e, u, f, d, g, null, o, s, l), y && (e.tag = c, e.anchor = h, e.kind = "mapping", e.result = u), y;
}
p(au, "readBlockMapping");
function su(e) {
  var t, r = !1, i = !1, n, a, o;
  if (o = e.input.charCodeAt(e.position), o !== 33) return !1;
  if (e.tag !== null && G(e, "duplication of a tag property"), o = e.input.charCodeAt(++e.position), o === 60 ? (r = !0, o = e.input.charCodeAt(++e.position)) : o === 33 ? (i = !0, n = "!!", o = e.input.charCodeAt(++e.position)) : n = "!", t = e.position, r) {
    do
      o = e.input.charCodeAt(++e.position);
    while (o !== 0 && o !== 62);
    e.position < e.length ? (a = e.input.slice(t, e.position), o = e.input.charCodeAt(++e.position)) : G(e, "unexpected end of the stream within a verbatim tag");
  } else {
    for (; o !== 0 && !Et(o); )
      o === 33 && (i ? G(e, "tag suffix cannot contain exclamation marks") : (n = e.input.slice(t - 1, e.position + 1), Yh.test(n) || G(e, "named tag handle cannot contain such characters"), i = !0, t = e.position + 1)), o = e.input.charCodeAt(++e.position);
    a = e.input.slice(t, e.position), Cb.test(a) && G(e, "tag suffix cannot contain flow indicator characters");
  }
  a && !Gh.test(a) && G(e, "tag name cannot contain such characters: " + a);
  try {
    a = decodeURIComponent(a);
  } catch {
    G(e, "tag name is malformed: " + a);
  }
  return r ? e.tag = a : ve.call(e.tagMap, n) ? e.tag = e.tagMap[n] + a : n === "!" ? e.tag = "!" + a : n === "!!" ? e.tag = "tag:yaml.org,2002:" + a : G(e, 'undeclared tag handle "' + n + '"'), !0;
}
p(su, "readTagProperty");
function ou(e) {
  var t, r;
  if (r = e.input.charCodeAt(e.position), r !== 38) return !1;
  for (e.anchor !== null && G(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position), t = e.position; r !== 0 && !Et(r) && !Re(r); )
    r = e.input.charCodeAt(++e.position);
  return e.position === t && G(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(t, e.position), !0;
}
p(ou, "readAnchorProperty");
function lu(e) {
  var t, r, i;
  if (i = e.input.charCodeAt(e.position), i !== 42) return !1;
  for (i = e.input.charCodeAt(++e.position), t = e.position; i !== 0 && !Et(i) && !Re(i); )
    i = e.input.charCodeAt(++e.position);
  return e.position === t && G(e, "name of an alias node must contain at least one character"), r = e.input.slice(t, e.position), ve.call(e.anchorMap, r) || G(e, 'unidentified alias "' + r + '"'), e.result = e.anchorMap[r], pt(e, !0, -1), !0;
}
p(lu, "readAlias");
function je(e, t, r, i, n) {
  var a, o, s, l = 1, c = !1, h = !1, u, f, d, g, m, x;
  if (e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null, a = o = s = ln === r || jh === r, i && pt(e, !0, -1) && (c = !0, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)), l === 1)
    for (; su(e) || ou(e); )
      pt(e, !0, -1) ? (c = !0, s = a, e.lineIndent > t ? l = 1 : e.lineIndent === t ? l = 0 : e.lineIndent < t && (l = -1)) : s = !1;
  if (s && (s = c || n), (l === 1 || ln === r) && (on === r || Hh === r ? m = t : m = t + 1, x = e.position - e.lineStart, l === 1 ? s && (Oa(e, x) || au(e, x, m)) || iu(e, m) ? h = !0 : (o && nu(e, m) || eu(e, m) || ru(e, m) ? h = !0 : lu(e) ? (h = !0, (e.tag !== null || e.anchor !== null) && G(e, "alias node should not have any properties")) : tu(e, m, on === r) && (h = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : l === 0 && (h = s && Oa(e, x))), e.tag === null)
    e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
  else if (e.tag === "?") {
    for (e.result !== null && e.kind !== "scalar" && G(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"'), u = 0, f = e.implicitTypes.length; u < f; u += 1)
      if (g = e.implicitTypes[u], g.resolve(e.result)) {
        e.result = g.construct(e.result), e.tag = g.tag, e.anchor !== null && (e.anchorMap[e.anchor] = e.result);
        break;
      }
  } else if (e.tag !== "!") {
    if (ve.call(e.typeMap[e.kind || "fallback"], e.tag))
      g = e.typeMap[e.kind || "fallback"][e.tag];
    else
      for (g = null, d = e.typeMap.multi[e.kind || "fallback"], u = 0, f = d.length; u < f; u += 1)
        if (e.tag.slice(0, d[u].tag.length) === d[u].tag) {
          g = d[u];
          break;
        }
    g || G(e, "unknown tag !<" + e.tag + ">"), e.result !== null && g.kind !== e.kind && G(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + g.kind + '", not "' + e.kind + '"'), g.resolve(e.result, e.tag) ? (e.result = g.construct(e.result, e.tag), e.anchor !== null && (e.anchorMap[e.anchor] = e.result)) : G(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
  }
  return e.listener !== null && e.listener("close", e), e.tag !== null || e.anchor !== null || h;
}
p(je, "composeNode");
function cu(e) {
  var t = e.position, r, i, n, a = !1, o;
  for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = /* @__PURE__ */ Object.create(null), e.anchorMap = /* @__PURE__ */ Object.create(null); (o = e.input.charCodeAt(e.position)) !== 0 && (pt(e, !0, -1), o = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || o !== 37)); ) {
    for (a = !0, o = e.input.charCodeAt(++e.position), r = e.position; o !== 0 && !Et(o); )
      o = e.input.charCodeAt(++e.position);
    for (i = e.input.slice(r, e.position), n = [], i.length < 1 && G(e, "directive name must not be less than one character in length"); o !== 0; ) {
      for (; we(o); )
        o = e.input.charCodeAt(++e.position);
      if (o === 35) {
        do
          o = e.input.charCodeAt(++e.position);
        while (o !== 0 && !Xt(o));
        break;
      }
      if (Xt(o)) break;
      for (r = e.position; o !== 0 && !Et(o); )
        o = e.input.charCodeAt(++e.position);
      n.push(e.input.slice(r, e.position));
    }
    o !== 0 && Rn(e), ve.call(Yo, i) ? Yo[i](e, i, n) : ri(e, 'unknown document directive "' + i + '"');
  }
  if (pt(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, pt(e, !0, -1)) : a && G(e, "directives end mark is expected"), je(e, e.lineIndent - 1, ln, !1, !0), pt(e, !0, -1), e.checkLineBreaks && bb.test(e.input.slice(t, e.position)) && ri(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && gi(e)) {
    e.input.charCodeAt(e.position) === 46 && (e.position += 3, pt(e, !0, -1));
    return;
  }
  if (e.position < e.length - 1)
    G(e, "end of the stream or a document separator is expected");
  else
    return;
}
p(cu, "readDocument");
function Rs(e, t) {
  e = String(e), t = t || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
  var r = new Jh(e, t), i = e.indexOf("\0");
  for (i !== -1 && (r.position = i, G(r, "null byte is not allowed in input")), r.input += "\0"; r.input.charCodeAt(r.position) === 32; )
    r.lineIndent += 1, r.position += 1;
  for (; r.position < r.length - 1; )
    cu(r);
  return r.documents;
}
p(Rs, "loadDocuments");
function wb(e, t, r) {
  t !== null && typeof t == "object" && typeof r > "u" && (r = t, t = null);
  var i = Rs(e, r);
  if (typeof t != "function")
    return i;
  for (var n = 0, a = i.length; n < a; n += 1)
    t(i[n]);
}
p(wb, "loadAll$1");
function hu(e, t) {
  var r = Rs(e, t);
  if (r.length !== 0) {
    if (r.length === 1)
      return r[0];
    throw new It("expected a single document in the stream, but found more");
  }
}
p(hu, "load$1");
var _b = hu, vb = {
  load: _b
}, uu = Object.prototype.toString, fu = Object.prototype.hasOwnProperty, Is = 65279, kb = 9, ii = 10, Sb = 13, Tb = 32, Bb = 33, Lb = 34, Ra = 35, Mb = 37, $b = 38, Ab = 39, Fb = 42, du = 44, Eb = 45, cn = 58, Db = 61, Ob = 62, Rb = 63, Ib = 64, pu = 91, gu = 93, Pb = 96, mu = 123, Nb = 124, yu = 125, $t = {};
$t[0] = "\\0";
$t[7] = "\\a";
$t[8] = "\\b";
$t[9] = "\\t";
$t[10] = "\\n";
$t[11] = "\\v";
$t[12] = "\\f";
$t[13] = "\\r";
$t[27] = "\\e";
$t[34] = '\\"';
$t[92] = "\\\\";
$t[133] = "\\N";
$t[160] = "\\_";
$t[8232] = "\\L";
$t[8233] = "\\P";
var zb = [
  "y",
  "Y",
  "yes",
  "Yes",
  "YES",
  "on",
  "On",
  "ON",
  "n",
  "N",
  "no",
  "No",
  "NO",
  "off",
  "Off",
  "OFF"
], qb = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
function xu(e, t) {
  var r, i, n, a, o, s, l;
  if (t === null) return {};
  for (r = {}, i = Object.keys(t), n = 0, a = i.length; n < a; n += 1)
    o = i[n], s = String(t[o]), o.slice(0, 2) === "!!" && (o = "tag:yaml.org,2002:" + o.slice(2)), l = e.compiledTypeMap.fallback[o], l && fu.call(l.styleAliases, s) && (s = l.styleAliases[s]), r[o] = s;
  return r;
}
p(xu, "compileStyleMap");
function bu(e) {
  var t, r, i;
  if (t = e.toString(16).toUpperCase(), e <= 255)
    r = "x", i = 2;
  else if (e <= 65535)
    r = "u", i = 4;
  else if (e <= 4294967295)
    r = "U", i = 8;
  else
    throw new It("code point within a string may not be greater than 0xFFFFFFFF");
  return "\\" + r + bt.repeat("0", i - t.length) + t;
}
p(bu, "encodeHex");
var Wb = 1, ni = 2;
function Cu(e) {
  this.schema = e.schema || Wh, this.indent = Math.max(1, e.indent || 2), this.noArrayIndent = e.noArrayIndent || !1, this.skipInvalid = e.skipInvalid || !1, this.flowLevel = bt.isNothing(e.flowLevel) ? -1 : e.flowLevel, this.styleMap = xu(this.schema, e.styles || null), this.sortKeys = e.sortKeys || !1, this.lineWidth = e.lineWidth || 80, this.noRefs = e.noRefs || !1, this.noCompatMode = e.noCompatMode || !1, this.condenseFlow = e.condenseFlow || !1, this.quotingType = e.quotingType === '"' ? ni : Wb, this.forceQuotes = e.forceQuotes || !1, this.replacer = typeof e.replacer == "function" ? e.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null;
}
p(Cu, "State");
function Ia(e, t) {
  for (var r = bt.repeat(" ", t), i = 0, n = -1, a = "", o, s = e.length; i < s; )
    n = e.indexOf(`
`, i), n === -1 ? (o = e.slice(i), i = s) : (o = e.slice(i, n + 1), i = n + 1), o.length && o !== `
` && (a += r), a += o;
  return a;
}
p(Ia, "indentString");
function hn(e, t) {
  return `
` + bt.repeat(" ", e.indent * t);
}
p(hn, "generateNextLine");
function wu(e, t) {
  var r, i, n;
  for (r = 0, i = e.implicitTypes.length; r < i; r += 1)
    if (n = e.implicitTypes[r], n.resolve(t))
      return !0;
  return !1;
}
p(wu, "testImplicitResolving");
function ai(e) {
  return e === Tb || e === kb;
}
p(ai, "isWhitespace");
function wr(e) {
  return 32 <= e && e <= 126 || 161 <= e && e <= 55295 && e !== 8232 && e !== 8233 || 57344 <= e && e <= 65533 && e !== Is || 65536 <= e && e <= 1114111;
}
p(wr, "isPrintable");
function Pa(e) {
  return wr(e) && e !== Is && e !== Sb && e !== ii;
}
p(Pa, "isNsCharOrWhitespace");
function Na(e, t, r) {
  var i = Pa(e), n = i && !ai(e);
  return (
    // ns-plain-safe
    (r ? (
      // c = flow-in
      i
    ) : i && e !== du && e !== pu && e !== gu && e !== mu && e !== yu) && e !== Ra && !(t === cn && !n) || Pa(t) && !ai(t) && e === Ra || t === cn && n
  );
}
p(Na, "isPlainSafe");
function _u(e) {
  return wr(e) && e !== Is && !ai(e) && e !== Eb && e !== Rb && e !== cn && e !== du && e !== pu && e !== gu && e !== mu && e !== yu && e !== Ra && e !== $b && e !== Fb && e !== Bb && e !== Nb && e !== Db && e !== Ob && e !== Ab && e !== Lb && e !== Mb && e !== Ib && e !== Pb;
}
p(_u, "isPlainSafeFirst");
function vu(e) {
  return !ai(e) && e !== cn;
}
p(vu, "isPlainSafeLast");
function ir(e, t) {
  var r = e.charCodeAt(t), i;
  return r >= 55296 && r <= 56319 && t + 1 < e.length && (i = e.charCodeAt(t + 1), i >= 56320 && i <= 57343) ? (r - 55296) * 1024 + i - 56320 + 65536 : r;
}
p(ir, "codePointAt");
function Ps(e) {
  var t = /^\n* /;
  return t.test(e);
}
p(Ps, "needIndentIndicator");
var ku = 1, za = 2, Su = 3, Tu = 4, er = 5;
function Bu(e, t, r, i, n, a, o, s) {
  var l, c = 0, h = null, u = !1, f = !1, d = i !== -1, g = -1, m = _u(ir(e, 0)) && vu(ir(e, e.length - 1));
  if (t || o)
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = ir(e, l), !wr(c))
        return er;
      m = m && Na(c, h, s), h = c;
    }
  else {
    for (l = 0; l < e.length; c >= 65536 ? l += 2 : l++) {
      if (c = ir(e, l), c === ii)
        u = !0, d && (f = f || // Foldable line = too long, and not more-indented.
        l - g - 1 > i && e[g + 1] !== " ", g = l);
      else if (!wr(c))
        return er;
      m = m && Na(c, h, s), h = c;
    }
    f = f || d && l - g - 1 > i && e[g + 1] !== " ";
  }
  return !u && !f ? m && !o && !n(e) ? ku : a === ni ? er : za : r > 9 && Ps(e) ? er : o ? a === ni ? er : za : f ? Tu : Su;
}
p(Bu, "chooseScalarStyle");
function Lu(e, t, r, i, n) {
  e.dump = function() {
    if (t.length === 0)
      return e.quotingType === ni ? '""' : "''";
    if (!e.noCompatMode && (zb.indexOf(t) !== -1 || qb.test(t)))
      return e.quotingType === ni ? '"' + t + '"' : "'" + t + "'";
    var a = e.indent * Math.max(1, r), o = e.lineWidth === -1 ? -1 : Math.max(Math.min(e.lineWidth, 40), e.lineWidth - a), s = i || e.flowLevel > -1 && r >= e.flowLevel;
    function l(c) {
      return wu(e, c);
    }
    switch (p(l, "testAmbiguity"), Bu(
      t,
      s,
      e.indent,
      o,
      l,
      e.quotingType,
      e.forceQuotes && !i,
      n
    )) {
      case ku:
        return t;
      case za:
        return "'" + t.replace(/'/g, "''") + "'";
      case Su:
        return "|" + qa(t, e.indent) + Wa(Ia(t, a));
      case Tu:
        return ">" + qa(t, e.indent) + Wa(Ia(Mu(t, o), a));
      case er:
        return '"' + $u(t) + '"';
      default:
        throw new It("impossible error: invalid scalar style");
    }
  }();
}
p(Lu, "writeScalar");
function qa(e, t) {
  var r = Ps(e) ? String(t) : "", i = e[e.length - 1] === `
`, n = i && (e[e.length - 2] === `
` || e === `
`), a = n ? "+" : i ? "" : "-";
  return r + a + `
`;
}
p(qa, "blockHeader");
function Wa(e) {
  return e[e.length - 1] === `
` ? e.slice(0, -1) : e;
}
p(Wa, "dropEndingNewline");
function Mu(e, t) {
  for (var r = /(\n+)([^\n]*)/g, i = function() {
    var c = e.indexOf(`
`);
    return c = c !== -1 ? c : e.length, r.lastIndex = c, Ha(e.slice(0, c), t);
  }(), n = e[0] === `
` || e[0] === " ", a, o; o = r.exec(e); ) {
    var s = o[1], l = o[2];
    a = l[0] === " ", i += s + (!n && !a && l !== "" ? `
` : "") + Ha(l, t), n = a;
  }
  return i;
}
p(Mu, "foldString");
function Ha(e, t) {
  if (e === "" || e[0] === " ") return e;
  for (var r = / [^ ]/g, i, n = 0, a, o = 0, s = 0, l = ""; i = r.exec(e); )
    s = i.index, s - n > t && (a = o > n ? o : s, l += `
` + e.slice(n, a), n = a + 1), o = s;
  return l += `
`, e.length - n > t && o > n ? l += e.slice(n, o) + `
` + e.slice(o + 1) : l += e.slice(n), l.slice(1);
}
p(Ha, "foldLine");
function $u(e) {
  for (var t = "", r = 0, i, n = 0; n < e.length; r >= 65536 ? n += 2 : n++)
    r = ir(e, n), i = $t[r], !i && wr(r) ? (t += e[n], r >= 65536 && (t += e[n + 1])) : t += i || bu(r);
  return t;
}
p($u, "escapeString");
function Au(e, t, r) {
  var i = "", n = e.tag, a, o, s;
  for (a = 0, o = r.length; a < o; a += 1)
    s = r[a], e.replacer && (s = e.replacer.call(r, String(a), s)), (ie(e, t, s, !1, !1) || typeof s > "u" && ie(e, t, null, !1, !1)) && (i !== "" && (i += "," + (e.condenseFlow ? "" : " ")), i += e.dump);
  e.tag = n, e.dump = "[" + i + "]";
}
p(Au, "writeFlowSequence");
function ja(e, t, r, i) {
  var n = "", a = e.tag, o, s, l;
  for (o = 0, s = r.length; o < s; o += 1)
    l = r[o], e.replacer && (l = e.replacer.call(r, String(o), l)), (ie(e, t + 1, l, !0, !0, !1, !0) || typeof l > "u" && ie(e, t + 1, null, !0, !0, !1, !0)) && ((!i || n !== "") && (n += hn(e, t)), e.dump && ii === e.dump.charCodeAt(0) ? n += "-" : n += "- ", n += e.dump);
  e.tag = a, e.dump = n || "[]";
}
p(ja, "writeBlockSequence");
function Fu(e, t, r) {
  var i = "", n = e.tag, a = Object.keys(r), o, s, l, c, h;
  for (o = 0, s = a.length; o < s; o += 1)
    h = "", i !== "" && (h += ", "), e.condenseFlow && (h += '"'), l = a[o], c = r[l], e.replacer && (c = e.replacer.call(r, l, c)), ie(e, t, l, !1, !1) && (e.dump.length > 1024 && (h += "? "), h += e.dump + (e.condenseFlow ? '"' : "") + ":" + (e.condenseFlow ? "" : " "), ie(e, t, c, !1, !1) && (h += e.dump, i += h));
  e.tag = n, e.dump = "{" + i + "}";
}
p(Fu, "writeFlowMapping");
function Eu(e, t, r, i) {
  var n = "", a = e.tag, o = Object.keys(r), s, l, c, h, u, f;
  if (e.sortKeys === !0)
    o.sort();
  else if (typeof e.sortKeys == "function")
    o.sort(e.sortKeys);
  else if (e.sortKeys)
    throw new It("sortKeys must be a boolean or a function");
  for (s = 0, l = o.length; s < l; s += 1)
    f = "", (!i || n !== "") && (f += hn(e, t)), c = o[s], h = r[c], e.replacer && (h = e.replacer.call(r, c, h)), ie(e, t + 1, c, !0, !0, !0) && (u = e.tag !== null && e.tag !== "?" || e.dump && e.dump.length > 1024, u && (e.dump && ii === e.dump.charCodeAt(0) ? f += "?" : f += "? "), f += e.dump, u && (f += hn(e, t)), ie(e, t + 1, h, !0, u) && (e.dump && ii === e.dump.charCodeAt(0) ? f += ":" : f += ": ", f += e.dump, n += f));
  e.tag = a, e.dump = n || "{}";
}
p(Eu, "writeBlockMapping");
function Ya(e, t, r) {
  var i, n, a, o, s, l;
  for (n = r ? e.explicitTypes : e.implicitTypes, a = 0, o = n.length; a < o; a += 1)
    if (s = n[a], (s.instanceOf || s.predicate) && (!s.instanceOf || typeof t == "object" && t instanceof s.instanceOf) && (!s.predicate || s.predicate(t))) {
      if (r ? s.multi && s.representName ? e.tag = s.representName(t) : e.tag = s.tag : e.tag = "?", s.represent) {
        if (l = e.styleMap[s.tag] || s.defaultStyle, uu.call(s.represent) === "[object Function]")
          i = s.represent(t, l);
        else if (fu.call(s.represent, l))
          i = s.represent[l](t, l);
        else
          throw new It("!<" + s.tag + '> tag resolver accepts not "' + l + '" style');
        e.dump = i;
      }
      return !0;
    }
  return !1;
}
p(Ya, "detectType");
function ie(e, t, r, i, n, a, o) {
  e.tag = null, e.dump = r, Ya(e, r, !1) || Ya(e, r, !0);
  var s = uu.call(e.dump), l = i, c;
  i && (i = e.flowLevel < 0 || e.flowLevel > t);
  var h = s === "[object Object]" || s === "[object Array]", u, f;
  if (h && (u = e.duplicates.indexOf(r), f = u !== -1), (e.tag !== null && e.tag !== "?" || f || e.indent !== 2 && t > 0) && (n = !1), f && e.usedDuplicates[u])
    e.dump = "*ref_" + u;
  else {
    if (h && f && !e.usedDuplicates[u] && (e.usedDuplicates[u] = !0), s === "[object Object]")
      i && Object.keys(e.dump).length !== 0 ? (Eu(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (Fu(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object Array]")
      i && e.dump.length !== 0 ? (e.noArrayIndent && !o && t > 0 ? ja(e, t - 1, e.dump, n) : ja(e, t, e.dump, n), f && (e.dump = "&ref_" + u + e.dump)) : (Au(e, t, e.dump), f && (e.dump = "&ref_" + u + " " + e.dump));
    else if (s === "[object String]")
      e.tag !== "?" && Lu(e, e.dump, t, a, l);
    else {
      if (s === "[object Undefined]")
        return !1;
      if (e.skipInvalid) return !1;
      throw new It("unacceptable kind of an object to dump " + s);
    }
    e.tag !== null && e.tag !== "?" && (c = encodeURI(
      e.tag[0] === "!" ? e.tag.slice(1) : e.tag
    ).replace(/!/g, "%21"), e.tag[0] === "!" ? c = "!" + c : c.slice(0, 18) === "tag:yaml.org,2002:" ? c = "!!" + c.slice(18) : c = "!<" + c + ">", e.dump = c + " " + e.dump);
  }
  return !0;
}
p(ie, "writeNode");
function Du(e, t) {
  var r = [], i = [], n, a;
  for (un(e, r, i), n = 0, a = i.length; n < a; n += 1)
    t.duplicates.push(r[i[n]]);
  t.usedDuplicates = new Array(a);
}
p(Du, "getDuplicateReferences");
function un(e, t, r) {
  var i, n, a;
  if (e !== null && typeof e == "object")
    if (n = t.indexOf(e), n !== -1)
      r.indexOf(n) === -1 && r.push(n);
    else if (t.push(e), Array.isArray(e))
      for (n = 0, a = e.length; n < a; n += 1)
        un(e[n], t, r);
    else
      for (i = Object.keys(e), n = 0, a = i.length; n < a; n += 1)
        un(e[i[n]], t, r);
}
p(un, "inspectNode");
function Hb(e, t) {
  t = t || {};
  var r = new Cu(t);
  r.noRefs || Du(e, r);
  var i = e;
  return r.replacer && (i = r.replacer.call({ "": i }, "", i)), ie(r, 0, i, !0, !0) ? r.dump + `
` : "";
}
p(Hb, "dump$1");
function jb(e, t) {
  return function() {
    throw new Error("Function yaml." + e + " is removed in js-yaml 4. Use yaml." + t + " instead, which is now safe by default.");
  };
}
p(jb, "renamed");
var Yb = Sh, Gb = vb.load;
/*! Bundled license information:

js-yaml/dist/js-yaml.mjs:
  (*! js-yaml 4.1.0 https://github.com/nodeca/js-yaml @license MIT *)
*/
var Ht = {
  aggregation: 18,
  extension: 18,
  composition: 18,
  dependency: 6,
  lollipop: 13.5,
  arrow_point: 4
};
function Wr(e, t) {
  if (e === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 };
  e = ht(e), t = ht(t);
  const [r, i] = [e.x, e.y], [n, a] = [t.x, t.y], o = n - r, s = a - i;
  return { angle: Math.atan(s / o), deltaX: o, deltaY: s };
}
p(Wr, "calculateDeltaAndAngle");
var ht = /* @__PURE__ */ p((e) => Array.isArray(e) ? { x: e[0], y: e[1] } : e, "pointTransformer"), Ub = /* @__PURE__ */ p((e) => ({
  x: /* @__PURE__ */ p(function(t, r, i) {
    let n = 0;
    const a = ht(i[0]).x < ht(i[i.length - 1]).x ? "left" : "right";
    if (r === 0 && Object.hasOwn(Ht, e.arrowTypeStart)) {
      const { angle: d, deltaX: g } = Wr(i[0], i[1]);
      n = Ht[e.arrowTypeStart] * Math.cos(d) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ht, e.arrowTypeEnd)) {
      const { angle: d, deltaX: g } = Wr(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ht[e.arrowTypeEnd] * Math.cos(d) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      ht(t).x - ht(i[i.length - 1]).x
    ), s = Math.abs(
      ht(t).y - ht(i[i.length - 1]).y
    ), l = Math.abs(ht(t).x - ht(i[0]).x), c = Math.abs(ht(t).y - ht(i[0]).y), h = Ht[e.arrowTypeStart], u = Ht[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let d = u + f - o;
      d *= a === "right" ? -1 : 1, n -= d;
    }
    if (l < h && l > 0 && c < h) {
      let d = h + f - l;
      d *= a === "right" ? -1 : 1, n += d;
    }
    return ht(t).x + n;
  }, "x"),
  y: /* @__PURE__ */ p(function(t, r, i) {
    let n = 0;
    const a = ht(i[0]).y < ht(i[i.length - 1]).y ? "down" : "up";
    if (r === 0 && Object.hasOwn(Ht, e.arrowTypeStart)) {
      const { angle: d, deltaY: g } = Wr(i[0], i[1]);
      n = Ht[e.arrowTypeStart] * Math.abs(Math.sin(d)) * (g >= 0 ? 1 : -1);
    } else if (r === i.length - 1 && Object.hasOwn(Ht, e.arrowTypeEnd)) {
      const { angle: d, deltaY: g } = Wr(
        i[i.length - 1],
        i[i.length - 2]
      );
      n = Ht[e.arrowTypeEnd] * Math.abs(Math.sin(d)) * (g >= 0 ? 1 : -1);
    }
    const o = Math.abs(
      ht(t).y - ht(i[i.length - 1]).y
    ), s = Math.abs(
      ht(t).x - ht(i[i.length - 1]).x
    ), l = Math.abs(ht(t).y - ht(i[0]).y), c = Math.abs(ht(t).x - ht(i[0]).x), h = Ht[e.arrowTypeStart], u = Ht[e.arrowTypeEnd], f = 1;
    if (o < u && o > 0 && s < u) {
      let d = u + f - o;
      d *= a === "up" ? -1 : 1, n -= d;
    }
    if (l < h && l > 0 && c < h) {
      let d = h + f - l;
      d *= a === "up" ? -1 : 1, n += d;
    }
    return ht(t).y + n;
  }, "y")
}), "getLineFunctionsWithOffset"), Ns = /* @__PURE__ */ p(({
  flowchart: e
}) => {
  var n, a;
  const t = ((n = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : n.top) ?? 0, r = ((a = e == null ? void 0 : e.subGraphTitleMargin) == null ? void 0 : a.bottom) ?? 0, i = t + r;
  return {
    subGraphTitleTopMargin: t,
    subGraphTitleBottomMargin: r,
    subGraphTitleTotalMargin: i
  };
}, "getSubGraphTitleMargins"), Xb = /* @__PURE__ */ p((e) => {
  const { handDrawnSeed: t } = nt();
  return {
    fill: e,
    hachureAngle: 120,
    // angle of hachure,
    hachureGap: 4,
    fillWeight: 2,
    roughness: 0.7,
    stroke: e,
    seed: t
  };
}, "solidStateFill"), Sr = /* @__PURE__ */ p((e) => {
  const t = Vb([...e.cssCompiledStyles || [], ...e.cssStyles || []]);
  return { stylesMap: t, stylesArray: [...t] };
}, "compileStyles"), Vb = /* @__PURE__ */ p((e) => {
  const t = /* @__PURE__ */ new Map();
  return e.forEach((r) => {
    const [i, n] = r.split(":");
    t.set(i.trim(), n == null ? void 0 : n.trim());
  }), t;
}, "styles2Map"), Ou = /* @__PURE__ */ p((e) => e === "color" || e === "font-size" || e === "font-family" || e === "font-weight" || e === "font-style" || e === "text-decoration" || e === "text-align" || e === "text-transform" || e === "line-height" || e === "letter-spacing" || e === "word-spacing" || e === "text-shadow" || e === "text-overflow" || e === "white-space" || e === "word-wrap" || e === "word-break" || e === "overflow-wrap" || e === "hyphens", "isLabelStyle"), Y = /* @__PURE__ */ p((e) => {
  const { stylesArray: t } = Sr(e), r = [], i = [], n = [], a = [];
  return t.forEach((o) => {
    const s = o[0];
    Ou(s) ? r.push(o.join(":") + " !important") : (i.push(o.join(":") + " !important"), s.includes("stroke") && n.push(o.join(":") + " !important"), s === "fill" && a.push(o.join(":") + " !important"));
  }), {
    labelStyles: r.join(";"),
    nodeStyles: i.join(";"),
    stylesArray: t,
    borderStyles: n,
    backgroundStyles: a
  };
}, "styles2String"), H = /* @__PURE__ */ p((e, t) => {
  var l;
  const { themeVariables: r, handDrawnSeed: i } = nt(), { nodeBorder: n, mainBkg: a } = r, { stylesMap: o } = Sr(e);
  return Object.assign(
    {
      roughness: 0.7,
      fill: o.get("fill") || a,
      fillStyle: "hachure",
      // solid fill
      fillWeight: 4,
      hachureGap: 5.2,
      stroke: o.get("stroke") || n,
      seed: i,
      strokeWidth: ((l = o.get("stroke-width")) == null ? void 0 : l.replace("px", "")) || 1.3,
      fillLineDash: [0, 0],
      strokeLineDash: Zb(o.get("stroke-dasharray"))
    },
    t
  );
}, "userNodeOverrides"), Zb = /* @__PURE__ */ p((e) => {
  if (!e)
    return [0, 0];
  const t = e.trim().split(/\s+/).map(Number);
  if (t.length === 1) {
    const n = isNaN(t[0]) ? 0 : t[0];
    return [n, n];
  }
  const r = isNaN(t[0]) ? 0 : t[0], i = isNaN(t[1]) ? 0 : t[1];
  return [r, i];
}, "getStrokeDashArray"), zs = {}, wt = {};
Object.defineProperty(wt, "__esModule", { value: !0 });
wt.BLANK_URL = wt.relativeFirstCharacters = wt.whitespaceEscapeCharsRegex = wt.urlSchemeRegex = wt.ctrlCharactersRegex = wt.htmlCtrlEntityRegex = wt.htmlEntitiesRegex = wt.invalidProtocolRegex = void 0;
wt.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
wt.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
wt.htmlCtrlEntityRegex = /&(newline|tab);/gi;
wt.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
wt.urlSchemeRegex = /^.+(:|&colon;)/gim;
wt.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g;
wt.relativeFirstCharacters = [".", "/"];
wt.BLANK_URL = "about:blank";
Object.defineProperty(zs, "__esModule", { value: !0 });
var Ru = zs.sanitizeUrl = void 0, Tt = wt;
function Kb(e) {
  return Tt.relativeFirstCharacters.indexOf(e[0]) > -1;
}
function Qb(e) {
  var t = e.replace(Tt.ctrlCharactersRegex, "");
  return t.replace(Tt.htmlEntitiesRegex, function(r, i) {
    return String.fromCharCode(i);
  });
}
function Jb(e) {
  return URL.canParse(e);
}
function Go(e) {
  try {
    return decodeURIComponent(e);
  } catch {
    return e;
  }
}
function t1(e) {
  if (!e)
    return Tt.BLANK_URL;
  var t, r = Go(e.trim());
  do
    r = Qb(r).replace(Tt.htmlCtrlEntityRegex, "").replace(Tt.ctrlCharactersRegex, "").replace(Tt.whitespaceEscapeCharsRegex, "").trim(), r = Go(r), t = r.match(Tt.ctrlCharactersRegex) || r.match(Tt.htmlEntitiesRegex) || r.match(Tt.htmlCtrlEntityRegex) || r.match(Tt.whitespaceEscapeCharsRegex);
  while (t && t.length > 0);
  var i = r;
  if (!i)
    return Tt.BLANK_URL;
  if (Kb(i))
    return i;
  var n = i.trimStart(), a = n.match(Tt.urlSchemeRegex);
  if (!a)
    return i;
  var o = a[0].toLowerCase().trim();
  if (Tt.invalidProtocolRegex.test(o))
    return Tt.BLANK_URL;
  var s = n.replace(/\\/g, "/");
  if (o === "mailto:" || o.includes("://"))
    return s;
  if (o === "http:" || o === "https:") {
    if (!Jb(s))
      return Tt.BLANK_URL;
    var l = new URL(s);
    return l.protocol = l.protocol.toLowerCase(), l.hostname = l.hostname.toLowerCase(), l.toString();
  }
  return s;
}
Ru = zs.sanitizeUrl = t1;
var Iu = typeof global == "object" && global && global.Object === Object && global, e1 = typeof self == "object" && self && self.Object === Object && self, ae = Iu || e1 || Function("return this")(), fn = ae.Symbol, Pu = Object.prototype, r1 = Pu.hasOwnProperty, i1 = Pu.toString, Fr = fn ? fn.toStringTag : void 0;
function n1(e) {
  var t = r1.call(e, Fr), r = e[Fr];
  try {
    e[Fr] = void 0;
    var i = !0;
  } catch {
  }
  var n = i1.call(e);
  return i && (t ? e[Fr] = r : delete e[Fr]), n;
}
var a1 = Object.prototype, s1 = a1.toString;
function o1(e) {
  return s1.call(e);
}
var l1 = "[object Null]", c1 = "[object Undefined]", Uo = fn ? fn.toStringTag : void 0;
function Tr(e) {
  return e == null ? e === void 0 ? c1 : l1 : Uo && Uo in Object(e) ? n1(e) : o1(e);
}
function Xe(e) {
  var t = typeof e;
  return e != null && (t == "object" || t == "function");
}
var h1 = "[object AsyncFunction]", u1 = "[object Function]", f1 = "[object GeneratorFunction]", d1 = "[object Proxy]";
function qs(e) {
  if (!Xe(e))
    return !1;
  var t = Tr(e);
  return t == u1 || t == f1 || t == h1 || t == d1;
}
var aa = ae["__core-js_shared__"], Xo = function() {
  var e = /[^.]+$/.exec(aa && aa.keys && aa.keys.IE_PROTO || "");
  return e ? "Symbol(src)_1." + e : "";
}();
function p1(e) {
  return !!Xo && Xo in e;
}
var g1 = Function.prototype, m1 = g1.toString;
function Ve(e) {
  if (e != null) {
    try {
      return m1.call(e);
    } catch {
    }
    try {
      return e + "";
    } catch {
    }
  }
  return "";
}
var y1 = /[\\^$.*+?()[\]{}|]/g, x1 = /^\[object .+?Constructor\]$/, b1 = Function.prototype, C1 = Object.prototype, w1 = b1.toString, _1 = C1.hasOwnProperty, v1 = RegExp(
  "^" + w1.call(_1).replace(y1, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$"
);
function k1(e) {
  if (!Xe(e) || p1(e))
    return !1;
  var t = qs(e) ? v1 : x1;
  return t.test(Ve(e));
}
function S1(e, t) {
  return e == null ? void 0 : e[t];
}
function Ze(e, t) {
  var r = S1(e, t);
  return k1(r) ? r : void 0;
}
var si = Ze(Object, "create");
function T1() {
  this.__data__ = si ? si(null) : {}, this.size = 0;
}
function B1(e) {
  var t = this.has(e) && delete this.__data__[e];
  return this.size -= t ? 1 : 0, t;
}
var L1 = "__lodash_hash_undefined__", M1 = Object.prototype, $1 = M1.hasOwnProperty;
function A1(e) {
  var t = this.__data__;
  if (si) {
    var r = t[e];
    return r === L1 ? void 0 : r;
  }
  return $1.call(t, e) ? t[e] : void 0;
}
var F1 = Object.prototype, E1 = F1.hasOwnProperty;
function D1(e) {
  var t = this.__data__;
  return si ? t[e] !== void 0 : E1.call(t, e);
}
var O1 = "__lodash_hash_undefined__";
function R1(e, t) {
  var r = this.__data__;
  return this.size += this.has(e) ? 0 : 1, r[e] = si && t === void 0 ? O1 : t, this;
}
function Ye(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Ye.prototype.clear = T1;
Ye.prototype.delete = B1;
Ye.prototype.get = A1;
Ye.prototype.has = D1;
Ye.prototype.set = R1;
function I1() {
  this.__data__ = [], this.size = 0;
}
function Pn(e, t) {
  return e === t || e !== e && t !== t;
}
function Nn(e, t) {
  for (var r = e.length; r--; )
    if (Pn(e[r][0], t))
      return r;
  return -1;
}
var P1 = Array.prototype, N1 = P1.splice;
function z1(e) {
  var t = this.__data__, r = Nn(t, e);
  if (r < 0)
    return !1;
  var i = t.length - 1;
  return r == i ? t.pop() : N1.call(t, r, 1), --this.size, !0;
}
function q1(e) {
  var t = this.__data__, r = Nn(t, e);
  return r < 0 ? void 0 : t[r][1];
}
function W1(e) {
  return Nn(this.__data__, e) > -1;
}
function H1(e, t) {
  var r = this.__data__, i = Nn(r, e);
  return i < 0 ? (++this.size, r.push([e, t])) : r[i][1] = t, this;
}
function me(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
me.prototype.clear = I1;
me.prototype.delete = z1;
me.prototype.get = q1;
me.prototype.has = W1;
me.prototype.set = H1;
var oi = Ze(ae, "Map");
function j1() {
  this.size = 0, this.__data__ = {
    hash: new Ye(),
    map: new (oi || me)(),
    string: new Ye()
  };
}
function Y1(e) {
  var t = typeof e;
  return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null;
}
function zn(e, t) {
  var r = e.__data__;
  return Y1(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map;
}
function G1(e) {
  var t = zn(this, e).delete(e);
  return this.size -= t ? 1 : 0, t;
}
function U1(e) {
  return zn(this, e).get(e);
}
function X1(e) {
  return zn(this, e).has(e);
}
function V1(e, t) {
  var r = zn(this, e), i = r.size;
  return r.set(e, t), this.size += r.size == i ? 0 : 1, this;
}
function Te(e) {
  var t = -1, r = e == null ? 0 : e.length;
  for (this.clear(); ++t < r; ) {
    var i = e[t];
    this.set(i[0], i[1]);
  }
}
Te.prototype.clear = j1;
Te.prototype.delete = G1;
Te.prototype.get = U1;
Te.prototype.has = X1;
Te.prototype.set = V1;
var Z1 = "Expected a function";
function mi(e, t) {
  if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(Z1);
  var r = function() {
    var i = arguments, n = t ? t.apply(this, i) : i[0], a = r.cache;
    if (a.has(n))
      return a.get(n);
    var o = e.apply(this, i);
    return r.cache = a.set(n, o) || a, o;
  };
  return r.cache = new (mi.Cache || Te)(), r;
}
mi.Cache = Te;
function K1() {
  this.__data__ = new me(), this.size = 0;
}
function Q1(e) {
  var t = this.__data__, r = t.delete(e);
  return this.size = t.size, r;
}
function J1(e) {
  return this.__data__.get(e);
}
function t2(e) {
  return this.__data__.has(e);
}
var e2 = 200;
function r2(e, t) {
  var r = this.__data__;
  if (r instanceof me) {
    var i = r.__data__;
    if (!oi || i.length < e2 - 1)
      return i.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new Te(i);
  }
  return r.set(e, t), this.size = r.size, this;
}
function Br(e) {
  var t = this.__data__ = new me(e);
  this.size = t.size;
}
Br.prototype.clear = K1;
Br.prototype.delete = Q1;
Br.prototype.get = J1;
Br.prototype.has = t2;
Br.prototype.set = r2;
var dn = function() {
  try {
    var e = Ze(Object, "defineProperty");
    return e({}, "", {}), e;
  } catch {
  }
}();
function Ws(e, t, r) {
  t == "__proto__" && dn ? dn(e, t, {
    configurable: !0,
    enumerable: !0,
    value: r,
    writable: !0
  }) : e[t] = r;
}
function Ga(e, t, r) {
  (r !== void 0 && !Pn(e[t], r) || r === void 0 && !(t in e)) && Ws(e, t, r);
}
function i2(e) {
  return function(t, r, i) {
    for (var n = -1, a = Object(t), o = i(t), s = o.length; s--; ) {
      var l = o[++n];
      if (r(a[l], l, a) === !1)
        break;
    }
    return t;
  };
}
var n2 = i2(), Nu = typeof exports == "object" && exports && !exports.nodeType && exports, Vo = Nu && typeof module == "object" && module && !module.nodeType && module, a2 = Vo && Vo.exports === Nu, Zo = a2 ? ae.Buffer : void 0, Ko = Zo ? Zo.allocUnsafe : void 0;
function s2(e, t) {
  if (t)
    return e.slice();
  var r = e.length, i = Ko ? Ko(r) : new e.constructor(r);
  return e.copy(i), i;
}
var Qo = ae.Uint8Array;
function o2(e) {
  var t = new e.constructor(e.byteLength);
  return new Qo(t).set(new Qo(e)), t;
}
function l2(e, t) {
  var r = t ? o2(e.buffer) : e.buffer;
  return new e.constructor(r, e.byteOffset, e.length);
}
function c2(e, t) {
  var r = -1, i = e.length;
  for (t || (t = Array(i)); ++r < i; )
    t[r] = e[r];
  return t;
}
var Jo = Object.create, h2 = /* @__PURE__ */ function() {
  function e() {
  }
  return function(t) {
    if (!Xe(t))
      return {};
    if (Jo)
      return Jo(t);
    e.prototype = t;
    var r = new e();
    return e.prototype = void 0, r;
  };
}();
function zu(e, t) {
  return function(r) {
    return e(t(r));
  };
}
var qu = zu(Object.getPrototypeOf, Object), u2 = Object.prototype;
function qn(e) {
  var t = e && e.constructor, r = typeof t == "function" && t.prototype || u2;
  return e === r;
}
function f2(e) {
  return typeof e.constructor == "function" && !qn(e) ? h2(qu(e)) : {};
}
function yi(e) {
  return e != null && typeof e == "object";
}
var d2 = "[object Arguments]";
function tl(e) {
  return yi(e) && Tr(e) == d2;
}
var Wu = Object.prototype, p2 = Wu.hasOwnProperty, g2 = Wu.propertyIsEnumerable, pn = tl(/* @__PURE__ */ function() {
  return arguments;
}()) ? tl : function(e) {
  return yi(e) && p2.call(e, "callee") && !g2.call(e, "callee");
}, gn = Array.isArray, m2 = 9007199254740991;
function Hu(e) {
  return typeof e == "number" && e > -1 && e % 1 == 0 && e <= m2;
}
function Wn(e) {
  return e != null && Hu(e.length) && !qs(e);
}
function y2(e) {
  return yi(e) && Wn(e);
}
function x2() {
  return !1;
}
var ju = typeof exports == "object" && exports && !exports.nodeType && exports, el = ju && typeof module == "object" && module && !module.nodeType && module, b2 = el && el.exports === ju, rl = b2 ? ae.Buffer : void 0, C2 = rl ? rl.isBuffer : void 0, Hs = C2 || x2, w2 = "[object Object]", _2 = Function.prototype, v2 = Object.prototype, Yu = _2.toString, k2 = v2.hasOwnProperty, S2 = Yu.call(Object);
function T2(e) {
  if (!yi(e) || Tr(e) != w2)
    return !1;
  var t = qu(e);
  if (t === null)
    return !0;
  var r = k2.call(t, "constructor") && t.constructor;
  return typeof r == "function" && r instanceof r && Yu.call(r) == S2;
}
var B2 = "[object Arguments]", L2 = "[object Array]", M2 = "[object Boolean]", $2 = "[object Date]", A2 = "[object Error]", F2 = "[object Function]", E2 = "[object Map]", D2 = "[object Number]", O2 = "[object Object]", R2 = "[object RegExp]", I2 = "[object Set]", P2 = "[object String]", N2 = "[object WeakMap]", z2 = "[object ArrayBuffer]", q2 = "[object DataView]", W2 = "[object Float32Array]", H2 = "[object Float64Array]", j2 = "[object Int8Array]", Y2 = "[object Int16Array]", G2 = "[object Int32Array]", U2 = "[object Uint8Array]", X2 = "[object Uint8ClampedArray]", V2 = "[object Uint16Array]", Z2 = "[object Uint32Array]", ct = {};
ct[W2] = ct[H2] = ct[j2] = ct[Y2] = ct[G2] = ct[U2] = ct[X2] = ct[V2] = ct[Z2] = !0;
ct[B2] = ct[L2] = ct[z2] = ct[M2] = ct[q2] = ct[$2] = ct[A2] = ct[F2] = ct[E2] = ct[D2] = ct[O2] = ct[R2] = ct[I2] = ct[P2] = ct[N2] = !1;
function K2(e) {
  return yi(e) && Hu(e.length) && !!ct[Tr(e)];
}
function Q2(e) {
  return function(t) {
    return e(t);
  };
}
var Gu = typeof exports == "object" && exports && !exports.nodeType && exports, Zr = Gu && typeof module == "object" && module && !module.nodeType && module, J2 = Zr && Zr.exports === Gu, sa = J2 && Iu.process, il = function() {
  try {
    var e = Zr && Zr.require && Zr.require("util").types;
    return e || sa && sa.binding && sa.binding("util");
  } catch {
  }
}(), nl = il && il.isTypedArray, js = nl ? Q2(nl) : K2;
function Ua(e, t) {
  if (!(t === "constructor" && typeof e[t] == "function") && t != "__proto__")
    return e[t];
}
var tC = Object.prototype, eC = tC.hasOwnProperty;
function rC(e, t, r) {
  var i = e[t];
  (!(eC.call(e, t) && Pn(i, r)) || r === void 0 && !(t in e)) && Ws(e, t, r);
}
function iC(e, t, r, i) {
  var n = !r;
  r || (r = {});
  for (var a = -1, o = t.length; ++a < o; ) {
    var s = t[a], l = void 0;
    l === void 0 && (l = e[s]), n ? Ws(r, s, l) : rC(r, s, l);
  }
  return r;
}
function nC(e, t) {
  for (var r = -1, i = Array(e); ++r < e; )
    i[r] = t(r);
  return i;
}
var aC = 9007199254740991, sC = /^(?:0|[1-9]\d*)$/;
function Uu(e, t) {
  var r = typeof e;
  return t = t ?? aC, !!t && (r == "number" || r != "symbol" && sC.test(e)) && e > -1 && e % 1 == 0 && e < t;
}
var oC = Object.prototype, lC = oC.hasOwnProperty;
function cC(e, t) {
  var r = gn(e), i = !r && pn(e), n = !r && !i && Hs(e), a = !r && !i && !n && js(e), o = r || i || n || a, s = o ? nC(e.length, String) : [], l = s.length;
  for (var c in e)
    (t || lC.call(e, c)) && !(o && // Safari 9 has enumerable `arguments.length` in strict mode.
    (c == "length" || // Node.js 0.10 has enumerable non-index properties on buffers.
    n && (c == "offset" || c == "parent") || // PhantomJS 2 has enumerable non-index properties on typed arrays.
    a && (c == "buffer" || c == "byteLength" || c == "byteOffset") || // Skip index properties.
    Uu(c, l))) && s.push(c);
  return s;
}
function hC(e) {
  var t = [];
  if (e != null)
    for (var r in Object(e))
      t.push(r);
  return t;
}
var uC = Object.prototype, fC = uC.hasOwnProperty;
function dC(e) {
  if (!Xe(e))
    return hC(e);
  var t = qn(e), r = [];
  for (var i in e)
    i == "constructor" && (t || !fC.call(e, i)) || r.push(i);
  return r;
}
function Xu(e) {
  return Wn(e) ? cC(e, !0) : dC(e);
}
function pC(e) {
  return iC(e, Xu(e));
}
function gC(e, t, r, i, n, a, o) {
  var s = Ua(e, r), l = Ua(t, r), c = o.get(l);
  if (c) {
    Ga(e, r, c);
    return;
  }
  var h = a ? a(s, l, r + "", e, t, o) : void 0, u = h === void 0;
  if (u) {
    var f = gn(l), d = !f && Hs(l), g = !f && !d && js(l);
    h = l, f || d || g ? gn(s) ? h = s : y2(s) ? h = c2(s) : d ? (u = !1, h = s2(l, !0)) : g ? (u = !1, h = l2(l, !0)) : h = [] : T2(l) || pn(l) ? (h = s, pn(s) ? h = pC(s) : (!Xe(s) || qs(s)) && (h = f2(l))) : u = !1;
  }
  u && (o.set(l, h), n(h, l, i, a, o), o.delete(l)), Ga(e, r, h);
}
function Vu(e, t, r, i, n) {
  e !== t && n2(t, function(a, o) {
    if (n || (n = new Br()), Xe(a))
      gC(e, t, o, r, Vu, i, n);
    else {
      var s = i ? i(Ua(e, o), a, o + "", e, t, n) : void 0;
      s === void 0 && (s = a), Ga(e, o, s);
    }
  }, Xu);
}
function Zu(e) {
  return e;
}
function mC(e, t, r) {
  switch (r.length) {
    case 0:
      return e.call(t);
    case 1:
      return e.call(t, r[0]);
    case 2:
      return e.call(t, r[0], r[1]);
    case 3:
      return e.call(t, r[0], r[1], r[2]);
  }
  return e.apply(t, r);
}
var al = Math.max;
function yC(e, t, r) {
  return t = al(t === void 0 ? e.length - 1 : t, 0), function() {
    for (var i = arguments, n = -1, a = al(i.length - t, 0), o = Array(a); ++n < a; )
      o[n] = i[t + n];
    n = -1;
    for (var s = Array(t + 1); ++n < t; )
      s[n] = i[n];
    return s[t] = r(o), mC(e, this, s);
  };
}
function xC(e) {
  return function() {
    return e;
  };
}
var bC = dn ? function(e, t) {
  return dn(e, "toString", {
    configurable: !0,
    enumerable: !1,
    value: xC(t),
    writable: !0
  });
} : Zu, CC = 800, wC = 16, _C = Date.now;
function vC(e) {
  var t = 0, r = 0;
  return function() {
    var i = _C(), n = wC - (i - r);
    if (r = i, n > 0) {
      if (++t >= CC)
        return arguments[0];
    } else
      t = 0;
    return e.apply(void 0, arguments);
  };
}
var kC = vC(bC);
function SC(e, t) {
  return kC(yC(e, t, Zu), e + "");
}
function TC(e, t, r) {
  if (!Xe(r))
    return !1;
  var i = typeof t;
  return (i == "number" ? Wn(r) && Uu(t, r.length) : i == "string" && t in r) ? Pn(r[t], e) : !1;
}
function BC(e) {
  return SC(function(t, r) {
    var i = -1, n = r.length, a = n > 1 ? r[n - 1] : void 0, o = n > 2 ? r[2] : void 0;
    for (a = e.length > 3 && typeof a == "function" ? (n--, a) : void 0, o && TC(r[0], r[1], o) && (a = n < 3 ? void 0 : a, n = 1), t = Object(t); ++i < n; ) {
      var s = r[i];
      s && e(t, s, i, a);
    }
    return t;
  });
}
var LC = BC(function(e, t, r) {
  Vu(e, t, r);
}), MC = "​", $C = {
  curveBasis: Oi,
  curveBasisClosed: Ax,
  curveBasisOpen: Fx,
  curveBumpX: Dc,
  curveBumpY: Oc,
  curveBundle: Ex,
  curveCardinalClosed: Dx,
  curveCardinalOpen: Ox,
  curveCardinal: Nc,
  curveCatmullRomClosed: Rx,
  curveCatmullRomOpen: Ix,
  curveCatmullRom: qc,
  curveLinear: en,
  curveLinearClosed: Px,
  curveMonotoneX: Uc,
  curveMonotoneY: Xc,
  curveNatural: Zc,
  curveStep: Kc,
  curveStepAfter: Jc,
  curveStepBefore: Qc
}, AC = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, FC = /* @__PURE__ */ p(function(e, t) {
  const r = Ku(e, /(?:init\b)|(?:initialize\b)/);
  let i = {};
  if (Array.isArray(r)) {
    const o = r.map((s) => s.args);
    ji(o), i = xt(i, [...o]);
  } else
    i = r.args;
  if (!i)
    return;
  let n = ds(e, t);
  const a = "config";
  return i[a] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), i[n] = i[a], delete i[a]), i;
}, "detectInit"), Ku = /* @__PURE__ */ p(function(e, t = null) {
  var r, i;
  try {
    const n = new RegExp(
      `[%]{2}(?![{]${AC.source})(?=[}][%]{2}).*
`,
      "ig"
    );
    e = e.trim().replace(n, "").replace(/'/gm, '"'), F.debug(
      `Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${e}`
    );
    let a;
    const o = [];
    for (; (a = Xr.exec(e)) !== null; )
      if (a.index === Xr.lastIndex && Xr.lastIndex++, a && !t || t && ((r = a[1]) != null && r.match(t)) || t && ((i = a[2]) != null && i.match(t))) {
        const s = a[1] ? a[1] : a[2], l = a[3] ? a[3].trim() : a[4] ? JSON.parse(a[4].trim()) : null;
        o.push({ type: s, args: l });
      }
    return o.length === 0 ? { type: e, args: null } : o.length === 1 ? o[0] : o;
  } catch (n) {
    return F.error(
      `ERROR: ${n.message} - Unable to parse directive type: '${t}' based on the text: '${e}'`
    ), { type: void 0, args: null };
  }
}, "detectDirective"), EC = /* @__PURE__ */ p(function(e) {
  return e.replace(Xr, "");
}, "removeDirectives"), DC = /* @__PURE__ */ p(function(e, t) {
  for (const [r, i] of t.entries())
    if (i.match(e))
      return r;
  return -1;
}, "isSubstringInArray");
function Ys(e, t) {
  if (!e)
    return t;
  const r = `curve${e.charAt(0).toUpperCase() + e.slice(1)}`;
  return $C[r] ?? t;
}
p(Ys, "interpolateToCurve");
function Qu(e, t) {
  const r = e.trim();
  if (r)
    return t.securityLevel !== "loose" ? Ru(r) : r;
}
p(Qu, "formatUrl");
var OC = /* @__PURE__ */ p((e, ...t) => {
  const r = e.split("."), i = r.length - 1, n = r[i];
  let a = window;
  for (let o = 0; o < i; o++)
    if (a = a[r[o]], !a) {
      F.error(`Function name: ${e} not found in window`);
      return;
    }
  a[n](...t);
}, "runFunc");
function Gs(e, t) {
  return !e || !t ? 0 : Math.sqrt(Math.pow(t.x - e.x, 2) + Math.pow(t.y - e.y, 2));
}
p(Gs, "distance");
function Ju(e) {
  let t, r = 0;
  e.forEach((n) => {
    r += Gs(n, t), t = n;
  });
  const i = r / 2;
  return Us(e, i);
}
p(Ju, "traverseEdge");
function tf(e) {
  return e.length === 1 ? e[0] : Ju(e);
}
p(tf, "calcLabelPosition");
var sl = /* @__PURE__ */ p((e, t = 2) => {
  const r = Math.pow(10, t);
  return Math.round(e * r) / r;
}, "roundNumber"), Us = /* @__PURE__ */ p((e, t) => {
  let r, i = t;
  for (const n of e) {
    if (r) {
      const a = Gs(n, r);
      if (a === 0)
        return r;
      if (a < i)
        i -= a;
      else {
        const o = i / a;
        if (o <= 0)
          return r;
        if (o >= 1)
          return { x: n.x, y: n.y };
        if (o > 0 && o < 1)
          return {
            x: sl((1 - o) * r.x + o * n.x, 5),
            y: sl((1 - o) * r.y + o * n.y, 5)
          };
      }
    }
    r = n;
  }
  throw new Error("Could not find a suitable point for the given distance");
}, "calculatePoint"), RC = /* @__PURE__ */ p((e, t, r) => {
  F.info(`our points ${JSON.stringify(t)}`), t[0] !== r && (t = t.reverse());
  const n = Us(t, 25), a = e ? 10 : 5, o = Math.atan2(t[0].y - n.y, t[0].x - n.x), s = { x: 0, y: 0 };
  return s.x = Math.sin(o) * a + (t[0].x + n.x) / 2, s.y = -Math.cos(o) * a + (t[0].y + n.y) / 2, s;
}, "calcCardinalityPosition");
function ef(e, t, r) {
  const i = structuredClone(r);
  F.info("our points", i), t !== "start_left" && t !== "start_right" && i.reverse();
  const n = 25 + e, a = Us(i, n), o = 10 + e * 0.5, s = Math.atan2(i[0].y - a.y, i[0].x - a.x), l = { x: 0, y: 0 };
  return t === "start_left" ? (l.x = Math.sin(s + Math.PI) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s + Math.PI) * o + (i[0].y + a.y) / 2) : t === "end_right" ? (l.x = Math.sin(s - Math.PI) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s - Math.PI) * o + (i[0].y + a.y) / 2 - 5) : t === "end_left" ? (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2 - 5, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2 - 5) : (l.x = Math.sin(s) * o + (i[0].x + a.x) / 2, l.y = -Math.cos(s) * o + (i[0].y + a.y) / 2), l;
}
p(ef, "calcTerminalLabelPosition");
function rf(e) {
  let t = "", r = "";
  for (const i of e)
    i !== void 0 && (i.startsWith("color:") || i.startsWith("text-align:") ? r = r + i + ";" : t = t + i + ";");
  return { style: t, labelStyle: r };
}
p(rf, "getStylesFromArray");
var ol = 0, IC = /* @__PURE__ */ p(() => (ol++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + ol), "generateId");
function nf(e) {
  let t = "";
  const r = "0123456789abcdef", i = r.length;
  for (let n = 0; n < e; n++)
    t += r.charAt(Math.floor(Math.random() * i));
  return t;
}
p(nf, "makeRandomHex");
var PC = /* @__PURE__ */ p((e) => nf(e.length), "random"), NC = /* @__PURE__ */ p(function() {
  return {
    x: 0,
    y: 0,
    fill: void 0,
    anchor: "start",
    style: "#666",
    width: 100,
    height: 100,
    textMargin: 0,
    rx: 0,
    ry: 0,
    valign: void 0,
    text: ""
  };
}, "getTextObj"), zC = /* @__PURE__ */ p(function(e, t) {
  const r = t.text.replace(kr.lineBreakRegex, " "), [, i] = Hn(t.fontSize), n = e.append("text");
  n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", i), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class);
  const a = n.append("tspan");
  return a.attr("x", t.x + t.textMargin * 2), a.attr("fill", t.fill), a.text(r), n;
}, "drawSimpleText"), qC = mi(
  (e, t, r) => {
    if (!e || (r = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" },
      r
    ), kr.lineBreakRegex.test(e)))
      return e;
    const i = e.split(" ").filter(Boolean), n = [];
    let a = "";
    return i.forEach((o, s) => {
      const l = ge(`${o} `, r), c = ge(a, r);
      if (l > t) {
        const { hyphenatedStrings: f, remainingWord: d } = WC(o, t, "-", r);
        n.push(a, ...f), a = d;
      } else c + l >= t ? (n.push(a), a = o) : a = [a, o].filter(Boolean).join(" ");
      s + 1 === i.length && n.push(a);
    }), n.filter((o) => o !== "").join(r.joinWith);
  },
  (e, t, r) => `${e}${t}${r.fontSize}${r.fontWeight}${r.fontFamily}${r.joinWith}`
), WC = mi(
  (e, t, r = "-", i) => {
    i = Object.assign(
      { fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 },
      i
    );
    const n = [...e], a = [];
    let o = "";
    return n.forEach((s, l) => {
      const c = `${o}${s}`;
      if (ge(c, i) >= t) {
        const u = l + 1, f = n.length === u, d = `${c}${r}`;
        a.push(f ? c : d), o = "";
      } else
        o = c;
    }), { hyphenatedStrings: a, remainingWord: o };
  },
  (e, t, r = "-", i) => `${e}${t}${r}${i.fontSize}${i.fontWeight}${i.fontFamily}`
);
function af(e, t) {
  return Xs(e, t).height;
}
p(af, "calculateTextHeight");
function ge(e, t) {
  return Xs(e, t).width;
}
p(ge, "calculateTextWidth");
var Xs = mi(
  (e, t) => {
    const { fontSize: r = 12, fontFamily: i = "Arial", fontWeight: n = 400 } = t;
    if (!e)
      return { width: 0, height: 0 };
    const [, a] = Hn(r), o = ["sans-serif", i], s = e.split(kr.lineBreakRegex), l = [], c = rt("body");
    if (!c.remove)
      return { width: 0, height: 0, lineHeight: 0 };
    const h = c.append("svg");
    for (const f of o) {
      let d = 0;
      const g = { width: 0, height: 0, lineHeight: 0 };
      for (const m of s) {
        const x = NC();
        x.text = m || MC;
        const y = zC(h, x).style("font-size", a).style("font-weight", n).style("font-family", f), b = (y._groups || y)[0][0].getBBox();
        if (b.width === 0 && b.height === 0)
          throw new Error("svg element not in render tree");
        g.width = Math.round(Math.max(g.width, b.width)), d = Math.round(b.height), g.height += d, g.lineHeight = Math.round(Math.max(g.lineHeight, d));
      }
      l.push(g);
    }
    h.remove();
    const u = isNaN(l[1].height) || isNaN(l[1].width) || isNaN(l[1].lineHeight) || l[0].height > l[1].height && l[0].width > l[1].width && l[0].lineHeight > l[1].lineHeight ? 0 : 1;
    return l[u];
  },
  (e, t) => `${e}${t.fontSize}${t.fontWeight}${t.fontFamily}`
), pr, HC = (pr = class {
  constructor(t = !1, r) {
    this.count = 0, this.count = r ? r.length : 0, this.next = t ? () => this.count++ : () => Date.now();
  }
}, p(pr, "InitIDGenerator"), pr), ki, jC = /* @__PURE__ */ p(function(e) {
  return ki = ki || document.createElement("div"), e = escape(e).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), ki.innerHTML = e, unescape(ki.textContent);
}, "entityDecode");
function Vs(e) {
  return "str" in e;
}
p(Vs, "isDetailedError");
var YC = /* @__PURE__ */ p((e, t, r, i) => {
  var a;
  if (!i)
    return;
  const n = (a = e.node()) == null ? void 0 : a.getBBox();
  n && e.append("text").text(i).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -r).attr("class", t);
}, "insertTitle"), Hn = /* @__PURE__ */ p((e) => {
  if (typeof e == "number")
    return [e, e + "px"];
  const t = parseInt(e ?? "", 10);
  return Number.isNaN(t) ? [void 0, void 0] : e === String(t) ? [t, e + "px"] : [t, e];
}, "parseFontSize");
function Zs(e, t) {
  return LC({}, e, t);
}
p(Zs, "cleanAndMerge");
var Ut = {
  assignWithDepth: xt,
  wrapLabel: qC,
  calculateTextHeight: af,
  calculateTextWidth: ge,
  calculateTextDimensions: Xs,
  cleanAndMerge: Zs,
  detectInit: FC,
  detectDirective: Ku,
  isSubstringInArray: DC,
  interpolateToCurve: Ys,
  calcLabelPosition: tf,
  calcCardinalityPosition: RC,
  calcTerminalLabelPosition: ef,
  formatUrl: Qu,
  getStylesFromArray: rf,
  generateId: IC,
  random: PC,
  runFunc: OC,
  entityDecode: jC,
  insertTitle: YC,
  isLabelCoordinateInPath: sf,
  parseFontSize: Hn,
  InitIDGenerator: HC
}, GC = /* @__PURE__ */ p(function(e) {
  let t = e;
  return t = t.replace(/style.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/classDef.*:\S*#.*;/g, function(r) {
    return r.substring(0, r.length - 1);
  }), t = t.replace(/#\w+;/g, function(r) {
    const i = r.substring(1, r.length - 1);
    return /^\+?\d+$/.test(i) ? "ﬂ°°" + i + "¶ß" : "ﬂ°" + i + "¶ß";
  }), t;
}, "encodeEntities"), Ke = /* @__PURE__ */ p(function(e) {
  return e.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";");
}, "decodeEntities"), YT = /* @__PURE__ */ p((e, t, {
  counter: r = 0,
  prefix: i,
  suffix: n
}, a) => a || `${i ? `${i}_` : ""}${e}_${t}_${r}${n ? `_${n}` : ""}`, "getEdgeId");
function Mt(e) {
  return e ?? null;
}
p(Mt, "handleUndefinedAttr");
function sf(e, t) {
  const r = Math.round(e.x), i = Math.round(e.y), n = t.replace(
    /(\d+\.\d+)/g,
    (a) => Math.round(parseFloat(a)).toString()
  );
  return n.includes(r.toString()) || n.includes(i.toString());
}
p(sf, "isLabelCoordinateInPath");
const UC = Object.freeze({
  left: 0,
  top: 0,
  width: 16,
  height: 16
}), mn = Object.freeze({
  rotate: 0,
  vFlip: !1,
  hFlip: !1
}), of = Object.freeze({
  ...UC,
  ...mn
}), XC = Object.freeze({
  ...of,
  body: "",
  hidden: !1
}), VC = Object.freeze({
  width: null,
  height: null
}), ZC = Object.freeze({
  ...VC,
  ...mn
}), KC = (e, t, r, i = "") => {
  const n = e.split(":");
  if (e.slice(0, 1) === "@") {
    if (n.length < 2 || n.length > 3) return null;
    i = n.shift().slice(1);
  }
  if (n.length > 3 || !n.length) return null;
  if (n.length > 1) {
    const s = n.pop(), l = n.pop(), c = {
      provider: n.length > 0 ? n[0] : i,
      prefix: l,
      name: s
    };
    return oa(c) ? c : null;
  }
  const a = n[0], o = a.split("-");
  if (o.length > 1) {
    const s = {
      provider: i,
      prefix: o.shift(),
      name: o.join("-")
    };
    return oa(s) ? s : null;
  }
  if (r && i === "") {
    const s = {
      provider: i,
      prefix: "",
      name: a
    };
    return oa(s, r) ? s : null;
  }
  return null;
}, oa = (e, t) => e ? !!((t && e.prefix === "" || e.prefix) && e.name) : !1;
function QC(e, t) {
  const r = {};
  !e.hFlip != !t.hFlip && (r.hFlip = !0), !e.vFlip != !t.vFlip && (r.vFlip = !0);
  const i = ((e.rotate || 0) + (t.rotate || 0)) % 4;
  return i && (r.rotate = i), r;
}
function ll(e, t) {
  const r = QC(e, t);
  for (const i in XC) i in mn ? i in e && !(i in r) && (r[i] = mn[i]) : i in t ? r[i] = t[i] : i in e && (r[i] = e[i]);
  return r;
}
function JC(e, t) {
  const r = e.icons, i = e.aliases || /* @__PURE__ */ Object.create(null), n = /* @__PURE__ */ Object.create(null);
  function a(o) {
    if (r[o]) return n[o] = [];
    if (!(o in n)) {
      n[o] = null;
      const s = i[o] && i[o].parent, l = s && a(s);
      l && (n[o] = [s].concat(l));
    }
    return n[o];
  }
  return (t || Object.keys(r).concat(Object.keys(i))).forEach(a), n;
}
function cl(e, t, r) {
  const i = e.icons, n = e.aliases || /* @__PURE__ */ Object.create(null);
  let a = {};
  function o(s) {
    a = ll(i[s] || n[s], a);
  }
  return o(t), r.forEach(o), ll(e, a);
}
function tw(e, t) {
  if (e.icons[t]) return cl(e, t, []);
  const r = JC(e, [t])[t];
  return r ? cl(e, t, r) : null;
}
const ew = /(-?[0-9.]*[0-9]+[0-9.]*)/g, rw = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function hl(e, t, r) {
  if (t === 1) return e;
  if (r = r || 100, typeof e == "number") return Math.ceil(e * t * r) / r;
  if (typeof e != "string") return e;
  const i = e.split(ew);
  if (i === null || !i.length) return e;
  const n = [];
  let a = i.shift(), o = rw.test(a);
  for (; ; ) {
    if (o) {
      const s = parseFloat(a);
      isNaN(s) ? n.push(a) : n.push(Math.ceil(s * t * r) / r);
    } else n.push(a);
    if (a = i.shift(), a === void 0) return n.join("");
    o = !o;
  }
}
function iw(e, t = "defs") {
  let r = "";
  const i = e.indexOf("<" + t);
  for (; i >= 0; ) {
    const n = e.indexOf(">", i), a = e.indexOf("</" + t);
    if (n === -1 || a === -1) break;
    const o = e.indexOf(">", a);
    if (o === -1) break;
    r += e.slice(n + 1, a).trim(), e = e.slice(0, i).trim() + e.slice(o + 1);
  }
  return {
    defs: r,
    content: e
  };
}
function nw(e, t) {
  return e ? "<defs>" + e + "</defs>" + t : t;
}
function aw(e, t, r) {
  const i = iw(e);
  return nw(i.defs, t + i.content + r);
}
const sw = (e) => e === "unset" || e === "undefined" || e === "none";
function ow(e, t) {
  const r = {
    ...of,
    ...e
  }, i = {
    ...ZC,
    ...t
  }, n = {
    left: r.left,
    top: r.top,
    width: r.width,
    height: r.height
  };
  let a = r.body;
  [r, i].forEach((m) => {
    const x = [], y = m.hFlip, b = m.vFlip;
    let w = m.rotate;
    y ? b ? w += 2 : (x.push("translate(" + (n.width + n.left).toString() + " " + (0 - n.top).toString() + ")"), x.push("scale(-1 1)"), n.top = n.left = 0) : b && (x.push("translate(" + (0 - n.left).toString() + " " + (n.height + n.top).toString() + ")"), x.push("scale(1 -1)"), n.top = n.left = 0);
    let k;
    switch (w < 0 && (w -= Math.floor(w / 4) * 4), w = w % 4, w) {
      case 1:
        k = n.height / 2 + n.top, x.unshift("rotate(90 " + k.toString() + " " + k.toString() + ")");
        break;
      case 2:
        x.unshift("rotate(180 " + (n.width / 2 + n.left).toString() + " " + (n.height / 2 + n.top).toString() + ")");
        break;
      case 3:
        k = n.width / 2 + n.left, x.unshift("rotate(-90 " + k.toString() + " " + k.toString() + ")");
        break;
    }
    w % 2 === 1 && (n.left !== n.top && (k = n.left, n.left = n.top, n.top = k), n.width !== n.height && (k = n.width, n.width = n.height, n.height = k)), x.length && (a = aw(a, '<g transform="' + x.join(" ") + '">', "</g>"));
  });
  const o = i.width, s = i.height, l = n.width, c = n.height;
  let h, u;
  o === null ? (u = s === null ? "1em" : s === "auto" ? c : s, h = hl(u, l / c)) : (h = o === "auto" ? l : o, u = s === null ? hl(h, c / l) : s === "auto" ? c : s);
  const f = {}, d = (m, x) => {
    sw(x) || (f[m] = x.toString());
  };
  d("width", h), d("height", u);
  const g = [
    n.left,
    n.top,
    l,
    c
  ];
  return f.viewBox = g.join(" "), {
    attributes: f,
    viewBox: g,
    body: a
  };
}
const lw = /\sid="(\S+)"/g, cw = "IconifyId" + Date.now().toString(16) + (Math.random() * 16777216 | 0).toString(16);
let hw = 0;
function uw(e, t = cw) {
  const r = [];
  let i;
  for (; i = lw.exec(e); ) r.push(i[1]);
  if (!r.length) return e;
  const n = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16);
  return r.forEach((a) => {
    const o = typeof t == "function" ? t(a) : t + (hw++).toString(), s = a.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    e = e.replace(new RegExp('([#;"])(' + s + ')([")]|\\.[a-z])', "g"), "$1" + o + n + "$3");
  }), e = e.replace(new RegExp(n, "g"), ""), e;
}
function fw(e, t) {
  let r = e.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"';
  for (const i in t) r += " " + i + '="' + t[i] + '"';
  return '<svg xmlns="http://www.w3.org/2000/svg"' + r + ">" + e + "</svg>";
}
function Ks() {
  return {
    async: !1,
    breaks: !1,
    extensions: null,
    gfm: !0,
    hooks: null,
    pedantic: !1,
    renderer: null,
    silent: !1,
    tokenizer: null,
    walkTokens: null
  };
}
var Qe = Ks();
function lf(e) {
  Qe = e;
}
var Kr = { exec: () => null };
function st(e, t = "") {
  let r = typeof e == "string" ? e : e.source;
  const i = {
    replace: (n, a) => {
      let o = typeof a == "string" ? a : a.source;
      return o = o.replace(Dt.caret, "$1"), r = r.replace(n, o), i;
    },
    getRegex: () => new RegExp(r, t)
  };
  return i;
}
var Dt = {
  codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm,
  outputLinkReplace: /\\([\[\]])/g,
  indentCodeCompensation: /^(\s+)(?:```)/,
  beginningSpace: /^\s+/,
  endingHash: /#$/,
  startingSpaceChar: /^ /,
  endingSpaceChar: / $/,
  nonSpaceChar: /[^ ]/,
  newLineCharGlobal: /\n/g,
  tabCharGlobal: /\t/g,
  multipleSpaceGlobal: /\s+/g,
  blankLine: /^[ \t]*$/,
  doubleBlankLine: /\n[ \t]*\n[ \t]*$/,
  blockquoteStart: /^ {0,3}>/,
  blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g,
  blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm,
  listReplaceTabs: /^\t+/,
  listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g,
  listIsTask: /^\[[ xX]\] /,
  listReplaceTask: /^\[[ xX]\] +/,
  anyLine: /\n.*\n/,
  hrefBrackets: /^<(.*)>$/,
  tableDelimiter: /[:|]/,
  tableAlignChars: /^\||\| *$/g,
  tableRowBlankLine: /\n[ \t]*$/,
  tableAlignRight: /^ *-+: *$/,
  tableAlignCenter: /^ *:-+: *$/,
  tableAlignLeft: /^ *:-+ *$/,
  startATag: /^<a /i,
  endATag: /^<\/a>/i,
  startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i,
  endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i,
  startAngleBracket: /^</,
  endAngleBracket: />$/,
  pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/,
  unicodeAlphaNumeric: /[\p{L}\p{N}]/u,
  escapeTest: /[&<>"']/,
  escapeReplace: /[&<>"']/g,
  escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/,
  escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g,
  unescapeTest: /&(#(?:\d+)|(?:#x[0-9A-Fa-f]+)|(?:\w+));?/ig,
  caret: /(^|[^\[])\^/g,
  percentDecode: /%25/g,
  findPipe: /\|/g,
  splitPipe: / \|/,
  slashPipe: /\\\|/g,
  carriageReturn: /\r\n|\r/g,
  spaceLine: /^ +$/gm,
  notSpaceStart: /^\S*/,
  endingNewline: /\n$/,
  listItemRegex: (e) => new RegExp(`^( {0,3}${e})((?:[	 ][^\\n]*)?(?:\\n|$))`),
  nextBulletRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`),
  hrRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`),
  fencesBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}(?:\`\`\`|~~~)`),
  headingBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}#`),
  htmlBeginRegex: (e) => new RegExp(`^ {0,${Math.min(3, e - 1)}}<(?:[a-z].*>|!--)`, "i")
}, dw = /^(?:[ \t]*(?:\n|$))+/, pw = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, gw = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, xi = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, mw = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, Qs = /(?:[*+-]|\d{1,9}[.)])/, cf = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, hf = st(cf).replace(/bull/g, Qs).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), yw = st(cf).replace(/bull/g, Qs).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), Js = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, xw = /^[^\n]+/, to = /(?!\s*\])(?:\\.|[^\[\]\\])+/, bw = st(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", to).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Cw = st(/^( {0,3}bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, Qs).getRegex(), jn = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", eo = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, ww = st(
  "^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))",
  "i"
).replace("comment", eo).replace("tag", jn).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), uf = st(Js).replace("hr", xi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", jn).getRegex(), _w = st(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", uf).getRegex(), ro = {
  blockquote: _w,
  code: pw,
  def: bw,
  fences: gw,
  heading: mw,
  hr: xi,
  html: ww,
  lheading: hf,
  list: Cw,
  newline: dw,
  paragraph: uf,
  table: Kr,
  text: xw
}, ul = st(
  "^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)"
).replace("hr", xi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", jn).getRegex(), vw = {
  ...ro,
  lheading: yw,
  table: ul,
  paragraph: st(Js).replace("hr", xi).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", ul).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)]) ").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", jn).getRegex()
}, kw = {
  ...ro,
  html: st(
    `^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`
  ).replace("comment", eo).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(),
  def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/,
  heading: /^(#{1,6})(.*)(?:\n+|$)/,
  fences: Kr,
  // fences not supported
  lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/,
  paragraph: st(Js).replace("hr", xi).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", hf).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex()
}, Sw = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, Tw = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ff = /^( {2,}|\\)\n(?!\s*$)/, Bw = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, Yn = /[\p{P}\p{S}]/u, io = /[\s\p{P}\p{S}]/u, df = /[^\s\p{P}\p{S}]/u, Lw = st(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, io).getRegex(), pf = /(?!~)[\p{P}\p{S}]/u, Mw = /(?!~)[\s\p{P}\p{S}]/u, $w = /(?:[^\s\p{P}\p{S}]|~)/u, Aw = /\[[^[\]]*?\]\((?:\\.|[^\\\(\)]|\((?:\\.|[^\\\(\)])*\))*\)|`[^`]*?`|<[^<>]*?>/g, gf = /^(?:\*+(?:((?!\*)punct)|[^\s*]))|^_+(?:((?!_)punct)|([^\s_]))/, Fw = st(gf, "u").replace(/punct/g, Yn).getRegex(), Ew = st(gf, "u").replace(/punct/g, pf).getRegex(), mf = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Dw = st(mf, "gu").replace(/notPunctSpace/g, df).replace(/punctSpace/g, io).replace(/punct/g, Yn).getRegex(), Ow = st(mf, "gu").replace(/notPunctSpace/g, $w).replace(/punctSpace/g, Mw).replace(/punct/g, pf).getRegex(), Rw = st(
  "^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)",
  "gu"
).replace(/notPunctSpace/g, df).replace(/punctSpace/g, io).replace(/punct/g, Yn).getRegex(), Iw = st(/\\(punct)/, "gu").replace(/punct/g, Yn).getRegex(), Pw = st(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Nw = st(eo).replace("(?:-->|$)", "-->").getRegex(), zw = st(
  "^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>"
).replace("comment", Nw).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), yn = /(?:\[(?:\\.|[^\[\]\\])*\]|\\.|`[^`]*`|[^\[\]\\`])*?/, qw = st(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]*(?:\n[ \t]*)?)(title))?\s*\)/).replace("label", yn).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), yf = st(/^!?\[(label)\]\[(ref)\]/).replace("label", yn).replace("ref", to).getRegex(), xf = st(/^!?\[(ref)\](?:\[\])?/).replace("ref", to).getRegex(), Ww = st("reflink|nolink(?!\\()", "g").replace("reflink", yf).replace("nolink", xf).getRegex(), no = {
  _backpedal: Kr,
  // only used for GFM url
  anyPunctuation: Iw,
  autolink: Pw,
  blockSkip: Aw,
  br: ff,
  code: Tw,
  del: Kr,
  emStrongLDelim: Fw,
  emStrongRDelimAst: Dw,
  emStrongRDelimUnd: Rw,
  escape: Sw,
  link: qw,
  nolink: xf,
  punctuation: Lw,
  reflink: yf,
  reflinkSearch: Ww,
  tag: zw,
  text: Bw,
  url: Kr
}, Hw = {
  ...no,
  link: st(/^!?\[(label)\]\((.*?)\)/).replace("label", yn).getRegex(),
  reflink: st(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", yn).getRegex()
}, Xa = {
  ...no,
  emStrongRDelimAst: Ow,
  emStrongLDelim: Ew,
  url: st(/^((?:ftp|https?):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/, "i").replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(),
  _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/,
  del: /^(~~?)(?=[^\s~])((?:\\.|[^\\])*?(?:\\.|[^\s~\\]))\1(?=[^~]|$)/,
  text: /^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|https?:\/\/|ftp:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/
}, jw = {
  ...Xa,
  br: st(ff).replace("{2,}", "*").getRegex(),
  text: st(Xa.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex()
}, Si = {
  normal: ro,
  gfm: vw,
  pedantic: kw
}, Er = {
  normal: no,
  gfm: Xa,
  breaks: jw,
  pedantic: Hw
}, Yw = {
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
}, fl = (e) => Yw[e];
function Qt(e, t) {
  if (t) {
    if (Dt.escapeTest.test(e))
      return e.replace(Dt.escapeReplace, fl);
  } else if (Dt.escapeTestNoEncode.test(e))
    return e.replace(Dt.escapeReplaceNoEncode, fl);
  return e;
}
function dl(e) {
  try {
    e = encodeURI(e).replace(Dt.percentDecode, "%");
  } catch {
    return null;
  }
  return e;
}
function pl(e, t) {
  var a;
  const r = e.replace(Dt.findPipe, (o, s, l) => {
    let c = !1, h = s;
    for (; --h >= 0 && l[h] === "\\"; ) c = !c;
    return c ? "|" : " |";
  }), i = r.split(Dt.splitPipe);
  let n = 0;
  if (i[0].trim() || i.shift(), i.length > 0 && !((a = i.at(-1)) != null && a.trim()) && i.pop(), t)
    if (i.length > t)
      i.splice(t);
    else
      for (; i.length < t; ) i.push("");
  for (; n < i.length; n++)
    i[n] = i[n].trim().replace(Dt.slashPipe, "|");
  return i;
}
function Dr(e, t, r) {
  const i = e.length;
  if (i === 0)
    return "";
  let n = 0;
  for (; n < i && e.charAt(i - n - 1) === t; )
    n++;
  return e.slice(0, i - n);
}
function Gw(e, t) {
  if (e.indexOf(t[1]) === -1)
    return -1;
  let r = 0;
  for (let i = 0; i < e.length; i++)
    if (e[i] === "\\")
      i++;
    else if (e[i] === t[0])
      r++;
    else if (e[i] === t[1] && (r--, r < 0))
      return i;
  return r > 0 ? -2 : -1;
}
function gl(e, t, r, i, n) {
  const a = t.href, o = t.title || null, s = e[1].replace(n.other.outputLinkReplace, "$1");
  i.state.inLink = !0;
  const l = {
    type: e[0].charAt(0) === "!" ? "image" : "link",
    raw: r,
    href: a,
    title: o,
    text: s,
    tokens: i.inlineTokens(s)
  };
  return i.state.inLink = !1, l;
}
function Uw(e, t, r) {
  const i = e.match(r.other.indentCodeCompensation);
  if (i === null)
    return t;
  const n = i[1];
  return t.split(`
`).map((a) => {
    const o = a.match(r.other.beginningSpace);
    if (o === null)
      return a;
    const [s] = o;
    return s.length >= n.length ? a.slice(n.length) : a;
  }).join(`
`);
}
var xn = class {
  // set by the lexer
  constructor(e) {
    ot(this, "options");
    ot(this, "rules");
    // set by the lexer
    ot(this, "lexer");
    this.options = e || Qe;
  }
  space(e) {
    const t = this.rules.block.newline.exec(e);
    if (t && t[0].length > 0)
      return {
        type: "space",
        raw: t[0]
      };
  }
  code(e) {
    const t = this.rules.block.code.exec(e);
    if (t) {
      const r = t[0].replace(this.rules.other.codeRemoveIndent, "");
      return {
        type: "code",
        raw: t[0],
        codeBlockStyle: "indented",
        text: this.options.pedantic ? r : Dr(r, `
`)
      };
    }
  }
  fences(e) {
    const t = this.rules.block.fences.exec(e);
    if (t) {
      const r = t[0], i = Uw(r, t[3] || "", this.rules);
      return {
        type: "code",
        raw: r,
        lang: t[2] ? t[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : t[2],
        text: i
      };
    }
  }
  heading(e) {
    const t = this.rules.block.heading.exec(e);
    if (t) {
      let r = t[2].trim();
      if (this.rules.other.endingHash.test(r)) {
        const i = Dr(r, "#");
        (this.options.pedantic || !i || this.rules.other.endingSpaceChar.test(i)) && (r = i.trim());
      }
      return {
        type: "heading",
        raw: t[0],
        depth: t[1].length,
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  hr(e) {
    const t = this.rules.block.hr.exec(e);
    if (t)
      return {
        type: "hr",
        raw: Dr(t[0], `
`)
      };
  }
  blockquote(e) {
    const t = this.rules.block.blockquote.exec(e);
    if (t) {
      let r = Dr(t[0], `
`).split(`
`), i = "", n = "";
      const a = [];
      for (; r.length > 0; ) {
        let o = !1;
        const s = [];
        let l;
        for (l = 0; l < r.length; l++)
          if (this.rules.other.blockquoteStart.test(r[l]))
            s.push(r[l]), o = !0;
          else if (!o)
            s.push(r[l]);
          else
            break;
        r = r.slice(l);
        const c = s.join(`
`), h = c.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
        i = i ? `${i}
${c}` : c, n = n ? `${n}
${h}` : h;
        const u = this.lexer.state.top;
        if (this.lexer.state.top = !0, this.lexer.blockTokens(h, a, !0), this.lexer.state.top = u, r.length === 0)
          break;
        const f = a.at(-1);
        if ((f == null ? void 0 : f.type) === "code")
          break;
        if ((f == null ? void 0 : f.type) === "blockquote") {
          const d = f, g = d.raw + `
` + r.join(`
`), m = this.blockquote(g);
          a[a.length - 1] = m, i = i.substring(0, i.length - d.raw.length) + m.raw, n = n.substring(0, n.length - d.text.length) + m.text;
          break;
        } else if ((f == null ? void 0 : f.type) === "list") {
          const d = f, g = d.raw + `
` + r.join(`
`), m = this.list(g);
          a[a.length - 1] = m, i = i.substring(0, i.length - f.raw.length) + m.raw, n = n.substring(0, n.length - d.raw.length) + m.raw, r = g.substring(a.at(-1).raw.length).split(`
`);
          continue;
        }
      }
      return {
        type: "blockquote",
        raw: i,
        tokens: a,
        text: n
      };
    }
  }
  list(e) {
    let t = this.rules.block.list.exec(e);
    if (t) {
      let r = t[1].trim();
      const i = r.length > 1, n = {
        type: "list",
        raw: "",
        ordered: i,
        start: i ? +r.slice(0, -1) : "",
        loose: !1,
        items: []
      };
      r = i ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = i ? r : "[*+-]");
      const a = this.rules.other.listItemRegex(r);
      let o = !1;
      for (; e; ) {
        let l = !1, c = "", h = "";
        if (!(t = a.exec(e)) || this.rules.block.hr.test(e))
          break;
        c = t[0], e = e.substring(c.length);
        let u = t[2].split(`
`, 1)[0].replace(this.rules.other.listReplaceTabs, (y) => " ".repeat(3 * y.length)), f = e.split(`
`, 1)[0], d = !u.trim(), g = 0;
        if (this.options.pedantic ? (g = 2, h = u.trimStart()) : d ? g = t[1].length + 1 : (g = t[2].search(this.rules.other.nonSpaceChar), g = g > 4 ? 1 : g, h = u.slice(g), g += t[1].length), d && this.rules.other.blankLine.test(f) && (c += f + `
`, e = e.substring(f.length + 1), l = !0), !l) {
          const y = this.rules.other.nextBulletRegex(g), b = this.rules.other.hrRegex(g), w = this.rules.other.fencesBeginRegex(g), k = this.rules.other.headingBeginRegex(g), _ = this.rules.other.htmlBeginRegex(g);
          for (; e; ) {
            const C = e.split(`
`, 1)[0];
            let v;
            if (f = C, this.options.pedantic ? (f = f.replace(this.rules.other.listReplaceNesting, "  "), v = f) : v = f.replace(this.rules.other.tabCharGlobal, "    "), w.test(f) || k.test(f) || _.test(f) || y.test(f) || b.test(f))
              break;
            if (v.search(this.rules.other.nonSpaceChar) >= g || !f.trim())
              h += `
` + v.slice(g);
            else {
              if (d || u.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || w.test(u) || k.test(u) || b.test(u))
                break;
              h += `
` + f;
            }
            !d && !f.trim() && (d = !0), c += C + `
`, e = e.substring(C.length + 1), u = v.slice(g);
          }
        }
        n.loose || (o ? n.loose = !0 : this.rules.other.doubleBlankLine.test(c) && (o = !0));
        let m = null, x;
        this.options.gfm && (m = this.rules.other.listIsTask.exec(h), m && (x = m[0] !== "[ ] ", h = h.replace(this.rules.other.listReplaceTask, ""))), n.items.push({
          type: "list_item",
          raw: c,
          task: !!m,
          checked: x,
          loose: !1,
          text: h,
          tokens: []
        }), n.raw += c;
      }
      const s = n.items.at(-1);
      if (s)
        s.raw = s.raw.trimEnd(), s.text = s.text.trimEnd();
      else
        return;
      n.raw = n.raw.trimEnd();
      for (let l = 0; l < n.items.length; l++)
        if (this.lexer.state.top = !1, n.items[l].tokens = this.lexer.blockTokens(n.items[l].text, []), !n.loose) {
          const c = n.items[l].tokens.filter((u) => u.type === "space"), h = c.length > 0 && c.some((u) => this.rules.other.anyLine.test(u.raw));
          n.loose = h;
        }
      if (n.loose)
        for (let l = 0; l < n.items.length; l++)
          n.items[l].loose = !0;
      return n;
    }
  }
  html(e) {
    const t = this.rules.block.html.exec(e);
    if (t)
      return {
        type: "html",
        block: !0,
        raw: t[0],
        pre: t[1] === "pre" || t[1] === "script" || t[1] === "style",
        text: t[0]
      };
  }
  def(e) {
    const t = this.rules.block.def.exec(e);
    if (t) {
      const r = t[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), i = t[2] ? t[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", n = t[3] ? t[3].substring(1, t[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : t[3];
      return {
        type: "def",
        tag: r,
        raw: t[0],
        href: i,
        title: n
      };
    }
  }
  table(e) {
    var o;
    const t = this.rules.block.table.exec(e);
    if (!t || !this.rules.other.tableDelimiter.test(t[2]))
      return;
    const r = pl(t[1]), i = t[2].replace(this.rules.other.tableAlignChars, "").split("|"), n = (o = t[3]) != null && o.trim() ? t[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], a = {
      type: "table",
      raw: t[0],
      header: [],
      align: [],
      rows: []
    };
    if (r.length === i.length) {
      for (const s of i)
        this.rules.other.tableAlignRight.test(s) ? a.align.push("right") : this.rules.other.tableAlignCenter.test(s) ? a.align.push("center") : this.rules.other.tableAlignLeft.test(s) ? a.align.push("left") : a.align.push(null);
      for (let s = 0; s < r.length; s++)
        a.header.push({
          text: r[s],
          tokens: this.lexer.inline(r[s]),
          header: !0,
          align: a.align[s]
        });
      for (const s of n)
        a.rows.push(pl(s, a.header.length).map((l, c) => ({
          text: l,
          tokens: this.lexer.inline(l),
          header: !1,
          align: a.align[c]
        })));
      return a;
    }
  }
  lheading(e) {
    const t = this.rules.block.lheading.exec(e);
    if (t)
      return {
        type: "heading",
        raw: t[0],
        depth: t[2].charAt(0) === "=" ? 1 : 2,
        text: t[1],
        tokens: this.lexer.inline(t[1])
      };
  }
  paragraph(e) {
    const t = this.rules.block.paragraph.exec(e);
    if (t) {
      const r = t[1].charAt(t[1].length - 1) === `
` ? t[1].slice(0, -1) : t[1];
      return {
        type: "paragraph",
        raw: t[0],
        text: r,
        tokens: this.lexer.inline(r)
      };
    }
  }
  text(e) {
    const t = this.rules.block.text.exec(e);
    if (t)
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        tokens: this.lexer.inline(t[0])
      };
  }
  escape(e) {
    const t = this.rules.inline.escape.exec(e);
    if (t)
      return {
        type: "escape",
        raw: t[0],
        text: t[1]
      };
  }
  tag(e) {
    const t = this.rules.inline.tag.exec(e);
    if (t)
      return !this.lexer.state.inLink && this.rules.other.startATag.test(t[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(t[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(t[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(t[0]) && (this.lexer.state.inRawBlock = !1), {
        type: "html",
        raw: t[0],
        inLink: this.lexer.state.inLink,
        inRawBlock: this.lexer.state.inRawBlock,
        block: !1,
        text: t[0]
      };
  }
  link(e) {
    const t = this.rules.inline.link.exec(e);
    if (t) {
      const r = t[2].trim();
      if (!this.options.pedantic && this.rules.other.startAngleBracket.test(r)) {
        if (!this.rules.other.endAngleBracket.test(r))
          return;
        const a = Dr(r.slice(0, -1), "\\");
        if ((r.length - a.length) % 2 === 0)
          return;
      } else {
        const a = Gw(t[2], "()");
        if (a === -2)
          return;
        if (a > -1) {
          const s = (t[0].indexOf("!") === 0 ? 5 : 4) + t[1].length + a;
          t[2] = t[2].substring(0, a), t[0] = t[0].substring(0, s).trim(), t[3] = "";
        }
      }
      let i = t[2], n = "";
      if (this.options.pedantic) {
        const a = this.rules.other.pedanticHrefTitle.exec(i);
        a && (i = a[1], n = a[3]);
      } else
        n = t[3] ? t[3].slice(1, -1) : "";
      return i = i.trim(), this.rules.other.startAngleBracket.test(i) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(r) ? i = i.slice(1) : i = i.slice(1, -1)), gl(t, {
        href: i && i.replace(this.rules.inline.anyPunctuation, "$1"),
        title: n && n.replace(this.rules.inline.anyPunctuation, "$1")
      }, t[0], this.lexer, this.rules);
    }
  }
  reflink(e, t) {
    let r;
    if ((r = this.rules.inline.reflink.exec(e)) || (r = this.rules.inline.nolink.exec(e))) {
      const i = (r[2] || r[1]).replace(this.rules.other.multipleSpaceGlobal, " "), n = t[i.toLowerCase()];
      if (!n) {
        const a = r[0].charAt(0);
        return {
          type: "text",
          raw: a,
          text: a
        };
      }
      return gl(r, n, r[0], this.lexer, this.rules);
    }
  }
  emStrong(e, t, r = "") {
    let i = this.rules.inline.emStrongLDelim.exec(e);
    if (!i || i[3] && r.match(this.rules.other.unicodeAlphaNumeric)) return;
    if (!(i[1] || i[2] || "") || !r || this.rules.inline.punctuation.exec(r)) {
      const a = [...i[0]].length - 1;
      let o, s, l = a, c = 0;
      const h = i[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
      for (h.lastIndex = 0, t = t.slice(-1 * e.length + a); (i = h.exec(t)) != null; ) {
        if (o = i[1] || i[2] || i[3] || i[4] || i[5] || i[6], !o) continue;
        if (s = [...o].length, i[3] || i[4]) {
          l += s;
          continue;
        } else if ((i[5] || i[6]) && a % 3 && !((a + s) % 3)) {
          c += s;
          continue;
        }
        if (l -= s, l > 0) continue;
        s = Math.min(s, s + l + c);
        const u = [...i[0]][0].length, f = e.slice(0, a + i.index + u + s);
        if (Math.min(a, s) % 2) {
          const g = f.slice(1, -1);
          return {
            type: "em",
            raw: f,
            text: g,
            tokens: this.lexer.inlineTokens(g)
          };
        }
        const d = f.slice(2, -2);
        return {
          type: "strong",
          raw: f,
          text: d,
          tokens: this.lexer.inlineTokens(d)
        };
      }
    }
  }
  codespan(e) {
    const t = this.rules.inline.code.exec(e);
    if (t) {
      let r = t[2].replace(this.rules.other.newLineCharGlobal, " ");
      const i = this.rules.other.nonSpaceChar.test(r), n = this.rules.other.startingSpaceChar.test(r) && this.rules.other.endingSpaceChar.test(r);
      return i && n && (r = r.substring(1, r.length - 1)), {
        type: "codespan",
        raw: t[0],
        text: r
      };
    }
  }
  br(e) {
    const t = this.rules.inline.br.exec(e);
    if (t)
      return {
        type: "br",
        raw: t[0]
      };
  }
  del(e) {
    const t = this.rules.inline.del.exec(e);
    if (t)
      return {
        type: "del",
        raw: t[0],
        text: t[2],
        tokens: this.lexer.inlineTokens(t[2])
      };
  }
  autolink(e) {
    const t = this.rules.inline.autolink.exec(e);
    if (t) {
      let r, i;
      return t[2] === "@" ? (r = t[1], i = "mailto:" + r) : (r = t[1], i = r), {
        type: "link",
        raw: t[0],
        text: r,
        href: i,
        tokens: [
          {
            type: "text",
            raw: r,
            text: r
          }
        ]
      };
    }
  }
  url(e) {
    var r;
    let t;
    if (t = this.rules.inline.url.exec(e)) {
      let i, n;
      if (t[2] === "@")
        i = t[0], n = "mailto:" + i;
      else {
        let a;
        do
          a = t[0], t[0] = ((r = this.rules.inline._backpedal.exec(t[0])) == null ? void 0 : r[0]) ?? "";
        while (a !== t[0]);
        i = t[0], t[1] === "www." ? n = "http://" + t[0] : n = t[0];
      }
      return {
        type: "link",
        raw: t[0],
        text: i,
        href: n,
        tokens: [
          {
            type: "text",
            raw: i,
            text: i
          }
        ]
      };
    }
  }
  inlineText(e) {
    const t = this.rules.inline.text.exec(e);
    if (t) {
      const r = this.lexer.state.inRawBlock;
      return {
        type: "text",
        raw: t[0],
        text: t[0],
        escaped: r
      };
    }
  }
}, he = class Va {
  constructor(t) {
    ot(this, "tokens");
    ot(this, "options");
    ot(this, "state");
    ot(this, "tokenizer");
    ot(this, "inlineQueue");
    this.tokens = [], this.tokens.links = /* @__PURE__ */ Object.create(null), this.options = t || Qe, this.options.tokenizer = this.options.tokenizer || new xn(), this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = {
      inLink: !1,
      inRawBlock: !1,
      top: !0
    };
    const r = {
      other: Dt,
      block: Si.normal,
      inline: Er.normal
    };
    this.options.pedantic ? (r.block = Si.pedantic, r.inline = Er.pedantic) : this.options.gfm && (r.block = Si.gfm, this.options.breaks ? r.inline = Er.breaks : r.inline = Er.gfm), this.tokenizer.rules = r;
  }
  /**
   * Expose Rules
   */
  static get rules() {
    return {
      block: Si,
      inline: Er
    };
  }
  /**
   * Static Lex Method
   */
  static lex(t, r) {
    return new Va(r).lex(t);
  }
  /**
   * Static Lex Inline Method
   */
  static lexInline(t, r) {
    return new Va(r).inlineTokens(t);
  }
  /**
   * Preprocessing
   */
  lex(t) {
    t = t.replace(Dt.carriageReturn, `
`), this.blockTokens(t, this.tokens);
    for (let r = 0; r < this.inlineQueue.length; r++) {
      const i = this.inlineQueue[r];
      this.inlineTokens(i.src, i.tokens);
    }
    return this.inlineQueue = [], this.tokens;
  }
  blockTokens(t, r = [], i = !1) {
    var n, a, o;
    for (this.options.pedantic && (t = t.replace(Dt.tabCharGlobal, "    ").replace(Dt.spaceLine, "")); t; ) {
      let s;
      if ((a = (n = this.options.extensions) == null ? void 0 : n.block) != null && a.some((c) => (s = c.call({ lexer: this }, t, r)) ? (t = t.substring(s.raw.length), r.push(s), !0) : !1))
        continue;
      if (s = this.tokenizer.space(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        s.raw.length === 1 && c !== void 0 ? c.raw += `
` : r.push(s);
        continue;
      }
      if (s = this.tokenizer.code(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (s = this.tokenizer.fences(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.heading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.hr(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.blockquote(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.list(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.html(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.def(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "paragraph" || (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.raw, this.inlineQueue.at(-1).src = c.text) : this.tokens.links[s.tag] || (this.tokens.links[s.tag] = {
          href: s.href,
          title: s.title
        });
        continue;
      }
      if (s = this.tokenizer.table(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      if (s = this.tokenizer.lheading(t)) {
        t = t.substring(s.raw.length), r.push(s);
        continue;
      }
      let l = t;
      if ((o = this.options.extensions) != null && o.startBlock) {
        let c = 1 / 0;
        const h = t.slice(1);
        let u;
        this.options.extensions.startBlock.forEach((f) => {
          u = f.call({ lexer: this }, h), typeof u == "number" && u >= 0 && (c = Math.min(c, u));
        }), c < 1 / 0 && c >= 0 && (l = t.substring(0, c + 1));
      }
      if (this.state.top && (s = this.tokenizer.paragraph(l))) {
        const c = r.at(-1);
        i && (c == null ? void 0 : c.type) === "paragraph" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s), i = l.length !== t.length, t = t.substring(s.raw.length);
        continue;
      }
      if (s = this.tokenizer.text(t)) {
        t = t.substring(s.raw.length);
        const c = r.at(-1);
        (c == null ? void 0 : c.type) === "text" ? (c.raw += `
` + s.raw, c.text += `
` + s.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = c.text) : r.push(s);
        continue;
      }
      if (t) {
        const c = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(c);
          break;
        } else
          throw new Error(c);
      }
    }
    return this.state.top = !0, r;
  }
  inline(t, r = []) {
    return this.inlineQueue.push({ src: t, tokens: r }), r;
  }
  /**
   * Lexing/Compiling
   */
  inlineTokens(t, r = []) {
    var s, l, c;
    let i = t, n = null;
    if (this.tokens.links) {
      const h = Object.keys(this.tokens.links);
      if (h.length > 0)
        for (; (n = this.tokenizer.rules.inline.reflinkSearch.exec(i)) != null; )
          h.includes(n[0].slice(n[0].lastIndexOf("[") + 1, -1)) && (i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    }
    for (; (n = this.tokenizer.rules.inline.anyPunctuation.exec(i)) != null; )
      i = i.slice(0, n.index) + "++" + i.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex);
    for (; (n = this.tokenizer.rules.inline.blockSkip.exec(i)) != null; )
      i = i.slice(0, n.index) + "[" + "a".repeat(n[0].length - 2) + "]" + i.slice(this.tokenizer.rules.inline.blockSkip.lastIndex);
    let a = !1, o = "";
    for (; t; ) {
      a || (o = ""), a = !1;
      let h;
      if ((l = (s = this.options.extensions) == null ? void 0 : s.inline) != null && l.some((f) => (h = f.call({ lexer: this }, t, r)) ? (t = t.substring(h.raw.length), r.push(h), !0) : !1))
        continue;
      if (h = this.tokenizer.escape(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.tag(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.link(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.reflink(t, this.tokens.links)) {
        t = t.substring(h.raw.length);
        const f = r.at(-1);
        h.type === "text" && (f == null ? void 0 : f.type) === "text" ? (f.raw += h.raw, f.text += h.text) : r.push(h);
        continue;
      }
      if (h = this.tokenizer.emStrong(t, i, o)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.codespan(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.br(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.del(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (h = this.tokenizer.autolink(t)) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      if (!this.state.inLink && (h = this.tokenizer.url(t))) {
        t = t.substring(h.raw.length), r.push(h);
        continue;
      }
      let u = t;
      if ((c = this.options.extensions) != null && c.startInline) {
        let f = 1 / 0;
        const d = t.slice(1);
        let g;
        this.options.extensions.startInline.forEach((m) => {
          g = m.call({ lexer: this }, d), typeof g == "number" && g >= 0 && (f = Math.min(f, g));
        }), f < 1 / 0 && f >= 0 && (u = t.substring(0, f + 1));
      }
      if (h = this.tokenizer.inlineText(u)) {
        t = t.substring(h.raw.length), h.raw.slice(-1) !== "_" && (o = h.raw.slice(-1)), a = !0;
        const f = r.at(-1);
        (f == null ? void 0 : f.type) === "text" ? (f.raw += h.raw, f.text += h.text) : r.push(h);
        continue;
      }
      if (t) {
        const f = "Infinite loop on byte: " + t.charCodeAt(0);
        if (this.options.silent) {
          console.error(f);
          break;
        } else
          throw new Error(f);
      }
    }
    return r;
  }
}, bn = class {
  // set by the parser
  constructor(e) {
    ot(this, "options");
    ot(this, "parser");
    this.options = e || Qe;
  }
  space(e) {
    return "";
  }
  code({ text: e, lang: t, escaped: r }) {
    var a;
    const i = (a = (t || "").match(Dt.notSpaceStart)) == null ? void 0 : a[0], n = e.replace(Dt.endingNewline, "") + `
`;
    return i ? '<pre><code class="language-' + Qt(i) + '">' + (r ? n : Qt(n, !0)) + `</code></pre>
` : "<pre><code>" + (r ? n : Qt(n, !0)) + `</code></pre>
`;
  }
  blockquote({ tokens: e }) {
    return `<blockquote>
${this.parser.parse(e)}</blockquote>
`;
  }
  html({ text: e }) {
    return e;
  }
  heading({ tokens: e, depth: t }) {
    return `<h${t}>${this.parser.parseInline(e)}</h${t}>
`;
  }
  hr(e) {
    return `<hr>
`;
  }
  list(e) {
    const t = e.ordered, r = e.start;
    let i = "";
    for (let o = 0; o < e.items.length; o++) {
      const s = e.items[o];
      i += this.listitem(s);
    }
    const n = t ? "ol" : "ul", a = t && r !== 1 ? ' start="' + r + '"' : "";
    return "<" + n + a + `>
` + i + "</" + n + `>
`;
  }
  listitem(e) {
    var r;
    let t = "";
    if (e.task) {
      const i = this.checkbox({ checked: !!e.checked });
      e.loose ? ((r = e.tokens[0]) == null ? void 0 : r.type) === "paragraph" ? (e.tokens[0].text = i + " " + e.tokens[0].text, e.tokens[0].tokens && e.tokens[0].tokens.length > 0 && e.tokens[0].tokens[0].type === "text" && (e.tokens[0].tokens[0].text = i + " " + Qt(e.tokens[0].tokens[0].text), e.tokens[0].tokens[0].escaped = !0)) : e.tokens.unshift({
        type: "text",
        raw: i + " ",
        text: i + " ",
        escaped: !0
      }) : t += i + " ";
    }
    return t += this.parser.parse(e.tokens, !!e.loose), `<li>${t}</li>
`;
  }
  checkbox({ checked: e }) {
    return "<input " + (e ? 'checked="" ' : "") + 'disabled="" type="checkbox">';
  }
  paragraph({ tokens: e }) {
    return `<p>${this.parser.parseInline(e)}</p>
`;
  }
  table(e) {
    let t = "", r = "";
    for (let n = 0; n < e.header.length; n++)
      r += this.tablecell(e.header[n]);
    t += this.tablerow({ text: r });
    let i = "";
    for (let n = 0; n < e.rows.length; n++) {
      const a = e.rows[n];
      r = "";
      for (let o = 0; o < a.length; o++)
        r += this.tablecell(a[o]);
      i += this.tablerow({ text: r });
    }
    return i && (i = `<tbody>${i}</tbody>`), `<table>
<thead>
` + t + `</thead>
` + i + `</table>
`;
  }
  tablerow({ text: e }) {
    return `<tr>
${e}</tr>
`;
  }
  tablecell(e) {
    const t = this.parser.parseInline(e.tokens), r = e.header ? "th" : "td";
    return (e.align ? `<${r} align="${e.align}">` : `<${r}>`) + t + `</${r}>
`;
  }
  /**
   * span level renderer
   */
  strong({ tokens: e }) {
    return `<strong>${this.parser.parseInline(e)}</strong>`;
  }
  em({ tokens: e }) {
    return `<em>${this.parser.parseInline(e)}</em>`;
  }
  codespan({ text: e }) {
    return `<code>${Qt(e, !0)}</code>`;
  }
  br(e) {
    return "<br>";
  }
  del({ tokens: e }) {
    return `<del>${this.parser.parseInline(e)}</del>`;
  }
  link({ href: e, title: t, tokens: r }) {
    const i = this.parser.parseInline(r), n = dl(e);
    if (n === null)
      return i;
    e = n;
    let a = '<a href="' + e + '"';
    return t && (a += ' title="' + Qt(t) + '"'), a += ">" + i + "</a>", a;
  }
  image({ href: e, title: t, text: r, tokens: i }) {
    i && (r = this.parser.parseInline(i, this.parser.textRenderer));
    const n = dl(e);
    if (n === null)
      return Qt(r);
    e = n;
    let a = `<img src="${e}" alt="${r}"`;
    return t && (a += ` title="${Qt(t)}"`), a += ">", a;
  }
  text(e) {
    return "tokens" in e && e.tokens ? this.parser.parseInline(e.tokens) : "escaped" in e && e.escaped ? e.text : Qt(e.text);
  }
}, ao = class {
  // no need for block level renderers
  strong({ text: e }) {
    return e;
  }
  em({ text: e }) {
    return e;
  }
  codespan({ text: e }) {
    return e;
  }
  del({ text: e }) {
    return e;
  }
  html({ text: e }) {
    return e;
  }
  text({ text: e }) {
    return e;
  }
  link({ text: e }) {
    return "" + e;
  }
  image({ text: e }) {
    return "" + e;
  }
  br() {
    return "";
  }
}, ue = class Za {
  constructor(t) {
    ot(this, "options");
    ot(this, "renderer");
    ot(this, "textRenderer");
    this.options = t || Qe, this.options.renderer = this.options.renderer || new bn(), this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new ao();
  }
  /**
   * Static Parse Method
   */
  static parse(t, r) {
    return new Za(r).parse(t);
  }
  /**
   * Static Parse Inline Method
   */
  static parseInline(t, r) {
    return new Za(r).parseInline(t);
  }
  /**
   * Parse Loop
   */
  parse(t, r = !0) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        const c = s, h = this.options.extensions.renderers[c.type].call({ parser: this }, c);
        if (h !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "paragraph", "text"].includes(c.type)) {
          i += h || "";
          continue;
        }
      }
      const l = s;
      switch (l.type) {
        case "space": {
          i += this.renderer.space(l);
          continue;
        }
        case "hr": {
          i += this.renderer.hr(l);
          continue;
        }
        case "heading": {
          i += this.renderer.heading(l);
          continue;
        }
        case "code": {
          i += this.renderer.code(l);
          continue;
        }
        case "table": {
          i += this.renderer.table(l);
          continue;
        }
        case "blockquote": {
          i += this.renderer.blockquote(l);
          continue;
        }
        case "list": {
          i += this.renderer.list(l);
          continue;
        }
        case "html": {
          i += this.renderer.html(l);
          continue;
        }
        case "paragraph": {
          i += this.renderer.paragraph(l);
          continue;
        }
        case "text": {
          let c = l, h = this.renderer.text(c);
          for (; o + 1 < t.length && t[o + 1].type === "text"; )
            c = t[++o], h += `
` + this.renderer.text(c);
          r ? i += this.renderer.paragraph({
            type: "paragraph",
            raw: h,
            text: h,
            tokens: [{ type: "text", raw: h, text: h, escaped: !0 }]
          }) : i += h;
          continue;
        }
        default: {
          const c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
  /**
   * Parse Inline Tokens
   */
  parseInline(t, r = this.renderer) {
    var n, a;
    let i = "";
    for (let o = 0; o < t.length; o++) {
      const s = t[o];
      if ((a = (n = this.options.extensions) == null ? void 0 : n.renderers) != null && a[s.type]) {
        const c = this.options.extensions.renderers[s.type].call({ parser: this }, s);
        if (c !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(s.type)) {
          i += c || "";
          continue;
        }
      }
      const l = s;
      switch (l.type) {
        case "escape": {
          i += r.text(l);
          break;
        }
        case "html": {
          i += r.html(l);
          break;
        }
        case "link": {
          i += r.link(l);
          break;
        }
        case "image": {
          i += r.image(l);
          break;
        }
        case "strong": {
          i += r.strong(l);
          break;
        }
        case "em": {
          i += r.em(l);
          break;
        }
        case "codespan": {
          i += r.codespan(l);
          break;
        }
        case "br": {
          i += r.br(l);
          break;
        }
        case "del": {
          i += r.del(l);
          break;
        }
        case "text": {
          i += r.text(l);
          break;
        }
        default: {
          const c = 'Token with "' + l.type + '" type was not found.';
          if (this.options.silent)
            return console.error(c), "";
          throw new Error(c);
        }
      }
    }
    return i;
  }
}, ma, Pi = (ma = class {
  constructor(e) {
    ot(this, "options");
    ot(this, "block");
    this.options = e || Qe;
  }
  /**
   * Process markdown before marked
   */
  preprocess(e) {
    return e;
  }
  /**
   * Process HTML after marked is finished
   */
  postprocess(e) {
    return e;
  }
  /**
   * Process all tokens before walk tokens
   */
  processAllTokens(e) {
    return e;
  }
  /**
   * Provide function to tokenize markdown
   */
  provideLexer() {
    return this.block ? he.lex : he.lexInline;
  }
  /**
   * Provide function to parse tokens
   */
  provideParser() {
    return this.block ? ue.parse : ue.parseInline;
  }
}, ot(ma, "passThroughHooks", /* @__PURE__ */ new Set([
  "preprocess",
  "postprocess",
  "processAllTokens"
])), ma), Xw = class {
  constructor(...e) {
    ot(this, "defaults", Ks());
    ot(this, "options", this.setOptions);
    ot(this, "parse", this.parseMarkdown(!0));
    ot(this, "parseInline", this.parseMarkdown(!1));
    ot(this, "Parser", ue);
    ot(this, "Renderer", bn);
    ot(this, "TextRenderer", ao);
    ot(this, "Lexer", he);
    ot(this, "Tokenizer", xn);
    ot(this, "Hooks", Pi);
    this.use(...e);
  }
  /**
   * Run callback for every token
   */
  walkTokens(e, t) {
    var i, n;
    let r = [];
    for (const a of e)
      switch (r = r.concat(t.call(this, a)), a.type) {
        case "table": {
          const o = a;
          for (const s of o.header)
            r = r.concat(this.walkTokens(s.tokens, t));
          for (const s of o.rows)
            for (const l of s)
              r = r.concat(this.walkTokens(l.tokens, t));
          break;
        }
        case "list": {
          const o = a;
          r = r.concat(this.walkTokens(o.items, t));
          break;
        }
        default: {
          const o = a;
          (n = (i = this.defaults.extensions) == null ? void 0 : i.childTokens) != null && n[o.type] ? this.defaults.extensions.childTokens[o.type].forEach((s) => {
            const l = o[s].flat(1 / 0);
            r = r.concat(this.walkTokens(l, t));
          }) : o.tokens && (r = r.concat(this.walkTokens(o.tokens, t)));
        }
      }
    return r;
  }
  use(...e) {
    const t = this.defaults.extensions || { renderers: {}, childTokens: {} };
    return e.forEach((r) => {
      const i = { ...r };
      if (i.async = this.defaults.async || i.async || !1, r.extensions && (r.extensions.forEach((n) => {
        if (!n.name)
          throw new Error("extension name required");
        if ("renderer" in n) {
          const a = t.renderers[n.name];
          a ? t.renderers[n.name] = function(...o) {
            let s = n.renderer.apply(this, o);
            return s === !1 && (s = a.apply(this, o)), s;
          } : t.renderers[n.name] = n.renderer;
        }
        if ("tokenizer" in n) {
          if (!n.level || n.level !== "block" && n.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
          const a = t[n.level];
          a ? a.unshift(n.tokenizer) : t[n.level] = [n.tokenizer], n.start && (n.level === "block" ? t.startBlock ? t.startBlock.push(n.start) : t.startBlock = [n.start] : n.level === "inline" && (t.startInline ? t.startInline.push(n.start) : t.startInline = [n.start]));
        }
        "childTokens" in n && n.childTokens && (t.childTokens[n.name] = n.childTokens);
      }), i.extensions = t), r.renderer) {
        const n = this.defaults.renderer || new bn(this.defaults);
        for (const a in r.renderer) {
          if (!(a in n))
            throw new Error(`renderer '${a}' does not exist`);
          if (["options", "parser"].includes(a))
            continue;
          const o = a, s = r.renderer[o], l = n[o];
          n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h || "";
          };
        }
        i.renderer = n;
      }
      if (r.tokenizer) {
        const n = this.defaults.tokenizer || new xn(this.defaults);
        for (const a in r.tokenizer) {
          if (!(a in n))
            throw new Error(`tokenizer '${a}' does not exist`);
          if (["options", "rules", "lexer"].includes(a))
            continue;
          const o = a, s = r.tokenizer[o], l = n[o];
          n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h;
          };
        }
        i.tokenizer = n;
      }
      if (r.hooks) {
        const n = this.defaults.hooks || new Pi();
        for (const a in r.hooks) {
          if (!(a in n))
            throw new Error(`hook '${a}' does not exist`);
          if (["options", "block"].includes(a))
            continue;
          const o = a, s = r.hooks[o], l = n[o];
          Pi.passThroughHooks.has(a) ? n[o] = (c) => {
            if (this.defaults.async)
              return Promise.resolve(s.call(n, c)).then((u) => l.call(n, u));
            const h = s.call(n, c);
            return l.call(n, h);
          } : n[o] = (...c) => {
            let h = s.apply(n, c);
            return h === !1 && (h = l.apply(n, c)), h;
          };
        }
        i.hooks = n;
      }
      if (r.walkTokens) {
        const n = this.defaults.walkTokens, a = r.walkTokens;
        i.walkTokens = function(o) {
          let s = [];
          return s.push(a.call(this, o)), n && (s = s.concat(n.call(this, o))), s;
        };
      }
      this.defaults = { ...this.defaults, ...i };
    }), this;
  }
  setOptions(e) {
    return this.defaults = { ...this.defaults, ...e }, this;
  }
  lexer(e, t) {
    return he.lex(e, t ?? this.defaults);
  }
  parser(e, t) {
    return ue.parse(e, t ?? this.defaults);
  }
  parseMarkdown(e) {
    return (r, i) => {
      const n = { ...i }, a = { ...this.defaults, ...n }, o = this.onError(!!a.silent, !!a.async);
      if (this.defaults.async === !0 && n.async === !1)
        return o(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise."));
      if (typeof r > "u" || r === null)
        return o(new Error("marked(): input parameter is undefined or null"));
      if (typeof r != "string")
        return o(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(r) + ", string expected"));
      a.hooks && (a.hooks.options = a, a.hooks.block = e);
      const s = a.hooks ? a.hooks.provideLexer() : e ? he.lex : he.lexInline, l = a.hooks ? a.hooks.provideParser() : e ? ue.parse : ue.parseInline;
      if (a.async)
        return Promise.resolve(a.hooks ? a.hooks.preprocess(r) : r).then((c) => s(c, a)).then((c) => a.hooks ? a.hooks.processAllTokens(c) : c).then((c) => a.walkTokens ? Promise.all(this.walkTokens(c, a.walkTokens)).then(() => c) : c).then((c) => l(c, a)).then((c) => a.hooks ? a.hooks.postprocess(c) : c).catch(o);
      try {
        a.hooks && (r = a.hooks.preprocess(r));
        let c = s(r, a);
        a.hooks && (c = a.hooks.processAllTokens(c)), a.walkTokens && this.walkTokens(c, a.walkTokens);
        let h = l(c, a);
        return a.hooks && (h = a.hooks.postprocess(h)), h;
      } catch (c) {
        return o(c);
      }
    };
  }
  onError(e, t) {
    return (r) => {
      if (r.message += `
Please report this to https://github.com/markedjs/marked.`, e) {
        const i = "<p>An error occurred:</p><pre>" + Qt(r.message + "", !0) + "</pre>";
        return t ? Promise.resolve(i) : i;
      }
      if (t)
        return Promise.reject(r);
      throw r;
    };
  }
}, Ge = new Xw();
function at(e, t) {
  return Ge.parse(e, t);
}
at.options = at.setOptions = function(e) {
  return Ge.setOptions(e), at.defaults = Ge.defaults, lf(at.defaults), at;
};
at.getDefaults = Ks;
at.defaults = Qe;
at.use = function(...e) {
  return Ge.use(...e), at.defaults = Ge.defaults, lf(at.defaults), at;
};
at.walkTokens = function(e, t) {
  return Ge.walkTokens(e, t);
};
at.parseInline = Ge.parseInline;
at.Parser = ue;
at.parser = ue.parse;
at.Renderer = bn;
at.TextRenderer = ao;
at.Lexer = he;
at.lexer = he.lex;
at.Tokenizer = xn;
at.Hooks = Pi;
at.parse = at;
at.options;
at.setOptions;
at.use;
at.walkTokens;
at.parseInline;
ue.parse;
he.lex;
function bf(e) {
  for (var t = [], r = 1; r < arguments.length; r++)
    t[r - 1] = arguments[r];
  var i = Array.from(typeof e == "string" ? [e] : e);
  i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
  var n = i.reduce(function(s, l) {
    var c = l.match(/\n([\t ]+|(?!\s).)/g);
    return c ? s.concat(c.map(function(h) {
      var u, f;
      return (f = (u = h.match(/[\t ]/g)) === null || u === void 0 ? void 0 : u.length) !== null && f !== void 0 ? f : 0;
    })) : s;
  }, []);
  if (n.length) {
    var a = new RegExp(`
[	 ]{` + Math.min.apply(Math, n) + "}", "g");
    i = i.map(function(s) {
      return s.replace(a, `
`);
    });
  }
  i[0] = i[0].replace(/^\r?\n/, "");
  var o = i[0];
  return t.forEach(function(s, l) {
    var c = o.match(/(?:^|\n)( *)$/), h = c ? c[1] : "", u = s;
    typeof s == "string" && s.includes(`
`) && (u = String(s).split(`
`).map(function(f, d) {
      return d === 0 ? f : "" + h + f;
    }).join(`
`)), o += u + i[l + 1];
  }), o;
}
var Vw = {
  body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>',
  height: 80,
  width: 80
}, Ka = /* @__PURE__ */ new Map(), Cf = /* @__PURE__ */ new Map(), Zw = /* @__PURE__ */ p((e) => {
  for (const t of e) {
    if (!t.name)
      throw new Error(
        'Invalid icon loader. Must have a "name" property with non-empty string value.'
      );
    if (F.debug("Registering icon pack:", t.name), "loader" in t)
      Cf.set(t.name, t.loader);
    else if ("icons" in t)
      Ka.set(t.name, t.icons);
    else
      throw F.error("Invalid icon loader:", t), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
  }
}, "registerIconPacks"), wf = /* @__PURE__ */ p(async (e, t) => {
  const r = KC(e, !0, t !== void 0);
  if (!r)
    throw new Error(`Invalid icon name: ${e}`);
  const i = r.prefix || t;
  if (!i)
    throw new Error(`Icon name must contain a prefix: ${e}`);
  let n = Ka.get(i);
  if (!n) {
    const o = Cf.get(i);
    if (!o)
      throw new Error(`Icon set not found: ${r.prefix}`);
    try {
      n = { ...await o(), prefix: i }, Ka.set(i, n);
    } catch (s) {
      throw F.error(s), new Error(`Failed to load icon set: ${r.prefix}`);
    }
  }
  const a = tw(n, r.name);
  if (!a)
    throw new Error(`Icon not found: ${e}`);
  return a;
}, "getRegisteredIconData"), Kw = /* @__PURE__ */ p(async (e) => {
  try {
    return await wf(e), !0;
  } catch {
    return !1;
  }
}, "isIconAvailable"), bi = /* @__PURE__ */ p(async (e, t, r) => {
  let i;
  try {
    i = await wf(e, t == null ? void 0 : t.fallbackPrefix);
  } catch (o) {
    F.error(o), i = Vw;
  }
  const n = ow(i, t), a = fw(uw(n.body), {
    ...n.attributes,
    ...r
  });
  return jt(a, Bt());
}, "getIconSVG");
function _f(e, { markdownAutoWrap: t }) {
  const i = e.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`), n = bf(i);
  return t === !1 ? n.replace(/ /g, "&nbsp;") : n;
}
p(_f, "preprocessMarkdown");
function vf(e, t = {}) {
  const r = _f(e, t), i = at.lexer(r), n = [[]];
  let a = 0;
  function o(s, l = "normal") {
    s.type === "text" ? s.text.split(`
`).forEach((h, u) => {
      u !== 0 && (a++, n.push([])), h.split(" ").forEach((f) => {
        f = f.replace(/&#39;/g, "'"), f && n[a].push({ content: f, type: l });
      });
    }) : s.type === "strong" || s.type === "em" ? s.tokens.forEach((c) => {
      o(c, s.type);
    }) : s.type === "html" && n[a].push({ content: s.text, type: "normal" });
  }
  return p(o, "processNode"), i.forEach((s) => {
    var l;
    s.type === "paragraph" ? (l = s.tokens) == null || l.forEach((c) => {
      o(c);
    }) : s.type === "html" ? n[a].push({ content: s.text, type: "normal" }) : n[a].push({ content: s.raw, type: "normal" });
  }), n;
}
p(vf, "markdownToLines");
function kf(e, { markdownAutoWrap: t } = {}) {
  const r = at.lexer(e);
  function i(n) {
    var a, o, s;
    return n.type === "text" ? t === !1 ? n.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : n.text.replace(/\n */g, "<br/>") : n.type === "strong" ? `<strong>${(a = n.tokens) == null ? void 0 : a.map(i).join("")}</strong>` : n.type === "em" ? `<em>${(o = n.tokens) == null ? void 0 : o.map(i).join("")}</em>` : n.type === "paragraph" ? `<p>${(s = n.tokens) == null ? void 0 : s.map(i).join("")}</p>` : n.type === "space" ? "" : n.type === "html" ? `${n.text}` : n.type === "escape" ? n.text : (F.warn(`Unsupported markdown: ${n.type}`), n.raw);
  }
  return p(i, "output"), r.map(i).join("");
}
p(kf, "markdownToHTML");
function Sf(e) {
  return Intl.Segmenter ? [...new Intl.Segmenter().segment(e)].map((t) => t.segment) : [...e];
}
p(Sf, "splitTextToChars");
function Tf(e, t) {
  const r = Sf(t.content);
  return so(e, [], r, t.type);
}
p(Tf, "splitWordToFitWidth");
function so(e, t, r, i) {
  if (r.length === 0)
    return [
      { content: t.join(""), type: i },
      { content: "", type: i }
    ];
  const [n, ...a] = r, o = [...t, n];
  return e([{ content: o.join(""), type: i }]) ? so(e, o, a, i) : (t.length === 0 && n && (t.push(n), r.shift()), [
    { content: t.join(""), type: i },
    { content: r.join(""), type: i }
  ]);
}
p(so, "splitWordToFitWidthRecursion");
function Bf(e, t) {
  if (e.some(({ content: r }) => r.includes(`
`)))
    throw new Error("splitLineToFitWidth does not support newlines in the line");
  return Cn(e, t);
}
p(Bf, "splitLineToFitWidth");
function Cn(e, t, r = [], i = []) {
  if (e.length === 0)
    return i.length > 0 && r.push(i), r.length > 0 ? r : [];
  let n = "";
  e[0].content === " " && (n = " ", e.shift());
  const a = e.shift() ?? { content: " ", type: "normal" }, o = [...i];
  if (n !== "" && o.push({ content: n, type: "normal" }), o.push(a), t(o))
    return Cn(e, t, r, o);
  if (i.length > 0)
    r.push(i), e.unshift(a);
  else if (a.content) {
    const [s, l] = Tf(t, a);
    r.push([s]), l.content && e.unshift(l);
  }
  return Cn(e, t, r);
}
p(Cn, "splitLineToFitWidthRecursion");
function Qa(e, t) {
  t && e.attr("style", t);
}
p(Qa, "applyStyle");
async function Lf(e, t, r, i, n = !1, a = Bt()) {
  const o = e.append("foreignObject");
  o.attr("width", `${10 * r}px`), o.attr("height", `${10 * r}px`);
  const s = o.append("xhtml:div"), l = yr(t.label) ? await ps(t.label.replace(kr.lineBreakRegex, `
`), a) : jt(t.label, a), c = t.isNode ? "nodeLabel" : "edgeLabel", h = s.append("span");
  h.html(l), Qa(h, t.labelStyle), h.attr("class", `${c} ${i}`), Qa(s, t.labelStyle), s.style("display", "table-cell"), s.style("white-space", "nowrap"), s.style("line-height", "1.5"), s.style("max-width", r + "px"), s.style("text-align", "center"), s.attr("xmlns", "http://www.w3.org/1999/xhtml"), n && s.attr("class", "labelBkg");
  let u = s.node().getBoundingClientRect();
  return u.width === r && (s.style("display", "table"), s.style("white-space", "break-spaces"), s.style("width", r + "px"), u = s.node().getBoundingClientRect()), o.node();
}
p(Lf, "addHtmlSpan");
function Gn(e, t, r) {
  return e.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", t * r - 0.1 + "em").attr("dy", r + "em");
}
p(Gn, "createTspan");
function Mf(e, t, r) {
  const i = e.append("text"), n = Gn(i, 1, t);
  Un(n, r);
  const a = n.node().getComputedTextLength();
  return i.remove(), a;
}
p(Mf, "computeWidthOfText");
function Qw(e, t, r) {
  var o;
  const i = e.append("text"), n = Gn(i, 1, t);
  Un(n, [{ content: r, type: "normal" }]);
  const a = (o = n.node()) == null ? void 0 : o.getBoundingClientRect();
  return a && i.remove(), a;
}
p(Qw, "computeDimensionOfText");
function $f(e, t, r, i = !1) {
  const a = t.append("g"), o = a.insert("rect").attr("class", "background").attr("style", "stroke: none"), s = a.append("text").attr("y", "-10.1");
  let l = 0;
  for (const c of r) {
    const h = /* @__PURE__ */ p((f) => Mf(a, 1.1, f) <= e, "checkWidth"), u = h(c) ? [c] : Bf(c, h);
    for (const f of u) {
      const d = Gn(s, l, 1.1);
      Un(d, f), l++;
    }
  }
  if (i) {
    const c = s.node().getBBox(), h = 2;
    return o.attr("x", c.x - h).attr("y", c.y - h).attr("width", c.width + 2 * h).attr("height", c.height + 2 * h), a.node();
  } else
    return s.node();
}
p($f, "createFormattedText");
function Un(e, t) {
  e.text(""), t.forEach((r, i) => {
    const n = e.append("tspan").attr("font-style", r.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", r.type === "strong" ? "bold" : "normal");
    i === 0 ? n.text(r.content) : n.text(" " + r.content);
  });
}
p(Un, "updateTextContentAndStyles");
async function Af(e, t = {}) {
  const r = [];
  e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (n, a, o) => (r.push(
    (async () => {
      const s = `${a}:${o}`;
      return await Kw(s) ? await bi(s, void 0, { class: "label-icon" }) : `<i class='${jt(n, t).replace(":", " ")}'></i>`;
    })()
  ), n));
  const i = await Promise.all(r);
  return e.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => i.shift() ?? "");
}
p(Af, "replaceIconSubstring");
var Be = /* @__PURE__ */ p(async (e, t = "", {
  style: r = "",
  isTitle: i = !1,
  classes: n = "",
  useHtmlLabels: a = !0,
  isNode: o = !0,
  width: s = 200,
  addSvgBackground: l = !1
} = {}, c) => {
  if (F.debug(
    "XYZ createText",
    t,
    r,
    i,
    n,
    a,
    o,
    "addSvgBackground: ",
    l
  ), a) {
    const h = kf(t, c), u = await Af(Ke(h), c), f = t.replace(/\\\\/g, "\\"), d = {
      isNode: o,
      label: yr(t) ? f : u,
      labelStyle: r.replace("fill:", "color:")
    };
    return await Lf(e, d, s, n, l, c);
  } else {
    const h = t.replace(/<br\s*\/?>/g, "<br/>"), u = vf(h.replace("<br>", "<br/>"), c), f = $f(
      s,
      e,
      u,
      t ? l : !1
    );
    if (o) {
      /stroke:/.exec(r) && (r = r.replace("stroke:", "lineColor:"));
      const d = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      rt(f).attr("style", d);
    } else {
      const d = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
      rt(f).select("rect").attr("style", d.replace(/background:/g, "fill:"));
      const g = r.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
      rt(f).select("text").attr("style", g);
    }
    return f;
  }
}, "createText");
function la(e, t, r) {
  if (e && e.length) {
    const [i, n] = t, a = Math.PI / 180 * r, o = Math.cos(a), s = Math.sin(a);
    for (const l of e) {
      const [c, h] = l;
      l[0] = (c - i) * o - (h - n) * s + i, l[1] = (c - i) * s + (h - n) * o + n;
    }
  }
}
function Jw(e, t) {
  return e[0] === t[0] && e[1] === t[1];
}
function t_(e, t, r, i = 1) {
  const n = r, a = Math.max(t, 0.1), o = e[0] && e[0][0] && typeof e[0][0] == "number" ? [e] : e, s = [0, 0];
  if (n) for (const c of o) la(c, s, n);
  const l = function(c, h, u) {
    const f = [];
    for (const b of c) {
      const w = [...b];
      Jw(w[0], w[w.length - 1]) || w.push([w[0][0], w[0][1]]), w.length > 2 && f.push(w);
    }
    const d = [];
    h = Math.max(h, 0.1);
    const g = [];
    for (const b of f) for (let w = 0; w < b.length - 1; w++) {
      const k = b[w], _ = b[w + 1];
      if (k[1] !== _[1]) {
        const C = Math.min(k[1], _[1]);
        g.push({ ymin: C, ymax: Math.max(k[1], _[1]), x: C === k[1] ? k[0] : _[0], islope: (_[0] - k[0]) / (_[1] - k[1]) });
      }
    }
    if (g.sort((b, w) => b.ymin < w.ymin ? -1 : b.ymin > w.ymin ? 1 : b.x < w.x ? -1 : b.x > w.x ? 1 : b.ymax === w.ymax ? 0 : (b.ymax - w.ymax) / Math.abs(b.ymax - w.ymax)), !g.length) return d;
    let m = [], x = g[0].ymin, y = 0;
    for (; m.length || g.length; ) {
      if (g.length) {
        let b = -1;
        for (let w = 0; w < g.length && !(g[w].ymin > x); w++) b = w;
        g.splice(0, b + 1).forEach((w) => {
          m.push({ s: x, edge: w });
        });
      }
      if (m = m.filter((b) => !(b.edge.ymax <= x)), m.sort((b, w) => b.edge.x === w.edge.x ? 0 : (b.edge.x - w.edge.x) / Math.abs(b.edge.x - w.edge.x)), (u !== 1 || y % h == 0) && m.length > 1) for (let b = 0; b < m.length; b += 2) {
        const w = b + 1;
        if (w >= m.length) break;
        const k = m[b].edge, _ = m[w].edge;
        d.push([[Math.round(k.x), x], [Math.round(_.x), x]]);
      }
      x += u, m.forEach((b) => {
        b.edge.x = b.edge.x + u * b.edge.islope;
      }), y++;
    }
    return d;
  }(o, a, i);
  if (n) {
    for (const c of o) la(c, s, -n);
    (function(c, h, u) {
      const f = [];
      c.forEach((d) => f.push(...d)), la(f, h, u);
    })(l, s, -n);
  }
  return l;
}
function Ci(e, t) {
  var r;
  const i = t.hachureAngle + 90;
  let n = t.hachureGap;
  n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, 0.1));
  let a = 1;
  return t.roughness >= 1 && (((r = t.randomizer) === null || r === void 0 ? void 0 : r.next()) || Math.random()) > 0.7 && (a = n), t_(e, n, i, a || 1);
}
class oo {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    return this._fillPolygons(t, r);
  }
  _fillPolygons(t, r) {
    const i = Ci(t, r);
    return { type: "fillSketch", ops: this.renderLines(i, r) };
  }
  renderLines(t, r) {
    const i = [];
    for (const n of t) i.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], r));
    return i;
  }
}
function Xn(e) {
  const t = e[0], r = e[1];
  return Math.sqrt(Math.pow(t[0] - r[0], 2) + Math.pow(t[1] - r[1], 2));
}
class e_ extends oo {
  fillPolygons(t, r) {
    let i = r.hachureGap;
    i < 0 && (i = 4 * r.strokeWidth), i = Math.max(i, 0.1);
    const n = Ci(t, Object.assign({}, r, { hachureGap: i })), a = Math.PI / 180 * r.hachureAngle, o = [], s = 0.5 * i * Math.cos(a), l = 0.5 * i * Math.sin(a);
    for (const [c, h] of n) Xn([c, h]) && o.push([[c[0] - s, c[1] + l], [...h]], [[c[0] + s, c[1] - l], [...h]]);
    return { type: "fillSketch", ops: this.renderLines(o, r) };
  }
}
class r_ extends oo {
  fillPolygons(t, r) {
    const i = this._fillPolygons(t, r), n = Object.assign({}, r, { hachureAngle: r.hachureAngle + 90 }), a = this._fillPolygons(t, n);
    return i.ops = i.ops.concat(a.ops), i;
  }
}
class i_ {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = Ci(t, r = Object.assign({}, r, { hachureAngle: 0 }));
    return this.dotsOnLines(i, r);
  }
  dotsOnLines(t, r) {
    const i = [];
    let n = r.hachureGap;
    n < 0 && (n = 4 * r.strokeWidth), n = Math.max(n, 0.1);
    let a = r.fillWeight;
    a < 0 && (a = r.strokeWidth / 2);
    const o = n / 4;
    for (const s of t) {
      const l = Xn(s), c = l / n, h = Math.ceil(c) - 1, u = l - h * n, f = (s[0][0] + s[1][0]) / 2 - n / 4, d = Math.min(s[0][1], s[1][1]);
      for (let g = 0; g < h; g++) {
        const m = d + u + g * n, x = f - o + 2 * Math.random() * o, y = m - o + 2 * Math.random() * o, b = this.helper.ellipse(x, y, a, a, r);
        i.push(...b.ops);
      }
    }
    return { type: "fillSketch", ops: i };
  }
}
class n_ {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = Ci(t, r);
    return { type: "fillSketch", ops: this.dashedLine(i, r) };
  }
  dashedLine(t, r) {
    const i = r.dashOffset < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashOffset, n = r.dashGap < 0 ? r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap : r.dashGap, a = [];
    return t.forEach((o) => {
      const s = Xn(o), l = Math.floor(s / (i + n)), c = (s + n - l * (i + n)) / 2;
      let h = o[0], u = o[1];
      h[0] > u[0] && (h = o[1], u = o[0]);
      const f = Math.atan((u[1] - h[1]) / (u[0] - h[0]));
      for (let d = 0; d < l; d++) {
        const g = d * (i + n), m = g + i, x = [h[0] + g * Math.cos(f) + c * Math.cos(f), h[1] + g * Math.sin(f) + c * Math.sin(f)], y = [h[0] + m * Math.cos(f) + c * Math.cos(f), h[1] + m * Math.sin(f) + c * Math.sin(f)];
        a.push(...this.helper.doubleLineOps(x[0], x[1], y[0], y[1], r));
      }
    }), a;
  }
}
class a_ {
  constructor(t) {
    this.helper = t;
  }
  fillPolygons(t, r) {
    const i = r.hachureGap < 0 ? 4 * r.strokeWidth : r.hachureGap, n = r.zigzagOffset < 0 ? i : r.zigzagOffset, a = Ci(t, r = Object.assign({}, r, { hachureGap: i + n }));
    return { type: "fillSketch", ops: this.zigzagLines(a, n, r) };
  }
  zigzagLines(t, r, i) {
    const n = [];
    return t.forEach((a) => {
      const o = Xn(a), s = Math.round(o / (2 * r));
      let l = a[0], c = a[1];
      l[0] > c[0] && (l = a[1], c = a[0]);
      const h = Math.atan((c[1] - l[1]) / (c[0] - l[0]));
      for (let u = 0; u < s; u++) {
        const f = 2 * u * r, d = 2 * (u + 1) * r, g = Math.sqrt(2 * Math.pow(r, 2)), m = [l[0] + f * Math.cos(h), l[1] + f * Math.sin(h)], x = [l[0] + d * Math.cos(h), l[1] + d * Math.sin(h)], y = [m[0] + g * Math.cos(h + Math.PI / 4), m[1] + g * Math.sin(h + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(m[0], m[1], y[0], y[1], i), ...this.helper.doubleLineOps(y[0], y[1], x[0], x[1], i));
      }
    }), n;
  }
}
const Ot = {};
class s_ {
  constructor(t) {
    this.seed = t;
  }
  next() {
    return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random();
  }
}
const o_ = 0, ca = 1, ml = 2, Ti = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function ha(e, t) {
  return e.type === t;
}
function lo(e) {
  const t = [], r = function(o) {
    const s = new Array();
    for (; o !== ""; ) if (o.match(/^([ \t\r\n,]+)/)) o = o.substr(RegExp.$1.length);
    else if (o.match(/^([aAcChHlLmMqQsStTvVzZ])/)) s[s.length] = { type: o_, text: RegExp.$1 }, o = o.substr(RegExp.$1.length);
    else {
      if (!o.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/)) return [];
      s[s.length] = { type: ca, text: `${parseFloat(RegExp.$1)}` }, o = o.substr(RegExp.$1.length);
    }
    return s[s.length] = { type: ml, text: "" }, s;
  }(e);
  let i = "BOD", n = 0, a = r[n];
  for (; !ha(a, ml); ) {
    let o = 0;
    const s = [];
    if (i === "BOD") {
      if (a.text !== "M" && a.text !== "m") return lo("M0,0" + e);
      n++, o = Ti[a.text], i = a.text;
    } else ha(a, ca) ? o = Ti[i] : (n++, o = Ti[a.text], i = a.text);
    if (!(n + o < r.length)) throw new Error("Path data ended short");
    for (let l = n; l < n + o; l++) {
      const c = r[l];
      if (!ha(c, ca)) throw new Error("Param not a number: " + i + "," + c.text);
      s[s.length] = +c.text;
    }
    if (typeof Ti[i] != "number") throw new Error("Bad segment: " + i);
    {
      const l = { key: i, data: s };
      t.push(l), n += o, a = r[n], i === "M" && (i = "L"), i === "m" && (i = "l");
    }
  }
  return t;
}
function Ff(e) {
  let t = 0, r = 0, i = 0, n = 0;
  const a = [];
  for (const { key: o, data: s } of e) switch (o) {
    case "M":
      a.push({ key: "M", data: [...s] }), [t, r] = s, [i, n] = s;
      break;
    case "m":
      t += s[0], r += s[1], a.push({ key: "M", data: [t, r] }), i = t, n = r;
      break;
    case "L":
      a.push({ key: "L", data: [...s] }), [t, r] = s;
      break;
    case "l":
      t += s[0], r += s[1], a.push({ key: "L", data: [t, r] });
      break;
    case "C":
      a.push({ key: "C", data: [...s] }), t = s[4], r = s[5];
      break;
    case "c": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "C", data: l }), t = l[4], r = l[5];
      break;
    }
    case "Q":
      a.push({ key: "Q", data: [...s] }), t = s[2], r = s[3];
      break;
    case "q": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "Q", data: l }), t = l[2], r = l[3];
      break;
    }
    case "A":
      a.push({ key: "A", data: [...s] }), t = s[5], r = s[6];
      break;
    case "a":
      t += s[5], r += s[6], a.push({ key: "A", data: [s[0], s[1], s[2], s[3], s[4], t, r] });
      break;
    case "H":
      a.push({ key: "H", data: [...s] }), t = s[0];
      break;
    case "h":
      t += s[0], a.push({ key: "H", data: [t] });
      break;
    case "V":
      a.push({ key: "V", data: [...s] }), r = s[0];
      break;
    case "v":
      r += s[0], a.push({ key: "V", data: [r] });
      break;
    case "S":
      a.push({ key: "S", data: [...s] }), t = s[2], r = s[3];
      break;
    case "s": {
      const l = s.map((c, h) => h % 2 ? c + r : c + t);
      a.push({ key: "S", data: l }), t = l[2], r = l[3];
      break;
    }
    case "T":
      a.push({ key: "T", data: [...s] }), t = s[0], r = s[1];
      break;
    case "t":
      t += s[0], r += s[1], a.push({ key: "T", data: [t, r] });
      break;
    case "Z":
    case "z":
      a.push({ key: "Z", data: [] }), t = i, r = n;
  }
  return a;
}
function Ef(e) {
  const t = [];
  let r = "", i = 0, n = 0, a = 0, o = 0, s = 0, l = 0;
  for (const { key: c, data: h } of e) {
    switch (c) {
      case "M":
        t.push({ key: "M", data: [...h] }), [i, n] = h, [a, o] = h;
        break;
      case "C":
        t.push({ key: "C", data: [...h] }), i = h[4], n = h[5], s = h[2], l = h[3];
        break;
      case "L":
        t.push({ key: "L", data: [...h] }), [i, n] = h;
        break;
      case "H":
        i = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "V":
        n = h[0], t.push({ key: "L", data: [i, n] });
        break;
      case "S": {
        let u = 0, f = 0;
        r === "C" || r === "S" ? (u = i + (i - s), f = n + (n - l)) : (u = i, f = n), t.push({ key: "C", data: [u, f, ...h] }), s = h[0], l = h[1], i = h[2], n = h[3];
        break;
      }
      case "T": {
        const [u, f] = h;
        let d = 0, g = 0;
        r === "Q" || r === "T" ? (d = i + (i - s), g = n + (n - l)) : (d = i, g = n);
        const m = i + 2 * (d - i) / 3, x = n + 2 * (g - n) / 3, y = u + 2 * (d - u) / 3, b = f + 2 * (g - f) / 3;
        t.push({ key: "C", data: [m, x, y, b, u, f] }), s = d, l = g, i = u, n = f;
        break;
      }
      case "Q": {
        const [u, f, d, g] = h, m = i + 2 * (u - i) / 3, x = n + 2 * (f - n) / 3, y = d + 2 * (u - d) / 3, b = g + 2 * (f - g) / 3;
        t.push({ key: "C", data: [m, x, y, b, d, g] }), s = u, l = f, i = d, n = g;
        break;
      }
      case "A": {
        const u = Math.abs(h[0]), f = Math.abs(h[1]), d = h[2], g = h[3], m = h[4], x = h[5], y = h[6];
        u === 0 || f === 0 ? (t.push({ key: "C", data: [i, n, x, y, x, y] }), i = x, n = y) : (i !== x || n !== y) && (Df(i, n, x, y, u, f, d, g, m).forEach(function(b) {
          t.push({ key: "C", data: b });
        }), i = x, n = y);
        break;
      }
      case "Z":
        t.push({ key: "Z", data: [] }), i = a, n = o;
    }
    r = c;
  }
  return t;
}
function Or(e, t, r) {
  return [e * Math.cos(r) - t * Math.sin(r), e * Math.sin(r) + t * Math.cos(r)];
}
function Df(e, t, r, i, n, a, o, s, l, c) {
  const h = (u = o, Math.PI * u / 180);
  var u;
  let f = [], d = 0, g = 0, m = 0, x = 0;
  if (c) [d, g, m, x] = c;
  else {
    [e, t] = Or(e, t, -h), [r, i] = Or(r, i, -h);
    const E = (e - r) / 2, B = (t - i) / 2;
    let L = E * E / (n * n) + B * B / (a * a);
    L > 1 && (L = Math.sqrt(L), n *= L, a *= L);
    const T = n * n, $ = a * a, M = T * $ - T * B * B - $ * E * E, z = T * B * B + $ * E * E, U = (s === l ? -1 : 1) * Math.sqrt(Math.abs(M / z));
    m = U * n * B / a + (e + r) / 2, x = U * -a * E / n + (t + i) / 2, d = Math.asin(parseFloat(((t - x) / a).toFixed(9))), g = Math.asin(parseFloat(((i - x) / a).toFixed(9))), e < m && (d = Math.PI - d), r < m && (g = Math.PI - g), d < 0 && (d = 2 * Math.PI + d), g < 0 && (g = 2 * Math.PI + g), l && d > g && (d -= 2 * Math.PI), !l && g > d && (g -= 2 * Math.PI);
  }
  let y = g - d;
  if (Math.abs(y) > 120 * Math.PI / 180) {
    const E = g, B = r, L = i;
    g = l && g > d ? d + 120 * Math.PI / 180 * 1 : d + 120 * Math.PI / 180 * -1, f = Df(r = m + n * Math.cos(g), i = x + a * Math.sin(g), B, L, n, a, o, 0, l, [g, E, m, x]);
  }
  y = g - d;
  const b = Math.cos(d), w = Math.sin(d), k = Math.cos(g), _ = Math.sin(g), C = Math.tan(y / 4), v = 4 / 3 * n * C, D = 4 / 3 * a * C, R = [e, t], O = [e + v * w, t - D * b], A = [r + v * _, i - D * k], I = [r, i];
  if (O[0] = 2 * R[0] - O[0], O[1] = 2 * R[1] - O[1], c) return [O, A, I].concat(f);
  {
    f = [O, A, I].concat(f);
    const E = [];
    for (let B = 0; B < f.length; B += 3) {
      const L = Or(f[B][0], f[B][1], h), T = Or(f[B + 1][0], f[B + 1][1], h), $ = Or(f[B + 2][0], f[B + 2][1], h);
      E.push([L[0], L[1], T[0], T[1], $[0], $[1]]);
    }
    return E;
  }
}
const l_ = { randOffset: function(e, t) {
  return K(e, t);
}, randOffsetWithRange: function(e, t, r) {
  return wn(e, t, r);
}, ellipse: function(e, t, r, i, n) {
  const a = Rf(r, i, n);
  return Ja(e, t, n, a).opset;
}, doubleLineOps: function(e, t, r, i, n) {
  return ke(e, t, r, i, n, !0);
} };
function Of(e, t, r, i, n) {
  return { type: "path", ops: ke(e, t, r, i, n) };
}
function Ni(e, t, r) {
  const i = (e || []).length;
  if (i > 2) {
    const n = [];
    for (let a = 0; a < i - 1; a++) n.push(...ke(e[a][0], e[a][1], e[a + 1][0], e[a + 1][1], r));
    return t && n.push(...ke(e[i - 1][0], e[i - 1][1], e[0][0], e[0][1], r)), { type: "path", ops: n };
  }
  return i === 2 ? Of(e[0][0], e[0][1], e[1][0], e[1][1], r) : { type: "path", ops: [] };
}
function c_(e, t, r, i, n) {
  return function(a, o) {
    return Ni(a, !0, o);
  }([[e, t], [e + r, t], [e + r, t + i], [e, t + i]], n);
}
function yl(e, t) {
  if (e.length) {
    const r = typeof e[0][0] == "number" ? [e] : e, i = Bi(r[0], 1 * (1 + 0.2 * t.roughness), t), n = t.disableMultiStroke ? [] : Bi(r[0], 1.5 * (1 + 0.22 * t.roughness), Cl(t));
    for (let a = 1; a < r.length; a++) {
      const o = r[a];
      if (o.length) {
        const s = Bi(o, 1 * (1 + 0.2 * t.roughness), t), l = t.disableMultiStroke ? [] : Bi(o, 1.5 * (1 + 0.22 * t.roughness), Cl(t));
        for (const c of s) c.op !== "move" && i.push(c);
        for (const c of l) c.op !== "move" && n.push(c);
      }
    }
    return { type: "path", ops: i.concat(n) };
  }
  return { type: "path", ops: [] };
}
function Rf(e, t, r) {
  const i = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(e / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(r.curveStepCount, r.curveStepCount / Math.sqrt(200) * i)), a = 2 * Math.PI / n;
  let o = Math.abs(e / 2), s = Math.abs(t / 2);
  const l = 1 - r.curveFitting;
  return o += K(o * l, r), s += K(s * l, r), { increment: a, rx: o, ry: s };
}
function Ja(e, t, r, i) {
  const [n, a] = wl(i.increment, e, t, i.rx, i.ry, 1, i.increment * wn(0.1, wn(0.4, 1, r), r), r);
  let o = _n(n, null, r);
  if (!r.disableMultiStroke && r.roughness !== 0) {
    const [s] = wl(i.increment, e, t, i.rx, i.ry, 1.5, 0, r), l = _n(s, null, r);
    o = o.concat(l);
  }
  return { estimatedPoints: a, opset: { type: "path", ops: o } };
}
function xl(e, t, r, i, n, a, o, s, l) {
  const c = e, h = t;
  let u = Math.abs(r / 2), f = Math.abs(i / 2);
  u += K(0.01 * u, l), f += K(0.01 * f, l);
  let d = n, g = a;
  for (; d < 0; ) d += 2 * Math.PI, g += 2 * Math.PI;
  g - d > 2 * Math.PI && (d = 0, g = 2 * Math.PI);
  const m = 2 * Math.PI / l.curveStepCount, x = Math.min(m / 2, (g - d) / 2), y = _l(x, c, h, u, f, d, g, 1, l);
  if (!l.disableMultiStroke) {
    const b = _l(x, c, h, u, f, d, g, 1.5, l);
    y.push(...b);
  }
  return o && (s ? y.push(...ke(c, h, c + u * Math.cos(d), h + f * Math.sin(d), l), ...ke(c, h, c + u * Math.cos(g), h + f * Math.sin(g), l)) : y.push({ op: "lineTo", data: [c, h] }, { op: "lineTo", data: [c + u * Math.cos(d), h + f * Math.sin(d)] })), { type: "path", ops: y };
}
function bl(e, t) {
  const r = Ef(Ff(lo(e))), i = [];
  let n = [0, 0], a = [0, 0];
  for (const { key: o, data: s } of r) switch (o) {
    case "M":
      a = [s[0], s[1]], n = [s[0], s[1]];
      break;
    case "L":
      i.push(...ke(a[0], a[1], s[0], s[1], t)), a = [s[0], s[1]];
      break;
    case "C": {
      const [l, c, h, u, f, d] = s;
      i.push(...h_(l, c, h, u, f, d, a, t)), a = [f, d];
      break;
    }
    case "Z":
      i.push(...ke(a[0], a[1], n[0], n[1], t)), a = [n[0], n[1]];
  }
  return { type: "path", ops: i };
}
function ua(e, t) {
  const r = [];
  for (const i of e) if (i.length) {
    const n = t.maxRandomnessOffset || 0, a = i.length;
    if (a > 2) {
      r.push({ op: "move", data: [i[0][0] + K(n, t), i[0][1] + K(n, t)] });
      for (let o = 1; o < a; o++) r.push({ op: "lineTo", data: [i[o][0] + K(n, t), i[o][1] + K(n, t)] });
    }
  }
  return { type: "fillPath", ops: r };
}
function tr(e, t) {
  return function(r, i) {
    let n = r.fillStyle || "hachure";
    if (!Ot[n]) switch (n) {
      case "zigzag":
        Ot[n] || (Ot[n] = new e_(i));
        break;
      case "cross-hatch":
        Ot[n] || (Ot[n] = new r_(i));
        break;
      case "dots":
        Ot[n] || (Ot[n] = new i_(i));
        break;
      case "dashed":
        Ot[n] || (Ot[n] = new n_(i));
        break;
      case "zigzag-line":
        Ot[n] || (Ot[n] = new a_(i));
        break;
      default:
        n = "hachure", Ot[n] || (Ot[n] = new oo(i));
    }
    return Ot[n];
  }(t, l_).fillPolygons(e, t);
}
function Cl(e) {
  const t = Object.assign({}, e);
  return t.randomizer = void 0, e.seed && (t.seed = e.seed + 1), t;
}
function If(e) {
  return e.randomizer || (e.randomizer = new s_(e.seed || 0)), e.randomizer.next();
}
function wn(e, t, r, i = 1) {
  return r.roughness * i * (If(r) * (t - e) + e);
}
function K(e, t, r = 1) {
  return wn(-e, e, t, r);
}
function ke(e, t, r, i, n, a = !1) {
  const o = a ? n.disableMultiStrokeFill : n.disableMultiStroke, s = ts(e, t, r, i, n, !0, !1);
  if (o) return s;
  const l = ts(e, t, r, i, n, !0, !0);
  return s.concat(l);
}
function ts(e, t, r, i, n, a, o) {
  const s = Math.pow(e - r, 2) + Math.pow(t - i, 2), l = Math.sqrt(s);
  let c = 1;
  c = l < 200 ? 1 : l > 500 ? 0.4 : -16668e-7 * l + 1.233334;
  let h = n.maxRandomnessOffset || 0;
  h * h * 100 > s && (h = l / 10);
  const u = h / 2, f = 0.2 + 0.2 * If(n);
  let d = n.bowing * n.maxRandomnessOffset * (i - t) / 200, g = n.bowing * n.maxRandomnessOffset * (e - r) / 200;
  d = K(d, n, c), g = K(g, n, c);
  const m = [], x = () => K(u, n, c), y = () => K(h, n, c), b = n.preserveVertices;
  return o ? m.push({ op: "move", data: [e + (b ? 0 : x()), t + (b ? 0 : x())] }) : m.push({ op: "move", data: [e + (b ? 0 : K(h, n, c)), t + (b ? 0 : K(h, n, c))] }), o ? m.push({ op: "bcurveTo", data: [d + e + (r - e) * f + x(), g + t + (i - t) * f + x(), d + e + 2 * (r - e) * f + x(), g + t + 2 * (i - t) * f + x(), r + (b ? 0 : x()), i + (b ? 0 : x())] }) : m.push({ op: "bcurveTo", data: [d + e + (r - e) * f + y(), g + t + (i - t) * f + y(), d + e + 2 * (r - e) * f + y(), g + t + 2 * (i - t) * f + y(), r + (b ? 0 : y()), i + (b ? 0 : y())] }), m;
}
function Bi(e, t, r) {
  if (!e.length) return [];
  const i = [];
  i.push([e[0][0] + K(t, r), e[0][1] + K(t, r)]), i.push([e[0][0] + K(t, r), e[0][1] + K(t, r)]);
  for (let n = 1; n < e.length; n++) i.push([e[n][0] + K(t, r), e[n][1] + K(t, r)]), n === e.length - 1 && i.push([e[n][0] + K(t, r), e[n][1] + K(t, r)]);
  return _n(i, null, r);
}
function _n(e, t, r) {
  const i = e.length, n = [];
  if (i > 3) {
    const a = [], o = 1 - r.curveTightness;
    n.push({ op: "move", data: [e[1][0], e[1][1]] });
    for (let s = 1; s + 2 < i; s++) {
      const l = e[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * e[s + 1][0] - o * e[s - 1][0]) / 6, l[1] + (o * e[s + 1][1] - o * e[s - 1][1]) / 6], a[2] = [e[s + 1][0] + (o * e[s][0] - o * e[s + 2][0]) / 6, e[s + 1][1] + (o * e[s][1] - o * e[s + 2][1]) / 6], a[3] = [e[s + 1][0], e[s + 1][1]], n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[3][0], a[3][1]] });
    }
  } else i === 3 ? (n.push({ op: "move", data: [e[1][0], e[1][1]] }), n.push({ op: "bcurveTo", data: [e[1][0], e[1][1], e[2][0], e[2][1], e[2][0], e[2][1]] })) : i === 2 && n.push(...ts(e[0][0], e[0][1], e[1][0], e[1][1], r, !0, !0));
  return n;
}
function wl(e, t, r, i, n, a, o, s) {
  const l = [], c = [];
  if (s.roughness === 0) {
    e /= 4, c.push([t + i * Math.cos(-e), r + n * Math.sin(-e)]);
    for (let h = 0; h <= 2 * Math.PI; h += e) {
      const u = [t + i * Math.cos(h), r + n * Math.sin(h)];
      l.push(u), c.push(u);
    }
    c.push([t + i * Math.cos(0), r + n * Math.sin(0)]), c.push([t + i * Math.cos(e), r + n * Math.sin(e)]);
  } else {
    const h = K(0.5, s) - Math.PI / 2;
    c.push([K(a, s) + t + 0.9 * i * Math.cos(h - e), K(a, s) + r + 0.9 * n * Math.sin(h - e)]);
    const u = 2 * Math.PI + h - 0.01;
    for (let f = h; f < u; f += e) {
      const d = [K(a, s) + t + i * Math.cos(f), K(a, s) + r + n * Math.sin(f)];
      l.push(d), c.push(d);
    }
    c.push([K(a, s) + t + i * Math.cos(h + 2 * Math.PI + 0.5 * o), K(a, s) + r + n * Math.sin(h + 2 * Math.PI + 0.5 * o)]), c.push([K(a, s) + t + 0.98 * i * Math.cos(h + o), K(a, s) + r + 0.98 * n * Math.sin(h + o)]), c.push([K(a, s) + t + 0.9 * i * Math.cos(h + 0.5 * o), K(a, s) + r + 0.9 * n * Math.sin(h + 0.5 * o)]);
  }
  return [c, l];
}
function _l(e, t, r, i, n, a, o, s, l) {
  const c = a + K(0.1, l), h = [];
  h.push([K(s, l) + t + 0.9 * i * Math.cos(c - e), K(s, l) + r + 0.9 * n * Math.sin(c - e)]);
  for (let u = c; u <= o; u += e) h.push([K(s, l) + t + i * Math.cos(u), K(s, l) + r + n * Math.sin(u)]);
  return h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), h.push([t + i * Math.cos(o), r + n * Math.sin(o)]), _n(h, null, l);
}
function h_(e, t, r, i, n, a, o, s) {
  const l = [], c = [s.maxRandomnessOffset || 1, (s.maxRandomnessOffset || 1) + 0.3];
  let h = [0, 0];
  const u = s.disableMultiStroke ? 1 : 2, f = s.preserveVertices;
  for (let d = 0; d < u; d++) d === 0 ? l.push({ op: "move", data: [o[0], o[1]] }) : l.push({ op: "move", data: [o[0] + (f ? 0 : K(c[0], s)), o[1] + (f ? 0 : K(c[0], s))] }), h = f ? [n, a] : [n + K(c[d], s), a + K(c[d], s)], l.push({ op: "bcurveTo", data: [e + K(c[d], s), t + K(c[d], s), r + K(c[d], s), i + K(c[d], s), h[0], h[1]] });
  return l;
}
function Rr(e) {
  return [...e];
}
function vl(e, t = 0) {
  const r = e.length;
  if (r < 3) throw new Error("A curve must have at least three points.");
  const i = [];
  if (r === 3) i.push(Rr(e[0]), Rr(e[1]), Rr(e[2]), Rr(e[2]));
  else {
    const n = [];
    n.push(e[0], e[0]);
    for (let s = 1; s < e.length; s++) n.push(e[s]), s === e.length - 1 && n.push(e[s]);
    const a = [], o = 1 - t;
    i.push(Rr(n[0]));
    for (let s = 1; s + 2 < n.length; s++) {
      const l = n[s];
      a[0] = [l[0], l[1]], a[1] = [l[0] + (o * n[s + 1][0] - o * n[s - 1][0]) / 6, l[1] + (o * n[s + 1][1] - o * n[s - 1][1]) / 6], a[2] = [n[s + 1][0] + (o * n[s][0] - o * n[s + 2][0]) / 6, n[s + 1][1] + (o * n[s][1] - o * n[s + 2][1]) / 6], a[3] = [n[s + 1][0], n[s + 1][1]], i.push(a[1], a[2], a[3]);
    }
  }
  return i;
}
function zi(e, t) {
  return Math.pow(e[0] - t[0], 2) + Math.pow(e[1] - t[1], 2);
}
function u_(e, t, r) {
  const i = zi(t, r);
  if (i === 0) return zi(e, t);
  let n = ((e[0] - t[0]) * (r[0] - t[0]) + (e[1] - t[1]) * (r[1] - t[1])) / i;
  return n = Math.max(0, Math.min(1, n)), zi(e, Fe(t, r, n));
}
function Fe(e, t, r) {
  return [e[0] + (t[0] - e[0]) * r, e[1] + (t[1] - e[1]) * r];
}
function es(e, t, r, i) {
  const n = i || [];
  if (function(s, l) {
    const c = s[l + 0], h = s[l + 1], u = s[l + 2], f = s[l + 3];
    let d = 3 * h[0] - 2 * c[0] - f[0];
    d *= d;
    let g = 3 * h[1] - 2 * c[1] - f[1];
    g *= g;
    let m = 3 * u[0] - 2 * f[0] - c[0];
    m *= m;
    let x = 3 * u[1] - 2 * f[1] - c[1];
    return x *= x, d < m && (d = m), g < x && (g = x), d + g;
  }(e, t) < r) {
    const s = e[t + 0];
    n.length ? (a = n[n.length - 1], o = s, Math.sqrt(zi(a, o)) > 1 && n.push(s)) : n.push(s), n.push(e[t + 3]);
  } else {
    const l = e[t + 0], c = e[t + 1], h = e[t + 2], u = e[t + 3], f = Fe(l, c, 0.5), d = Fe(c, h, 0.5), g = Fe(h, u, 0.5), m = Fe(f, d, 0.5), x = Fe(d, g, 0.5), y = Fe(m, x, 0.5);
    es([l, f, m, y], 0, r, n), es([y, x, g, u], 0, r, n);
  }
  var a, o;
  return n;
}
function f_(e, t) {
  return vn(e, 0, e.length, t);
}
function vn(e, t, r, i, n) {
  const a = n || [], o = e[t], s = e[r - 1];
  let l = 0, c = 1;
  for (let h = t + 1; h < r - 1; ++h) {
    const u = u_(e[h], o, s);
    u > l && (l = u, c = h);
  }
  return Math.sqrt(l) > i ? (vn(e, t, c + 1, i, a), vn(e, c, r, i, a)) : (a.length || a.push(o), a.push(s)), a;
}
function fa(e, t = 0.15, r) {
  const i = [], n = (e.length - 1) / 3;
  for (let a = 0; a < n; a++)
    es(e, 3 * a, t, i);
  return r && r > 0 ? vn(i, 0, i.length, r) : i;
}
const Nt = "none";
class kn {
  constructor(t) {
    this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: 0.95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: 0.8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options));
  }
  static newSeed() {
    return Math.floor(Math.random() * 2 ** 31);
  }
  _o(t) {
    return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions;
  }
  _d(t, r, i) {
    return { shape: t, sets: r || [], options: i || this.defaultOptions };
  }
  line(t, r, i, n, a) {
    const o = this._o(a);
    return this._d("line", [Of(t, r, i, n, o)], o);
  }
  rectangle(t, r, i, n, a) {
    const o = this._o(a), s = [], l = c_(t, r, i, n, o);
    if (o.fill) {
      const c = [[t, r], [t + i, r], [t + i, r + n], [t, r + n]];
      o.fillStyle === "solid" ? s.push(ua([c], o)) : s.push(tr([c], o));
    }
    return o.stroke !== Nt && s.push(l), this._d("rectangle", s, o);
  }
  ellipse(t, r, i, n, a) {
    const o = this._o(a), s = [], l = Rf(i, n, o), c = Ja(t, r, o, l);
    if (o.fill) if (o.fillStyle === "solid") {
      const h = Ja(t, r, o, l).opset;
      h.type = "fillPath", s.push(h);
    } else s.push(tr([c.estimatedPoints], o));
    return o.stroke !== Nt && s.push(c.opset), this._d("ellipse", s, o);
  }
  circle(t, r, i, n) {
    const a = this.ellipse(t, r, i, i, n);
    return a.shape = "circle", a;
  }
  linearPath(t, r) {
    const i = this._o(r);
    return this._d("linearPath", [Ni(t, !1, i)], i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this._o(l), h = [], u = xl(t, r, i, n, a, o, s, !0, c);
    if (s && c.fill) if (c.fillStyle === "solid") {
      const f = Object.assign({}, c);
      f.disableMultiStroke = !0;
      const d = xl(t, r, i, n, a, o, !0, !1, f);
      d.type = "fillPath", h.push(d);
    } else h.push(function(f, d, g, m, x, y, b) {
      const w = f, k = d;
      let _ = Math.abs(g / 2), C = Math.abs(m / 2);
      _ += K(0.01 * _, b), C += K(0.01 * C, b);
      let v = x, D = y;
      for (; v < 0; ) v += 2 * Math.PI, D += 2 * Math.PI;
      D - v > 2 * Math.PI && (v = 0, D = 2 * Math.PI);
      const R = (D - v) / b.curveStepCount, O = [];
      for (let A = v; A <= D; A += R) O.push([w + _ * Math.cos(A), k + C * Math.sin(A)]);
      return O.push([w + _ * Math.cos(D), k + C * Math.sin(D)]), O.push([w, k]), tr([O], b);
    }(t, r, i, n, a, o, c));
    return c.stroke !== Nt && h.push(u), this._d("arc", h, c);
  }
  curve(t, r) {
    const i = this._o(r), n = [], a = yl(t, i);
    if (i.fill && i.fill !== Nt) if (i.fillStyle === "solid") {
      const o = yl(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(o.ops) });
    } else {
      const o = [], s = t;
      if (s.length) {
        const l = typeof s[0][0] == "number" ? [s] : s;
        for (const c of l) c.length < 3 ? o.push(...c) : c.length === 3 ? o.push(...fa(vl([c[0], c[0], c[1], c[2]]), 10, (1 + i.roughness) / 2)) : o.push(...fa(vl(c), 10, (1 + i.roughness) / 2));
      }
      o.length && n.push(tr([o], i));
    }
    return i.stroke !== Nt && n.push(a), this._d("curve", n, i);
  }
  polygon(t, r) {
    const i = this._o(r), n = [], a = Ni(t, !0, i);
    return i.fill && (i.fillStyle === "solid" ? n.push(ua([t], i)) : n.push(tr([t], i))), i.stroke !== Nt && n.push(a), this._d("polygon", n, i);
  }
  path(t, r) {
    const i = this._o(r), n = [];
    if (!t) return this._d("path", n, i);
    t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " ");
    const a = i.fill && i.fill !== "transparent" && i.fill !== Nt, o = i.stroke !== Nt, s = !!(i.simplification && i.simplification < 1), l = function(h, u, f) {
      const d = Ef(Ff(lo(h))), g = [];
      let m = [], x = [0, 0], y = [];
      const b = () => {
        y.length >= 4 && m.push(...fa(y, u)), y = [];
      }, w = () => {
        b(), m.length && (g.push(m), m = []);
      };
      for (const { key: _, data: C } of d) switch (_) {
        case "M":
          w(), x = [C[0], C[1]], m.push(x);
          break;
        case "L":
          b(), m.push([C[0], C[1]]);
          break;
        case "C":
          if (!y.length) {
            const v = m.length ? m[m.length - 1] : x;
            y.push([v[0], v[1]]);
          }
          y.push([C[0], C[1]]), y.push([C[2], C[3]]), y.push([C[4], C[5]]);
          break;
        case "Z":
          b(), m.push([x[0], x[1]]);
      }
      if (w(), !f) return g;
      const k = [];
      for (const _ of g) {
        const C = f_(_, f);
        C.length && k.push(C);
      }
      return k;
    }(t, 1, s ? 4 - 4 * (i.simplification || 1) : (1 + i.roughness) / 2), c = bl(t, i);
    if (a) if (i.fillStyle === "solid") if (l.length === 1) {
      const h = bl(t, Object.assign(Object.assign({}, i), { disableMultiStroke: !0, roughness: i.roughness ? i.roughness + i.fillShapeRoughnessGain : 0 }));
      n.push({ type: "fillPath", ops: this._mergedShape(h.ops) });
    } else n.push(ua(l, i));
    else n.push(tr(l, i));
    return o && (s ? l.forEach((h) => {
      n.push(Ni(h, !1, i));
    }) : n.push(c)), this._d("path", n, i);
  }
  opsToPath(t, r) {
    let i = "";
    for (const n of t.ops) {
      const a = typeof r == "number" && r >= 0 ? n.data.map((o) => +o.toFixed(r)) : n.data;
      switch (n.op) {
        case "move":
          i += `M${a[0]} ${a[1]} `;
          break;
        case "bcurveTo":
          i += `C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;
          break;
        case "lineTo":
          i += `L${a[0]} ${a[1]} `;
      }
    }
    return i.trim();
  }
  toPaths(t) {
    const r = t.sets || [], i = t.options || this.defaultOptions, n = [];
    for (const a of r) {
      let o = null;
      switch (a.type) {
        case "path":
          o = { d: this.opsToPath(a), stroke: i.stroke, strokeWidth: i.strokeWidth, fill: Nt };
          break;
        case "fillPath":
          o = { d: this.opsToPath(a), stroke: Nt, strokeWidth: 0, fill: i.fill || Nt };
          break;
        case "fillSketch":
          o = this.fillSketch(a, i);
      }
      o && n.push(o);
    }
    return n;
  }
  fillSketch(t, r) {
    let i = r.fillWeight;
    return i < 0 && (i = r.strokeWidth / 2), { d: this.opsToPath(t), stroke: r.fill || Nt, strokeWidth: i, fill: Nt };
  }
  _mergedShape(t) {
    return t.filter((r, i) => i === 0 || r.op !== "move");
  }
}
class d_ {
  constructor(t, r) {
    this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new kn(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.ctx, a = t.options.fixedDecimalPlaceDigits;
    for (const o of r) switch (o.type) {
      case "path":
        n.save(), n.strokeStyle = i.stroke === "none" ? "transparent" : i.stroke, n.lineWidth = i.strokeWidth, i.strokeLineDash && n.setLineDash(i.strokeLineDash), i.strokeLineDashOffset && (n.lineDashOffset = i.strokeLineDashOffset), this._drawToContext(n, o, a), n.restore();
        break;
      case "fillPath": {
        n.save(), n.fillStyle = i.fill || "";
        const s = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
        this._drawToContext(n, o, a, s), n.restore();
        break;
      }
      case "fillSketch":
        this.fillSketch(n, o, i);
    }
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2), t.save(), i.fillLineDash && t.setLineDash(i.fillLineDash), i.fillLineDashOffset && (t.lineDashOffset = i.fillLineDashOffset), t.strokeStyle = i.fill || "", t.lineWidth = n, this._drawToContext(t, r, i.fixedDecimalPlaceDigits), t.restore();
  }
  _drawToContext(t, r, i, n = "nonzero") {
    t.beginPath();
    for (const a of r.ops) {
      const o = typeof i == "number" && i >= 0 ? a.data.map((s) => +s.toFixed(i)) : a.data;
      switch (a.op) {
        case "move":
          t.moveTo(o[0], o[1]);
          break;
        case "bcurveTo":
          t.bezierCurveTo(o[0], o[1], o[2], o[3], o[4], o[5]);
          break;
        case "lineTo":
          t.lineTo(o[0], o[1]);
      }
    }
    r.type === "fillPath" ? t.fill(n) : t.stroke();
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o), o;
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o), o;
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o), o;
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a), a;
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i), i;
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i), i;
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c), c;
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i), i;
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i), i;
  }
}
const Li = "http://www.w3.org/2000/svg";
class p_ {
  constructor(t, r) {
    this.svg = t, this.gen = new kn(r);
  }
  draw(t) {
    const r = t.sets || [], i = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, a = n.createElementNS(Li, "g"), o = t.options.fixedDecimalPlaceDigits;
    for (const s of r) {
      let l = null;
      switch (s.type) {
        case "path":
          l = n.createElementNS(Li, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", i.stroke), l.setAttribute("stroke-width", i.strokeWidth + ""), l.setAttribute("fill", "none"), i.strokeLineDash && l.setAttribute("stroke-dasharray", i.strokeLineDash.join(" ").trim()), i.strokeLineDashOffset && l.setAttribute("stroke-dashoffset", `${i.strokeLineDashOffset}`);
          break;
        case "fillPath":
          l = n.createElementNS(Li, "path"), l.setAttribute("d", this.opsToPath(s, o)), l.setAttribute("stroke", "none"), l.setAttribute("stroke-width", "0"), l.setAttribute("fill", i.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || l.setAttribute("fill-rule", "evenodd");
          break;
        case "fillSketch":
          l = this.fillSketch(n, s, i);
      }
      l && a.appendChild(l);
    }
    return a;
  }
  fillSketch(t, r, i) {
    let n = i.fillWeight;
    n < 0 && (n = i.strokeWidth / 2);
    const a = t.createElementNS(Li, "path");
    return a.setAttribute("d", this.opsToPath(r, i.fixedDecimalPlaceDigits)), a.setAttribute("stroke", i.fill || ""), a.setAttribute("stroke-width", n + ""), a.setAttribute("fill", "none"), i.fillLineDash && a.setAttribute("stroke-dasharray", i.fillLineDash.join(" ").trim()), i.fillLineDashOffset && a.setAttribute("stroke-dashoffset", `${i.fillLineDashOffset}`), a;
  }
  get generator() {
    return this.gen;
  }
  getDefaultOptions() {
    return this.gen.defaultOptions;
  }
  opsToPath(t, r) {
    return this.gen.opsToPath(t, r);
  }
  line(t, r, i, n, a) {
    const o = this.gen.line(t, r, i, n, a);
    return this.draw(o);
  }
  rectangle(t, r, i, n, a) {
    const o = this.gen.rectangle(t, r, i, n, a);
    return this.draw(o);
  }
  ellipse(t, r, i, n, a) {
    const o = this.gen.ellipse(t, r, i, n, a);
    return this.draw(o);
  }
  circle(t, r, i, n) {
    const a = this.gen.circle(t, r, i, n);
    return this.draw(a);
  }
  linearPath(t, r) {
    const i = this.gen.linearPath(t, r);
    return this.draw(i);
  }
  polygon(t, r) {
    const i = this.gen.polygon(t, r);
    return this.draw(i);
  }
  arc(t, r, i, n, a, o, s = !1, l) {
    const c = this.gen.arc(t, r, i, n, a, o, s, l);
    return this.draw(c);
  }
  curve(t, r) {
    const i = this.gen.curve(t, r);
    return this.draw(i);
  }
  path(t, r) {
    const i = this.gen.path(t, r);
    return this.draw(i);
  }
}
var W = { canvas: (e, t) => new d_(e, t), svg: (e, t) => new p_(e, t), generator: (e) => new kn(e), newSeed: () => kn.newSeed() }, Z = /* @__PURE__ */ p(async (e, t, r) => {
  var u, f;
  let i;
  const n = t.useHtmlLabels || Ct((u = nt()) == null ? void 0 : u.htmlLabels);
  r ? i = r : i = "node default";
  const a = e.insert("g").attr("class", i).attr("id", t.domId || t.id), o = a.insert("g").attr("class", "label").attr("style", Mt(t.labelStyle));
  let s;
  t.label === void 0 ? s = "" : s = typeof t.label == "string" ? t.label : t.label[0];
  const l = await Be(o, jt(Ke(s), nt()), {
    useHtmlLabels: n,
    width: t.width || ((f = nt().flowchart) == null ? void 0 : f.wrappingWidth),
    // @ts-expect-error -- This is currently not used. Should this be `classes` instead?
    cssClasses: "markdown-node-label",
    style: t.labelStyle,
    addSvgBackground: !!t.icon || !!t.img
  });
  let c = l.getBBox();
  const h = ((t == null ? void 0 : t.padding) ?? 0) / 2;
  if (n) {
    const d = l.children[0], g = rt(l), m = d.getElementsByTagName("img");
    if (m) {
      const x = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...m].map(
          (y) => new Promise((b) => {
            function w() {
              if (y.style.display = "flex", y.style.flexDirection = "column", x) {
                const k = nt().fontSize ? nt().fontSize : window.getComputedStyle(document.body).fontSize, _ = 5, [C = Xl.fontSize] = Hn(k), v = C * _ + "px";
                y.style.minWidth = v, y.style.maxWidth = v;
              } else
                y.style.width = "100%";
              b(y);
            }
            p(w, "setupImage"), setTimeout(() => {
              y.complete && w();
            }), y.addEventListener("error", w), y.addEventListener("load", w);
          })
        )
      );
    }
    c = d.getBoundingClientRect(), g.attr("width", c.width), g.attr("height", c.height);
  }
  return n ? o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")") : o.attr("transform", "translate(0, " + -c.height / 2 + ")"), t.centerLabel && o.attr("transform", "translate(" + -c.width / 2 + ", " + -c.height / 2 + ")"), o.insert("rect", ":first-child"), { shapeSvg: a, bbox: c, halfPadding: h, label: o };
}, "labelHelper"), da = /* @__PURE__ */ p(async (e, t, r) => {
  var l, c, h, u, f, d;
  const i = r.useHtmlLabels || Ct((c = (l = nt()) == null ? void 0 : l.flowchart) == null ? void 0 : c.htmlLabels), n = e.insert("g").attr("class", "label").attr("style", r.labelStyle || ""), a = await Be(n, jt(Ke(t), nt()), {
    useHtmlLabels: i,
    width: r.width || ((u = (h = nt()) == null ? void 0 : h.flowchart) == null ? void 0 : u.wrappingWidth),
    style: r.labelStyle,
    addSvgBackground: !!r.icon || !!r.img
  });
  let o = a.getBBox();
  const s = r.padding / 2;
  if (Ct((d = (f = nt()) == null ? void 0 : f.flowchart) == null ? void 0 : d.htmlLabels)) {
    const g = a.children[0], m = rt(a);
    o = g.getBoundingClientRect(), m.attr("width", o.width), m.attr("height", o.height);
  }
  return i ? n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")") : n.attr("transform", "translate(0, " + -o.height / 2 + ")"), r.centerLabel && n.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), n.insert("rect", ":first-child"), { shapeSvg: e, bbox: o, halfPadding: s, label: n };
}, "insertLabel"), j = /* @__PURE__ */ p((e, t) => {
  const r = t.node().getBBox();
  e.width = r.width, e.height = r.height;
}, "updateNodeBounds"), V = /* @__PURE__ */ p((e, t) => (e.look === "handDrawn" ? "rough-node" : "node") + " " + e.cssClasses + " " + (t || ""), "getNodeClasses");
function tt(e) {
  const t = e.map((r, i) => `${i === 0 ? "M" : "L"}${r.x},${r.y}`);
  return t.push("Z"), t.join(" ");
}
p(tt, "createPathFromPoints");
function Se(e, t, r, i, n, a) {
  const o = [], l = r - e, c = i - t, h = l / a, u = 2 * Math.PI / h, f = t + c / 2;
  for (let d = 0; d <= 50; d++) {
    const g = d / 50, m = e + g * l, x = f + n * Math.sin(u * (m - e));
    o.push({ x: m, y: x });
  }
  return o;
}
p(Se, "generateFullSineWavePoints");
function li(e, t, r, i, n, a) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -d, y: -g });
  }
  return o;
}
p(li, "generateCirclePoints");
var g_ = /* @__PURE__ */ p((e, t) => {
  var r = e.x, i = e.y, n = t.x - r, a = t.y - i, o = e.width / 2, s = e.height / 2, l, c;
  return Math.abs(a) * o > Math.abs(n) * s ? (a < 0 && (s = -s), l = a === 0 ? 0 : s * n / a, c = s) : (n < 0 && (o = -o), l = o, c = n === 0 ? 0 : o * a / n), { x: r + l, y: i + c };
}, "intersectRect"), Lr = g_;
function Pf(e, t) {
  t && e.attr("style", t);
}
p(Pf, "applyStyle");
async function Nf(e) {
  const t = rt(document.createElementNS("http://www.w3.org/2000/svg", "foreignObject")), r = t.append("xhtml:div"), i = nt();
  let n = e.label;
  e.label && yr(e.label) && (n = await ps(e.label.replace(kr.lineBreakRegex, `
`), i));
  const o = '<span class="' + (e.isNode ? "nodeLabel" : "edgeLabel") + '" ' + (e.labelStyle ? 'style="' + e.labelStyle + '"' : "") + // codeql [js/html-constructed-from-input] : false positive
  ">" + n + "</span>";
  return r.html(jt(o, i)), Pf(r, e.labelStyle), r.style("display", "inline-block"), r.style("padding-right", "1px"), r.style("white-space", "nowrap"), r.attr("xmlns", "http://www.w3.org/1999/xhtml"), t.node();
}
p(Nf, "addHtmlLabel");
var m_ = /* @__PURE__ */ p(async (e, t, r, i) => {
  let n = e || "";
  if (typeof n == "object" && (n = n[0]), Ct(nt().flowchart.htmlLabels)) {
    n = n.replace(/\\n|\n/g, "<br />"), F.info("vertexText" + n);
    const a = {
      isNode: i,
      label: Ke(n).replace(
        /fa[blrs]?:fa-[\w-]+/g,
        (s) => `<i class='${s.replace(":", " ")}'></i>`
      ),
      labelStyle: t && t.replace("fill:", "color:")
    };
    return await Nf(a);
  } else {
    const a = document.createElementNS("http://www.w3.org/2000/svg", "text");
    a.setAttribute("style", t.replace("color:", "fill:"));
    let o = [];
    typeof n == "string" ? o = n.split(/\\n|\n|<br\s*\/?>/gi) : Array.isArray(n) ? o = n : o = [];
    for (const s of o) {
      const l = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      l.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), l.setAttribute("dy", "1em"), l.setAttribute("x", "0"), r ? l.setAttribute("class", "title-row") : l.setAttribute("class", "row"), l.textContent = s.trim(), a.appendChild(l);
    }
    return a;
  }
}, "createLabel"), Pe = m_, Le = /* @__PURE__ */ p((e, t, r, i, n) => [
  "M",
  e + n,
  t,
  // Move to the first point
  "H",
  e + r - n,
  // Draw horizontal line to the beginning of the right corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r,
  t + n,
  // Draw arc to the right top corner
  "V",
  t + i - n,
  // Draw vertical line down to the beginning of the right bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + r - n,
  t + i,
  // Draw arc to the right bottom corner
  "H",
  e + n,
  // Draw horizontal line to the beginning of the left bottom corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e,
  t + i - n,
  // Draw arc to the left bottom corner
  "V",
  t + n,
  // Draw vertical line up to the beginning of the left top corner
  "A",
  n,
  n,
  0,
  0,
  1,
  e + n,
  t,
  // Draw arc to the left top corner
  "Z"
  // Close the path
].join(" "), "createRoundedRectPathD"), zf = /* @__PURE__ */ p(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = Y(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = Ct(r.flowchart.htmlLabels), d = u.insert("g").attr("class", "cluster-label "), g = await Be(d, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0
  });
  let m = g.getBBox();
  if (Ct(r.flowchart.htmlLabels)) {
    const v = g.children[0], D = rt(g);
    m = v.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const x = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const y = t.height, b = t.x - x / 2, w = t.y - y / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const v = W.svg(u), D = H(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 3,
      seed: n
    }), R = v.path(Le(b, w, x, y, 0), D);
    k = u.insert(() => (F.debug("Rough node insert CXC", R), R), ":first-child"), k.select("path:nth-child(2)").attr("style", c.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", w).attr("width", x).attr("height", y);
  const { subGraphTitleTopMargin: _ } = Ns(r);
  if (d.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + _})`
  ), s) {
    const v = d.select("span");
    v && v.attr("style", s);
  }
  const C = k.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(v) {
    return Lr(t, v);
  }, { cluster: u, labelBBox: m };
}, "rect"), y_ = /* @__PURE__ */ p((e, t) => {
  const r = e.insert("g").attr("class", "note-cluster").attr("id", t.id), i = r.insert("rect", ":first-child"), n = 0 * t.padding, a = n / 2;
  i.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - a).attr("y", t.y - t.height / 2 - a).attr("width", t.width + n).attr("height", t.height + n).attr("fill", "none");
  const o = i.node().getBBox();
  return t.width = o.width, t.height = o.height, t.intersect = function(s) {
    return Lr(t, s);
  }, { cluster: r, labelBBox: { width: 0, height: 0 } };
}, "noteGroup"), x_ = /* @__PURE__ */ p(async (e, t) => {
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { altBackground: a, compositeBackground: o, compositeTitleBackground: s, nodeBorder: l } = i, c = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-id", t.id).attr("data-look", t.look), h = c.insert("g", ":first-child"), u = c.insert("g").attr("class", "cluster-label");
  let f = c.append("rect");
  const d = u.node().appendChild(await Pe(t.label, t.labelStyle, void 0, !0));
  let g = d.getBBox();
  if (Ct(r.flowchart.htmlLabels)) {
    const R = d.children[0], O = rt(d);
    g = R.getBoundingClientRect(), O.attr("width", g.width), O.attr("height", g.height);
  }
  const m = 0 * t.padding, x = m / 2, y = (t.width <= g.width + t.padding ? g.width + t.padding : t.width) + m;
  t.width <= g.width + t.padding ? t.diff = (y - t.width) / 2 - t.padding : t.diff = -t.padding;
  const b = t.height + m, w = t.height + m - g.height - 6, k = t.x - y / 2, _ = t.y - b / 2;
  t.width = y;
  const C = t.y - t.height / 2 - x + g.height + 2;
  let v;
  if (t.look === "handDrawn") {
    const R = t.cssClasses.includes("statediagram-cluster-alt"), O = W.svg(c), A = t.rx || t.ry ? O.path(Le(k, _, y, b, 10), {
      roughness: 0.7,
      fill: s,
      fillStyle: "solid",
      stroke: l,
      seed: n
    }) : O.rectangle(k, _, y, b, { seed: n });
    v = c.insert(() => A, ":first-child");
    const I = O.rectangle(k, C, y, w, {
      fill: R ? a : o,
      fillStyle: R ? "hachure" : "solid",
      stroke: l,
      seed: n
    });
    v = c.insert(() => A, ":first-child"), f = c.insert(() => I);
  } else
    v = h.insert("rect", ":first-child"), v.attr("class", "outer").attr("x", k).attr("y", _).attr("width", y).attr("height", b).attr("data-look", t.look), f.attr("class", "inner").attr("x", k).attr("y", C).attr("width", y).attr("height", w);
  u.attr(
    "transform",
    `translate(${t.x - g.width / 2}, ${_ + 1 - (Ct(r.flowchart.htmlLabels) ? 0 : 3)})`
  );
  const D = v.node().getBBox();
  return t.height = D.height, t.offsetX = 0, t.offsetY = g.height - t.padding / 2, t.labelBBox = g, t.intersect = function(R) {
    return Lr(t, R);
  }, { cluster: c, labelBBox: g };
}, "roundedWithTitle"), b_ = /* @__PURE__ */ p(async (e, t) => {
  F.info("Creating subgraph rect for ", t.id, t);
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { clusterBkg: a, clusterBorder: o } = i, { labelStyles: s, nodeStyles: l, borderStyles: c, backgroundStyles: h } = Y(t), u = e.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.id).attr("data-look", t.look), f = Ct(r.flowchart.htmlLabels), d = u.insert("g").attr("class", "cluster-label "), g = await Be(d, t.label, {
    style: t.labelStyle,
    useHtmlLabels: f,
    isNode: !0,
    width: t.width
  });
  let m = g.getBBox();
  if (Ct(r.flowchart.htmlLabels)) {
    const v = g.children[0], D = rt(g);
    m = v.getBoundingClientRect(), D.attr("width", m.width), D.attr("height", m.height);
  }
  const x = t.width <= m.width + t.padding ? m.width + t.padding : t.width;
  t.width <= m.width + t.padding ? t.diff = (x - t.width) / 2 - t.padding : t.diff = -t.padding;
  const y = t.height, b = t.x - x / 2, w = t.y - y / 2;
  F.trace("Data ", t, JSON.stringify(t));
  let k;
  if (t.look === "handDrawn") {
    const v = W.svg(u), D = H(t, {
      roughness: 0.7,
      fill: a,
      // fill: 'red',
      stroke: o,
      fillWeight: 4,
      seed: n
    }), R = v.path(Le(b, w, x, y, t.rx), D);
    k = u.insert(() => (F.debug("Rough node insert CXC", R), R), ":first-child"), k.select("path:nth-child(2)").attr("style", c.join(";")), k.select("path").attr("style", h.join(";").replace("fill", "stroke"));
  } else
    k = u.insert("rect", ":first-child"), k.attr("style", l).attr("rx", t.rx).attr("ry", t.ry).attr("x", b).attr("y", w).attr("width", x).attr("height", y);
  const { subGraphTitleTopMargin: _ } = Ns(r);
  if (d.attr(
    "transform",
    // This puts the label on top of the box instead of inside it
    `translate(${t.x - m.width / 2}, ${t.y - t.height / 2 + _})`
  ), s) {
    const v = d.select("span");
    v && v.attr("style", s);
  }
  const C = k.node().getBBox();
  return t.offsetX = 0, t.width = C.width, t.height = C.height, t.offsetY = m.height - t.padding / 2, t.intersect = function(v) {
    return Lr(t, v);
  }, { cluster: u, labelBBox: m };
}, "kanbanSection"), C_ = /* @__PURE__ */ p((e, t) => {
  const r = nt(), { themeVariables: i, handDrawnSeed: n } = r, { nodeBorder: a } = i, o = e.insert("g").attr("class", t.cssClasses).attr("id", t.id).attr("data-look", t.look), s = o.insert("g", ":first-child"), l = 0 * t.padding, c = t.width + l;
  t.diff = -t.padding;
  const h = t.height + l, u = t.x - c / 2, f = t.y - h / 2;
  t.width = c;
  let d;
  if (t.look === "handDrawn") {
    const x = W.svg(o).rectangle(u, f, c, h, {
      fill: "lightgrey",
      roughness: 0.5,
      strokeLineDash: [5],
      stroke: a,
      seed: n
    });
    d = o.insert(() => x, ":first-child");
  } else
    d = s.insert("rect", ":first-child"), d.attr("class", "divider").attr("x", u).attr("y", f).attr("width", c).attr("height", h).attr("data-look", t.look);
  const g = d.node().getBBox();
  return t.height = g.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function(m) {
    return Lr(t, m);
  }, { cluster: o, labelBBox: {} };
}, "divider"), w_ = zf, __ = {
  rect: zf,
  squareRect: w_,
  roundedWithTitle: x_,
  noteGroup: y_,
  divider: C_,
  kanbanSection: b_
}, qf = /* @__PURE__ */ new Map(), v_ = /* @__PURE__ */ p(async (e, t) => {
  const r = t.shape || "rect", i = await __[r](e, t);
  return qf.set(t.id, i), i;
}, "insertCluster"), GT = /* @__PURE__ */ p(() => {
  qf = /* @__PURE__ */ new Map();
}, "clear");
function Wf(e, t) {
  return e.intersect(t);
}
p(Wf, "intersectNode");
var k_ = Wf;
function Hf(e, t, r, i) {
  var n = e.x, a = e.y, o = n - i.x, s = a - i.y, l = Math.sqrt(t * t * s * s + r * r * o * o), c = Math.abs(t * r * o / l);
  i.x < n && (c = -c);
  var h = Math.abs(t * r * s / l);
  return i.y < a && (h = -h), { x: n + c, y: a + h };
}
p(Hf, "intersectEllipse");
var jf = Hf;
function Yf(e, t, r) {
  return jf(e, t, t, r);
}
p(Yf, "intersectCircle");
var S_ = Yf;
function Gf(e, t, r, i) {
  {
    const n = t.y - e.y, a = e.x - t.x, o = t.x * e.y - e.x * t.y, s = n * r.x + a * r.y + o, l = n * i.x + a * i.y + o, c = 1e-6;
    if (s !== 0 && l !== 0 && rs(s, l))
      return;
    const h = i.y - r.y, u = r.x - i.x, f = i.x * r.y - r.x * i.y, d = h * e.x + u * e.y + f, g = h * t.x + u * t.y + f;
    if (Math.abs(d) < c && Math.abs(g) < c && rs(d, g))
      return;
    const m = n * u - h * a;
    if (m === 0)
      return;
    const x = Math.abs(m / 2);
    let y = a * f - u * o;
    const b = y < 0 ? (y - x) / m : (y + x) / m;
    y = h * o - n * f;
    const w = y < 0 ? (y - x) / m : (y + x) / m;
    return { x: b, y: w };
  }
}
p(Gf, "intersectLine");
function rs(e, t) {
  return e * t > 0;
}
p(rs, "sameSign");
var T_ = Gf;
function Uf(e, t, r) {
  let i = e.x, n = e.y, a = [], o = Number.POSITIVE_INFINITY, s = Number.POSITIVE_INFINITY;
  typeof t.forEach == "function" ? t.forEach(function(h) {
    o = Math.min(o, h.x), s = Math.min(s, h.y);
  }) : (o = Math.min(o, t.x), s = Math.min(s, t.y));
  let l = i - e.width / 2 - o, c = n - e.height / 2 - s;
  for (let h = 0; h < t.length; h++) {
    let u = t[h], f = t[h < t.length - 1 ? h + 1 : 0], d = T_(
      e,
      r,
      { x: l + u.x, y: c + u.y },
      { x: l + f.x, y: c + f.y }
    );
    d && a.push(d);
  }
  return a.length ? (a.length > 1 && a.sort(function(h, u) {
    let f = h.x - r.x, d = h.y - r.y, g = Math.sqrt(f * f + d * d), m = u.x - r.x, x = u.y - r.y, y = Math.sqrt(m * m + x * x);
    return g < y ? -1 : g === y ? 0 : 1;
  }), a[0]) : e;
}
p(Uf, "intersectPolygon");
var B_ = Uf, N = {
  node: k_,
  circle: S_,
  ellipse: jf,
  polygon: B_,
  rect: Lr
};
function Xf(e, t) {
  const { labelStyles: r } = Y(t);
  t.labelStyle = r;
  const i = V(t);
  let n = i;
  i || (n = "anchor");
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = 1, { cssStyles: s } = t, l = W.svg(a), c = H(t, { fill: "black", stroke: "none", fillStyle: "solid" });
  t.look !== "handDrawn" && (c.roughness = 0);
  const h = l.circle(0, 0, o * 2, c), u = a.insert(() => h, ":first-child");
  return u.attr("class", "anchor").attr("style", Mt(s)), j(t, u), t.intersect = function(f) {
    return F.info("Circle intersect", t, o, f), N.circle(t, o, f);
  }, a;
}
p(Xf, "anchor");
function is(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, d = u / n, g = f / a, m = Math.sqrt(d ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const x = Math.sqrt(1 - m ** 2), y = l + x * a * Math.sin(h) * (o ? -1 : 1), b = c - x * n * Math.cos(h) * (o ? -1 : 1), w = Math.atan2((t - b) / a, (e - y) / n);
  let _ = Math.atan2((i - b) / a, (r - y) / n) - w;
  o && _ < 0 && (_ += 2 * Math.PI), !o && _ > 0 && (_ -= 2 * Math.PI);
  const C = [];
  for (let v = 0; v < 20; v++) {
    const D = v / 19, R = w + D * _, O = y + n * Math.cos(R), A = b + a * Math.sin(R);
    C.push({ x: O, y: A });
  }
  return C;
}
p(is, "generateArcPoints");
async function Vf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = a.width + t.padding + 20, s = a.height + t.padding, l = s / 2, c = l / (2.5 + s / 50), { cssStyles: h } = t, u = [
    { x: o / 2, y: -s / 2 },
    { x: -o / 2, y: -s / 2 },
    ...is(-o / 2, -s / 2, -o / 2, s / 2, c, l, !1),
    { x: o / 2, y: s / 2 },
    ...is(o / 2, s / 2, o / 2, -s / 2, c, l, !0)
  ], f = W.svg(n), d = H(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = tt(u), m = f.path(g, d), x = n.insert(() => m, ":first-child");
  return x.attr("class", "basic label-container"), h && t.look !== "handDrawn" && x.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), x.attr("transform", `translate(${c / 2}, 0)`), j(t, x), t.intersect = function(y) {
    return N.polygon(t, u, y);
  }, n;
}
p(Vf, "bowTieRect");
function Me(e, t, r, i) {
  return e.insert("polygon", ":first-child").attr(
    "points",
    i.map(function(n) {
      return n.x + "," + n.y;
    }).join(" ")
  ).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + r / 2 + ")");
}
p(Me, "insertPolygonShape");
async function Zf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = a.height + t.padding, s = 12, l = a.width + t.padding + s, c = 0, h = l, u = -o, f = 0, d = [
    { x: c + s, y: u },
    { x: h, y: u },
    { x: h, y: f },
    { x: c, y: f },
    { x: c, y: u + s },
    { x: c + s, y: u }
  ];
  let g;
  const { cssStyles: m } = t;
  if (t.look === "handDrawn") {
    const x = W.svg(n), y = H(t, {}), b = tt(d), w = x.path(b, y);
    g = n.insert(() => w, ":first-child").attr("transform", `translate(${-l / 2}, ${o / 2})`), m && g.attr("style", m);
  } else
    g = Me(n, l, o, d);
  return i && g.attr("style", i), j(t, g), t.intersect = function(x) {
    return N.polygon(t, d, x);
  }, n;
}
p(Zf, "card");
function Kf(e, t) {
  const { nodeStyles: r } = Y(t);
  t.label = "";
  const i = e.insert("g").attr("class", V(t)).attr("id", t.domId ?? t.id), { cssStyles: n } = t, a = Math.max(28, t.width ?? 0), o = [
    { x: 0, y: a / 2 },
    { x: a / 2, y: 0 },
    { x: 0, y: -a / 2 },
    { x: -a / 2, y: 0 }
  ], s = W.svg(i), l = H(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = tt(o), h = s.path(c, l), u = i.insert(() => h, ":first-child");
  return n && t.look !== "handDrawn" && u.selectAll("path").attr("style", n), r && t.look !== "handDrawn" && u.selectAll("path").attr("style", r), t.width = 28, t.height = 28, t.intersect = function(f) {
    return N.polygon(t, o, f);
  }, i;
}
p(Kf, "choice");
async function co(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o, halfPadding: s } = await Z(e, t, V(t)), l = (r == null ? void 0 : r.padding) ?? s, c = o.width / 2 + l;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const f = W.svg(a), d = H(t, {}), g = f.circle(0, 0, c * 2, d);
    h = a.insert(() => g, ":first-child"), h.attr("class", "basic label-container").attr("style", Mt(u));
  } else
    h = a.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", n).attr("r", c).attr("cx", 0).attr("cy", 0);
  return j(t, h), t.calcIntersect = function(f, d) {
    const g = f.width / 2;
    return N.circle(f, g, d);
  }, t.intersect = function(f) {
    return F.info("Circle intersect", t, c, f), N.circle(t, c, f);
  }, a;
}
p(co, "circle");
function Qf(e) {
  const t = Math.cos(Math.PI / 4), r = Math.sin(Math.PI / 4), i = e * 2, n = { x: i / 2 * t, y: i / 2 * r }, a = { x: -(i / 2) * t, y: i / 2 * r }, o = { x: -(i / 2) * t, y: -(i / 2) * r }, s = { x: i / 2 * t, y: -(i / 2) * r };
  return `M ${a.x},${a.y} L ${s.x},${s.y}
                   M ${n.x},${n.y} L ${o.x},${o.y}`;
}
p(Qf, "createLine");
function Jf(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r, t.label = "";
  const n = e.insert("g").attr("class", V(t)).attr("id", t.domId ?? t.id), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), { cssStyles: o } = t, s = W.svg(n), l = H(t, {});
  t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid");
  const c = s.circle(0, 0, a * 2, l), h = Qf(a), u = s.path(h, l), f = n.insert(() => c, ":first-child");
  return f.insert(() => u), o && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), i && t.look !== "handDrawn" && f.selectAll("path").attr("style", i), j(t, f), t.intersect = function(d) {
    return F.info("crossedCircle intersect", t, { radius: a, point: d }), N.circle(t, a, d);
  }, n;
}
p(Jf, "crossedCircle");
function le(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -d, y: -g });
  }
  return o;
}
p(le, "generateCirclePoints");
async function td(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...le(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...le(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...le(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...le(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...le(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...le(s / 2 + s * 0.1, -c, c, 20, -180, -270),
    ...le(s / 2 + s * 0.1, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...le(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2, y: l / 2 + c }
  ], d = W.svg(n), g = H(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = tt(u).replace("Z", ""), y = d.path(x, g), b = tt(f), w = d.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => w, ":first-child").attr("stroke-opacity", 0), k.insert(() => y, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + c - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, k), t.intersect = function(_) {
    return N.polygon(t, f, _);
  }, n;
}
p(td, "curlyBraceLeft");
function ce(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: d, y: g });
  }
  return o;
}
p(ce, "generateCirclePoints");
async function ed(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...ce(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...ce(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...ce(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...ce(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    { x: -s / 2, y: -l / 2 - c },
    { x: s / 2, y: -l / 2 - c },
    ...ce(s / 2, -l / 2, c, 20, -90, 0),
    { x: s / 2 + c, y: -c },
    ...ce(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...ce(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: s / 2 + c, y: l / 2 },
    ...ce(s / 2, l / 2, c, 20, 0, 90),
    { x: s / 2, y: l / 2 + c },
    { x: -s / 2, y: l / 2 + c }
  ], d = W.svg(n), g = H(t, { fill: "none" });
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const x = tt(u).replace("Z", ""), y = d.path(x, g), b = tt(f), w = d.path(b, { ...g }), k = n.insert("g", ":first-child");
  return k.insert(() => w, ":first-child").attr("stroke-opacity", 0), k.insert(() => y, ":first-child"), k.attr("class", "text"), h && t.look !== "handDrawn" && k.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(${-c}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, k), t.intersect = function(_) {
    return N.polygon(t, f, _);
  }, n;
}
p(ed, "curlyBraceRight");
function vt(e, t, r, i = 100, n = 0, a = 180) {
  const o = [], s = n * Math.PI / 180, h = (a * Math.PI / 180 - s) / (i - 1);
  for (let u = 0; u < i; u++) {
    const f = s + u * h, d = e + r * Math.cos(f), g = t + r * Math.sin(f);
    o.push({ x: -d, y: -g });
  }
  return o;
}
p(vt, "generateCirclePoints");
async function rd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = a.width + (t.padding ?? 0), l = a.height + (t.padding ?? 0), c = Math.max(5, l * 0.1), { cssStyles: h } = t, u = [
    ...vt(s / 2, -l / 2, c, 30, -90, 0),
    { x: -s / 2 - c, y: c },
    ...vt(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...vt(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: -l / 2 },
    ...vt(s / 2, l / 2, c, 20, 0, 90)
  ], f = [
    ...vt(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...vt(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...vt(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...vt(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], d = [
    { x: s / 2, y: -l / 2 - c },
    { x: -s / 2, y: -l / 2 - c },
    ...vt(s / 2, -l / 2, c, 20, -90, 0),
    { x: -s / 2 - c, y: -c },
    ...vt(s / 2 + c * 2, -c, c, 20, -180, -270),
    ...vt(s / 2 + c * 2, c, c, 20, -90, -180),
    { x: -s / 2 - c, y: l / 2 },
    ...vt(s / 2, l / 2, c, 20, 0, 90),
    { x: -s / 2, y: l / 2 + c },
    { x: s / 2 - c - c / 2, y: l / 2 + c },
    ...vt(-s / 2 + c + c / 2, -l / 2, c, 20, -90, -180),
    { x: s / 2 - c / 2, y: c },
    ...vt(-s / 2 - c / 2, -c, c, 20, 0, 90),
    ...vt(-s / 2 - c / 2, c, c, 20, -90, 0),
    { x: s / 2 - c / 2, y: -c },
    ...vt(-s / 2 + c + c / 2, l / 2, c, 30, -180, -270)
  ], g = W.svg(n), m = H(t, { fill: "none" });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const y = tt(u).replace("Z", ""), b = g.path(y, m), k = tt(f).replace("Z", ""), _ = g.path(k, m), C = tt(d), v = g.path(C, { ...m }), D = n.insert("g", ":first-child");
  return D.insert(() => v, ":first-child").attr("stroke-opacity", 0), D.insert(() => b, ":first-child"), D.insert(() => _, ":first-child"), D.attr("class", "text"), h && t.look !== "handDrawn" && D.selectAll("path").attr("style", h), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(${c - c / 4}, 0)`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, D), t.intersect = function(R) {
    return N.polygon(t, d, R);
  }, n;
}
p(rd, "curlyBraces");
async function id(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = 80, s = 20, l = Math.max(o, (a.width + (t.padding ?? 0) * 2) * 1.25, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = W.svg(n), d = H(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = l, m = c, x = g - h, y = m / 4, b = [
    { x, y: 0 },
    { x: y, y: 0 },
    { x: 0, y: m / 2 },
    { x: y, y: m },
    { x, y: m },
    ...li(-x, -m / 2, h, 50, 270, 90)
  ], w = tt(b), k = f.path(w, d), _ = n.insert(() => k, ":first-child");
  return _.attr("class", "basic label-container"), u && t.look !== "handDrawn" && _.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && _.selectChildren("path").attr("style", i), _.attr("transform", `translate(${-l / 2}, ${-c / 2})`), j(t, _), t.intersect = function(C) {
    return N.polygon(t, b, C);
  }, n;
}
p(id, "curvedTrapezoid");
var L_ = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createCylinderPathD"), M_ = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`
].join(" "), "createOuterCylinderPathD"), $_ = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function nd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + t.padding, t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + t.padding, t.height ?? 0);
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const d = W.svg(n), g = M_(0, 0, s, h, l, c), m = $_(0, c, s, h, l, c), x = d.path(g, H(t, {})), y = d.path(m, H(t, { fill: "none" }));
    u = n.insert(() => y, ":first-child"), u = n.insert(() => x, ":first-child"), u.attr("class", "basic label-container"), f && u.attr("style", f);
  } else {
    const d = L_(0, 0, s, h, l, c);
    u = n.insert("path", ":first-child").attr("d", d).attr("class", "basic label-container").attr("style", Mt(f)).attr("style", i);
  }
  return u.attr("label-offset-y", c), u.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), j(t, u), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + (t.padding ?? 0) / 1.5 - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(d) {
    const g = N.rect(t, d), m = g.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(m) < (t.width ?? 0) / 2 || Math.abs(m) == (t.width ?? 0) / 2 && Math.abs(g.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let x = c * c * (1 - m * m / (l * l));
      x > 0 && (x = Math.sqrt(x)), x = c - x, d.y - (t.y ?? 0) > 0 && (x = -x), g.y += x;
    }
    return g;
  }, n;
}
p(nd, "cylinder");
async function ad(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = a.width + t.padding, l = a.height + t.padding, c = l * 0.2, h = -s / 2, u = -l / 2 - c / 2, { cssStyles: f } = t, d = W.svg(n), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u + c },
    { x: -h, y: u + c },
    { x: -h, y: -u },
    { x: h, y: -u },
    { x: h, y: u },
    { x: -h, y: u },
    { x: -h, y: u + c }
  ], x = d.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), y = n.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), f && t.look !== "handDrawn" && y.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${h + (t.padding ?? 0) / 2 - (a.x - (a.left ?? 0))}, ${u + c + (t.padding ?? 0) / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, y), t.intersect = function(b) {
    return N.rect(t, b);
  }, n;
}
p(ad, "dividedRectangle");
async function sd(e, t) {
  var f, d;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o } = await Z(e, t, V(t)), l = a.width / 2 + o + 5, c = a.width / 2 + o;
  let h;
  const { cssStyles: u } = t;
  if (t.look === "handDrawn") {
    const g = W.svg(n), m = H(t, { roughness: 0.2, strokeWidth: 2.5 }), x = H(t, { roughness: 0.2, strokeWidth: 1.5 }), y = g.circle(0, 0, l * 2, m), b = g.circle(0, 0, c * 2, x);
    h = n.insert("g", ":first-child"), h.attr("class", Mt(t.cssClasses)).attr("style", Mt(u)), (f = h.node()) == null || f.appendChild(y), (d = h.node()) == null || d.appendChild(b);
  } else {
    h = n.insert("g", ":first-child");
    const g = h.insert("circle", ":first-child"), m = h.insert("circle");
    h.attr("class", "basic label-container").attr("style", i), g.attr("class", "outer-circle").attr("style", i).attr("r", l).attr("cx", 0).attr("cy", 0), m.attr("class", "inner-circle").attr("style", i).attr("r", c).attr("cx", 0).attr("cy", 0);
  }
  return j(t, h), t.intersect = function(g) {
    return F.info("DoubleCircle intersect", t, l, g), N.circle(t, l, g);
  }, n;
}
p(sd, "doublecircle");
function od(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.label = "", t.labelStyle = i;
  const a = e.insert("g").attr("class", V(t)).attr("id", t.domId ?? t.id), o = 7, { cssStyles: s } = t, l = W.svg(a), { nodeBorder: c } = r, h = H(t, { fillStyle: "solid" });
  t.look !== "handDrawn" && (h.roughness = 0);
  const u = l.circle(0, 0, o * 2, h), f = a.insert(() => u, ":first-child");
  return f.selectAll("path").attr("style", `fill: ${c} !important;`), s && s.length > 0 && t.look !== "handDrawn" && f.selectAll("path").attr("style", s), n && t.look !== "handDrawn" && f.selectAll("path").attr("style", n), j(t, f), t.intersect = function(d) {
    return F.info("filledCircle intersect", t, { radius: o, point: d }), N.circle(t, o, d);
  }, a;
}
p(od, "filledCircle");
async function ld(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = a.width + (t.padding ?? 0), l = s + a.height, c = s + a.height, h = [
    { x: 0, y: -l },
    { x: c, y: -l },
    { x: c / 2, y: 0 }
  ], { cssStyles: u } = t, f = W.svg(n), d = H(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = tt(h), m = f.path(g, d), x = n.insert(() => m, ":first-child").attr("transform", `translate(${-l / 2}, ${l / 2})`);
  return u && t.look !== "handDrawn" && x.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), t.width = s, t.height = l, j(t, x), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${-l / 2 + (t.padding ?? 0) / 2 + (a.y - (a.top ?? 0))})`
  ), t.intersect = function(y) {
    return F.info("Triangle intersect", t, h, y), N.polygon(t, h, y);
  }, n;
}
p(ld, "flippedTriangle");
function cd(e, t, { dir: r, config: { state: i, themeVariables: n } }) {
  const { nodeStyles: a } = Y(t);
  t.label = "";
  const o = e.insert("g").attr("class", V(t)).attr("id", t.domId ?? t.id), { cssStyles: s } = t;
  let l = Math.max(70, (t == null ? void 0 : t.width) ?? 0), c = Math.max(10, (t == null ? void 0 : t.height) ?? 0);
  r === "LR" && (l = Math.max(10, (t == null ? void 0 : t.width) ?? 0), c = Math.max(70, (t == null ? void 0 : t.height) ?? 0));
  const h = -1 * l / 2, u = -1 * c / 2, f = W.svg(o), d = H(t, {
    stroke: n.lineColor,
    fill: n.lineColor
  });
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = f.rectangle(h, u, l, c, d), m = o.insert(() => g, ":first-child");
  s && t.look !== "handDrawn" && m.selectAll("path").attr("style", s), a && t.look !== "handDrawn" && m.selectAll("path").attr("style", a), j(t, m);
  const x = (i == null ? void 0 : i.padding) ?? 0;
  return t.width && t.height && (t.width += x / 2 || 0, t.height += x / 2 || 0), t.intersect = function(y) {
    return N.rect(t, y);
  }, o;
}
p(cd, "forkJoin");
async function hd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const n = 80, a = 50, { shapeSvg: o, bbox: s } = await Z(e, t, V(t)), l = Math.max(n, s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a, s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = c / 2, { cssStyles: u } = t, f = W.svg(o), d = H(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = [
    { x: -l / 2, y: -c / 2 },
    { x: l / 2 - h, y: -c / 2 },
    ...li(-l / 2 + h, 0, h, 50, 90, 270),
    { x: l / 2 - h, y: c / 2 },
    { x: -l / 2, y: c / 2 }
  ], m = tt(g), x = f.path(m, d), y = o.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), j(t, y), t.intersect = function(b) {
    return F.info("Pill intersect", t, { radius: h, point: b }), N.polygon(t, g, b);
  }, o;
}
p(hd, "halfRoundedRectangle");
async function ud(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = a.height + (t.padding ?? 0), s = a.width + (t.padding ?? 0) * 2.5, { cssStyles: l } = t, c = W.svg(n), h = H(t, {});
  t.look !== "handDrawn" && (h.roughness = 0, h.fillStyle = "solid");
  let u = s / 2;
  const f = u / 6;
  u = u + f;
  const d = o / 2, g = d / 2, m = u - g, x = [
    { x: -m, y: -d },
    { x: 0, y: -d },
    { x: m, y: -d },
    { x: u, y: 0 },
    { x: m, y: d },
    { x: 0, y: d },
    { x: -m, y: d },
    { x: -u, y: 0 }
  ], y = tt(x), b = c.path(y, h), w = n.insert(() => b, ":first-child");
  return w.attr("class", "basic label-container"), l && t.look !== "handDrawn" && w.selectChildren("path").attr("style", l), i && t.look !== "handDrawn" && w.selectChildren("path").attr("style", i), t.width = s, t.height = o, j(t, w), t.intersect = function(k) {
    return N.polygon(t, x, k);
  }, n;
}
p(ud, "hexagon");
async function fd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.label = "", t.labelStyle = r;
  const { shapeSvg: n } = await Z(e, t, V(t)), a = Math.max(30, (t == null ? void 0 : t.width) ?? 0), o = Math.max(30, (t == null ? void 0 : t.height) ?? 0), { cssStyles: s } = t, l = W.svg(n), c = H(t, {});
  t.look !== "handDrawn" && (c.roughness = 0, c.fillStyle = "solid");
  const h = [
    { x: 0, y: 0 },
    { x: a, y: 0 },
    { x: 0, y: o },
    { x: a, y: o }
  ], u = tt(h), f = l.path(u, c), d = n.insert(() => f, ":first-child");
  return d.attr("class", "basic label-container"), s && t.look !== "handDrawn" && d.selectChildren("path").attr("style", s), i && t.look !== "handDrawn" && d.selectChildren("path").attr("style", i), d.attr("transform", `translate(${-a / 2}, ${-o / 2})`), j(t, d), t.intersect = function(g) {
    return F.info("Pill intersect", t, { points: h }), N.polygon(t, h, g);
  }, n;
}
p(fd, "hourglass");
async function dd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await Z(e, t, "icon-shape default"), f = t.pos === "t", d = s, g = s, { nodeBorder: m } = r, { stylesMap: x } = Sr(t), y = -g / 2, b = -d / 2, w = t.label ? 8 : 0, k = W.svg(c), _ = H(t, { stroke: "none", fill: "none" });
  t.look !== "handDrawn" && (_.roughness = 0, _.fillStyle = "solid");
  const C = k.rectangle(y, b, g, d, _), v = Math.max(g, h.width), D = d + h.height + w, R = k.rectangle(-v / 2, -D / 2, v, D, {
    ..._,
    fill: "transparent",
    stroke: "none"
  }), O = c.insert(() => C, ":first-child"), A = c.insert(() => R);
  if (t.icon) {
    const I = c.append("g");
    I.html(
      `<g>${await bi(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const E = I.node().getBBox(), B = E.width, L = E.height, T = E.x, $ = E.y;
    I.attr(
      "transform",
      `translate(${-B / 2 - T},${f ? h.height / 2 + w / 2 - L / 2 - $ : -h.height / 2 - w / 2 - L / 2 - $})`
    ), I.attr("style", `color: ${x.get("stroke") ?? m};`);
  }
  return u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${f ? -D / 2 : D / 2 - h.height})`
  ), O.attr(
    "transform",
    `translate(0,${f ? h.height / 2 + w / 2 : -h.height / 2 - w / 2})`
  ), j(t, A), t.intersect = function(I) {
    if (F.info("iconSquare intersect", t, I), !t.label)
      return N.rect(t, I);
    const E = t.x ?? 0, B = t.y ?? 0, L = t.height ?? 0;
    let T = [];
    return f ? T = [
      { x: E - h.width / 2, y: B - L / 2 },
      { x: E + h.width / 2, y: B - L / 2 },
      { x: E + h.width / 2, y: B - L / 2 + h.height + w },
      { x: E + g / 2, y: B - L / 2 + h.height + w },
      { x: E + g / 2, y: B + L / 2 },
      { x: E - g / 2, y: B + L / 2 },
      { x: E - g / 2, y: B - L / 2 + h.height + w },
      { x: E - h.width / 2, y: B - L / 2 + h.height + w }
    ] : T = [
      { x: E - g / 2, y: B - L / 2 },
      { x: E + g / 2, y: B - L / 2 },
      { x: E + g / 2, y: B - L / 2 + d },
      { x: E + h.width / 2, y: B - L / 2 + d },
      { x: E + h.width / 2 / 2, y: B + L / 2 },
      { x: E - h.width / 2, y: B + L / 2 },
      { x: E - h.width / 2, y: B - L / 2 + d },
      { x: E - g / 2, y: B - L / 2 + d }
    ], N.polygon(t, T, I);
  }, c;
}
p(dd, "icon");
async function pd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, label: u } = await Z(e, t, "icon-shape default"), f = 20, d = t.label ? 8 : 0, g = t.pos === "t", { nodeBorder: m, mainBkg: x } = r, { stylesMap: y } = Sr(t), b = W.svg(c), w = H(t, {});
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const k = y.get("fill");
  w.stroke = k ?? x;
  const _ = c.append("g");
  t.icon && _.html(
    `<g>${await bi(t.icon, {
      height: s,
      width: s,
      fallbackPrefix: ""
    })}</g>`
  );
  const C = _.node().getBBox(), v = C.width, D = C.height, R = C.x, O = C.y, A = Math.max(v, D) * Math.SQRT2 + f * 2, I = b.circle(0, 0, A, w), E = Math.max(A, h.width), B = A + h.height + d, L = b.rectangle(-E / 2, -B / 2, E, B, {
    ...w,
    fill: "transparent",
    stroke: "none"
  }), T = c.insert(() => I, ":first-child"), $ = c.insert(() => L);
  return _.attr(
    "transform",
    `translate(${-v / 2 - R},${g ? h.height / 2 + d / 2 - D / 2 - O : -h.height / 2 - d / 2 - D / 2 - O})`
  ), _.attr("style", `color: ${y.get("stroke") ?? m};`), u.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${g ? -B / 2 : B / 2 - h.height})`
  ), T.attr(
    "transform",
    `translate(0,${g ? h.height / 2 + d / 2 : -h.height / 2 - d / 2})`
  ), j(t, $), t.intersect = function(M) {
    return F.info("iconSquare intersect", t, M), N.rect(t, M);
  }, c;
}
p(pd, "iconCircle");
async function gd(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await Z(
    e,
    t,
    "icon-shape default"
  ), d = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: x, mainBkg: y } = r, { stylesMap: b } = Sr(t), w = -m / 2, k = -g / 2, _ = t.label ? 8 : 0, C = W.svg(c), v = H(t, {});
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const D = b.get("fill");
  v.stroke = D ?? y;
  const R = C.path(Le(w, k, m, g, 5), v), O = Math.max(m, h.width), A = g + h.height + _, I = C.rectangle(-O / 2, -A / 2, O, A, {
    ...v,
    fill: "transparent",
    stroke: "none"
  }), E = c.insert(() => R, ":first-child").attr("class", "icon-shape2"), B = c.insert(() => I);
  if (t.icon) {
    const L = c.append("g");
    L.html(
      `<g>${await bi(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const T = L.node().getBBox(), $ = T.width, M = T.height, z = T.x, U = T.y;
    L.attr(
      "transform",
      `translate(${-$ / 2 - z},${d ? h.height / 2 + _ / 2 - M / 2 - U : -h.height / 2 - _ / 2 - M / 2 - U})`
    ), L.attr("style", `color: ${b.get("stroke") ?? x};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${d ? -A / 2 : A / 2 - h.height})`
  ), E.attr(
    "transform",
    `translate(0,${d ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), j(t, B), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return N.rect(t, L);
    const T = t.x ?? 0, $ = t.y ?? 0, M = t.height ?? 0;
    let z = [];
    return d ? z = [
      { x: T - h.width / 2, y: $ - M / 2 },
      { x: T + h.width / 2, y: $ - M / 2 },
      { x: T + h.width / 2, y: $ - M / 2 + h.height + _ },
      { x: T + m / 2, y: $ - M / 2 + h.height + _ },
      { x: T + m / 2, y: $ + M / 2 },
      { x: T - m / 2, y: $ + M / 2 },
      { x: T - m / 2, y: $ - M / 2 + h.height + _ },
      { x: T - h.width / 2, y: $ - M / 2 + h.height + _ }
    ] : z = [
      { x: T - m / 2, y: $ - M / 2 },
      { x: T + m / 2, y: $ - M / 2 },
      { x: T + m / 2, y: $ - M / 2 + g },
      { x: T + h.width / 2, y: $ - M / 2 + g },
      { x: T + h.width / 2 / 2, y: $ + M / 2 },
      { x: T - h.width / 2, y: $ + M / 2 },
      { x: T - h.width / 2, y: $ - M / 2 + g },
      { x: T - m / 2, y: $ - M / 2 + g }
    ], N.polygon(t, z, L);
  }, c;
}
p(gd, "iconRounded");
async function md(e, t, { config: { themeVariables: r, flowchart: i } }) {
  const { labelStyles: n } = Y(t);
  t.labelStyle = n;
  const a = t.assetHeight ?? 48, o = t.assetWidth ?? 48, s = Math.max(a, o), l = i == null ? void 0 : i.wrappingWidth;
  t.width = Math.max(s, l ?? 0);
  const { shapeSvg: c, bbox: h, halfPadding: u, label: f } = await Z(
    e,
    t,
    "icon-shape default"
  ), d = t.pos === "t", g = s + u * 2, m = s + u * 2, { nodeBorder: x, mainBkg: y } = r, { stylesMap: b } = Sr(t), w = -m / 2, k = -g / 2, _ = t.label ? 8 : 0, C = W.svg(c), v = H(t, {});
  t.look !== "handDrawn" && (v.roughness = 0, v.fillStyle = "solid");
  const D = b.get("fill");
  v.stroke = D ?? y;
  const R = C.path(Le(w, k, m, g, 0.1), v), O = Math.max(m, h.width), A = g + h.height + _, I = C.rectangle(-O / 2, -A / 2, O, A, {
    ...v,
    fill: "transparent",
    stroke: "none"
  }), E = c.insert(() => R, ":first-child"), B = c.insert(() => I);
  if (t.icon) {
    const L = c.append("g");
    L.html(
      `<g>${await bi(t.icon, {
        height: s,
        width: s,
        fallbackPrefix: ""
      })}</g>`
    );
    const T = L.node().getBBox(), $ = T.width, M = T.height, z = T.x, U = T.y;
    L.attr(
      "transform",
      `translate(${-$ / 2 - z},${d ? h.height / 2 + _ / 2 - M / 2 - U : -h.height / 2 - _ / 2 - M / 2 - U})`
    ), L.attr("style", `color: ${b.get("stroke") ?? x};`);
  }
  return f.attr(
    "transform",
    `translate(${-h.width / 2 - (h.x - (h.left ?? 0))},${d ? -A / 2 : A / 2 - h.height})`
  ), E.attr(
    "transform",
    `translate(0,${d ? h.height / 2 + _ / 2 : -h.height / 2 - _ / 2})`
  ), j(t, B), t.intersect = function(L) {
    if (F.info("iconSquare intersect", t, L), !t.label)
      return N.rect(t, L);
    const T = t.x ?? 0, $ = t.y ?? 0, M = t.height ?? 0;
    let z = [];
    return d ? z = [
      { x: T - h.width / 2, y: $ - M / 2 },
      { x: T + h.width / 2, y: $ - M / 2 },
      { x: T + h.width / 2, y: $ - M / 2 + h.height + _ },
      { x: T + m / 2, y: $ - M / 2 + h.height + _ },
      { x: T + m / 2, y: $ + M / 2 },
      { x: T - m / 2, y: $ + M / 2 },
      { x: T - m / 2, y: $ - M / 2 + h.height + _ },
      { x: T - h.width / 2, y: $ - M / 2 + h.height + _ }
    ] : z = [
      { x: T - m / 2, y: $ - M / 2 },
      { x: T + m / 2, y: $ - M / 2 },
      { x: T + m / 2, y: $ - M / 2 + g },
      { x: T + h.width / 2, y: $ - M / 2 + g },
      { x: T + h.width / 2 / 2, y: $ + M / 2 },
      { x: T - h.width / 2, y: $ + M / 2 },
      { x: T - h.width / 2, y: $ - M / 2 + g },
      { x: T - m / 2, y: $ - M / 2 + g }
    ], N.polygon(t, z, L);
  }, c;
}
p(md, "iconSquare");
async function yd(e, t, { config: { flowchart: r } }) {
  const i = new Image();
  i.src = (t == null ? void 0 : t.img) ?? "", await i.decode();
  const n = Number(i.naturalWidth.toString().replace("px", "")), a = Number(i.naturalHeight.toString().replace("px", ""));
  t.imageAspectRatio = n / a;
  const { labelStyles: o } = Y(t);
  t.labelStyle = o;
  const s = r == null ? void 0 : r.wrappingWidth;
  t.defaultWidth = r == null ? void 0 : r.wrappingWidth;
  const l = Math.max(
    t.label ? s ?? 0 : 0,
    (t == null ? void 0 : t.assetWidth) ?? n
  ), c = t.constraint === "on" && t != null && t.assetHeight ? t.assetHeight * t.imageAspectRatio : l, h = t.constraint === "on" ? c / t.imageAspectRatio : (t == null ? void 0 : t.assetHeight) ?? a;
  t.width = Math.max(c, s ?? 0);
  const { shapeSvg: u, bbox: f, label: d } = await Z(e, t, "image-shape default"), g = t.pos === "t", m = -c / 2, x = -h / 2, y = t.label ? 8 : 0, b = W.svg(u), w = H(t, {});
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const k = b.rectangle(m, x, c, h, w), _ = Math.max(c, f.width), C = h + f.height + y, v = b.rectangle(-_ / 2, -C / 2, _, C, {
    ...w,
    fill: "none",
    stroke: "none"
  }), D = u.insert(() => k, ":first-child"), R = u.insert(() => v);
  if (t.img) {
    const O = u.append("image");
    O.attr("href", t.img), O.attr("width", c), O.attr("height", h), O.attr("preserveAspectRatio", "none"), O.attr(
      "transform",
      `translate(${-c / 2},${g ? C / 2 - h : -C / 2})`
    );
  }
  return d.attr(
    "transform",
    `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${g ? -h / 2 - f.height / 2 - y / 2 : h / 2 - f.height / 2 + y / 2})`
  ), D.attr(
    "transform",
    `translate(0,${g ? f.height / 2 + y / 2 : -f.height / 2 - y / 2})`
  ), j(t, R), t.intersect = function(O) {
    if (F.info("iconSquare intersect", t, O), !t.label)
      return N.rect(t, O);
    const A = t.x ?? 0, I = t.y ?? 0, E = t.height ?? 0;
    let B = [];
    return g ? B = [
      { x: A - f.width / 2, y: I - E / 2 },
      { x: A + f.width / 2, y: I - E / 2 },
      { x: A + f.width / 2, y: I - E / 2 + f.height + y },
      { x: A + c / 2, y: I - E / 2 + f.height + y },
      { x: A + c / 2, y: I + E / 2 },
      { x: A - c / 2, y: I + E / 2 },
      { x: A - c / 2, y: I - E / 2 + f.height + y },
      { x: A - f.width / 2, y: I - E / 2 + f.height + y }
    ] : B = [
      { x: A - c / 2, y: I - E / 2 },
      { x: A + c / 2, y: I - E / 2 },
      { x: A + c / 2, y: I - E / 2 + h },
      { x: A + f.width / 2, y: I - E / 2 + h },
      { x: A + f.width / 2 / 2, y: I + E / 2 },
      { x: A - f.width / 2, y: I + E / 2 },
      { x: A - f.width / 2, y: I - E / 2 + h },
      { x: A - c / 2, y: I - E / 2 + h }
    ], N.polygon(t, B, O);
  }, u;
}
p(yd, "imageSquare");
async function xd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: -3 * s / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), d = tt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Me(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return N.polygon(t, l, u);
  }, n;
}
p(xd, "inv_trapezoid");
async function Vn(e, t, r) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i;
  const { shapeSvg: a, bbox: o } = await Z(e, t, V(t)), s = Math.max(o.width + r.labelPaddingX * 2, (t == null ? void 0 : t.width) || 0), l = Math.max(o.height + r.labelPaddingY * 2, (t == null ? void 0 : t.height) || 0), c = -s / 2, h = -l / 2;
  let u, { rx: f, ry: d } = t;
  const { cssStyles: g } = t;
  if (r != null && r.rx && r.ry && (f = r.rx, d = r.ry), t.look === "handDrawn") {
    const m = W.svg(a), x = H(t, {}), y = f || d ? m.path(Le(c, h, s, l, f || 0), x) : m.rectangle(c, h, s, l, x);
    u = a.insert(() => y, ":first-child"), u.attr("class", "basic label-container").attr("style", Mt(g));
  } else
    u = a.insert("rect", ":first-child"), u.attr("class", "basic label-container").attr("style", n).attr("rx", Mt(f)).attr("ry", Mt(d)).attr("x", c).attr("y", h).attr("width", s).attr("height", l);
  return j(t, u), t.calcIntersect = function(m, x) {
    return N.rect(m, x);
  }, t.intersect = function(m) {
    return N.rect(t, m);
  }, a;
}
p(Vn, "drawRect");
async function bd(e, t) {
  const { shapeSvg: r, bbox: i, label: n } = await Z(e, t, "label"), a = r.insert("rect", ":first-child");
  return a.attr("width", 0.1).attr("height", 0.1), r.attr("class", "label edgeLabel"), n.attr(
    "transform",
    `translate(${-(i.width / 2) - (i.x - (i.left ?? 0))}, ${-(i.height / 2) - (i.y - (i.top ?? 0))})`
  ), j(t, a), t.intersect = function(l) {
    return N.rect(t, l);
  }, r;
}
p(bd, "labelRect");
async function Cd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: 0, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: -(3 * s) / 6, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), d = tt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Me(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return N.polygon(t, l, u);
  }, n;
}
p(Cd, "lean_left");
async function wd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), l = [
    { x: -3 * s / 6, y: 0 },
    { x: o, y: 0 },
    { x: o + 3 * s / 6, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), d = tt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Me(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return N.polygon(t, l, u);
  }, n;
}
p(wd, "lean_right");
function _d(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.label = "", t.labelStyle = r;
  const n = e.insert("g").attr("class", V(t)).attr("id", t.domId ?? t.id), { cssStyles: a } = t, o = Math.max(35, (t == null ? void 0 : t.width) ?? 0), s = Math.max(35, (t == null ? void 0 : t.height) ?? 0), l = 7, c = [
    { x: o, y: 0 },
    { x: 0, y: s + l / 2 },
    { x: o - 2 * l, y: s + l / 2 },
    { x: 0, y: 2 * s },
    { x: o, y: s - l / 2 },
    { x: 2 * l, y: s - l / 2 }
  ], h = W.svg(n), u = H(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = tt(c), d = h.path(f, u), g = n.insert(() => d, ":first-child");
  return a && t.look !== "handDrawn" && g.selectAll("path").attr("style", a), i && t.look !== "handDrawn" && g.selectAll("path").attr("style", i), g.attr("transform", `translate(-${o / 2},${-s})`), j(t, g), t.intersect = function(m) {
    return F.info("lightningBolt intersect", t, m), N.polygon(t, c, m);
  }, n;
}
p(_d, "lightningBolt");
var A_ = /* @__PURE__ */ p((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createCylinderPathD"), F_ = /* @__PURE__ */ p((e, t, r, i, n, a, o) => [
  `M${e},${t + a}`,
  `M${e + r},${t + a}`,
  `a${n},${a} 0,0,0 ${-r},0`,
  `l0,${i}`,
  `a${n},${a} 0,0,0 ${r},0`,
  `l0,${-i}`,
  `M${e},${t + a + o}`,
  `a${n},${a} 0,0,0 ${r},0`
].join(" "), "createOuterCylinderPathD"), E_ = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e - r / 2},${-i / 2}`, `a${n},${a} 0,0,0 ${r},0`].join(" "), "createInnerCylinderPathD");
async function vd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0), t.width ?? 0), l = s / 2, c = l / (2.5 + s / 50), h = Math.max(a.height + c + (t.padding ?? 0), t.height ?? 0), u = h * 0.1;
  let f;
  const { cssStyles: d } = t;
  if (t.look === "handDrawn") {
    const g = W.svg(n), m = F_(0, 0, s, h, l, c, u), x = E_(0, c, s, h, l, c), y = H(t, {}), b = g.path(m, y), w = g.path(x, y);
    n.insert(() => w, ":first-child").attr("class", "line"), f = n.insert(() => b, ":first-child"), f.attr("class", "basic label-container"), d && f.attr("style", d);
  } else {
    const g = A_(0, 0, s, h, l, c, u);
    f = n.insert("path", ":first-child").attr("d", g).attr("class", "basic label-container").attr("style", Mt(d)).attr("style", i);
  }
  return f.attr("label-offset-y", c), f.attr("transform", `translate(${-s / 2}, ${-(h / 2 + c)})`), j(t, f), o.attr(
    "transform",
    `translate(${-(a.width / 2) - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), t.intersect = function(g) {
    const m = N.rect(t, g), x = m.x - (t.x ?? 0);
    if (l != 0 && (Math.abs(x) < (t.width ?? 0) / 2 || Math.abs(x) == (t.width ?? 0) / 2 && Math.abs(m.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - c)) {
      let y = c * c * (1 - x * x / (l * l));
      y > 0 && (y = Math.sqrt(y)), y = c - y, g.y - (t.y ?? 0) > 0 && (y = -y), m.y += y;
    }
    return m;
  }, n;
}
p(vd, "linedCylinder");
async function kd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, { cssStyles: u } = t, f = W.svg(n), d = H(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = [
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: h / 2 },
    ...Se(
      -s / 2 - s / 2 * 0.1,
      h / 2,
      s / 2 + s / 2 * 0.1,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -h / 2 },
    { x: -s / 2, y: -h / 2 },
    { x: -s / 2, y: h / 2 * 1.1 },
    { x: -s / 2, y: -h / 2 }
  ], m = f.polygon(
    g.map((y) => [y.x, y.y]),
    d
  ), x = n.insert(() => m, ":first-child");
  return x.attr("class", "basic label-container"), u && t.look !== "handDrawn" && x.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && x.selectAll("path").attr("style", i), x.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) + s / 2 * 0.1 / 2 - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, x), t.intersect = function(y) {
    return N.polygon(t, g, y);
  }, n;
}
p(kd, "linedWaveEdgedRect");
async function Sd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, d = W.svg(n), g = H(t, {}), m = [
    { x: h - c, y: u + c },
    { x: h - c, y: u + l + c },
    { x: h + s - c, y: u + l + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u + l - c },
    { x: h + s + c, y: u + l - c },
    { x: h + s + c, y: u - c },
    { x: h + c, y: u - c },
    { x: h + c, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], x = [
    { x: h, y: u + c },
    { x: h + s - c, y: u + c },
    { x: h + s - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u },
    { x: h, y: u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = tt(m), b = d.path(y, g), w = tt(x), k = d.path(w, { ...g, fill: "none" }), _ = n.insert(() => k, ":first-child");
  return _.insert(() => b, ":first-child"), _.attr("class", "basic label-container"), f && t.look !== "handDrawn" && _.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && _.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) - c - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c - (a.y - (a.top ?? 0))})`
  ), j(t, _), t.intersect = function(C) {
    return N.polygon(t, m, C);
  }, n;
}
p(Sd, "multiRect");
async function Td(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = l + c, u = -s / 2, f = -h / 2, d = 5, { cssStyles: g } = t, m = Se(
    u - d,
    f + h + d,
    u + s - d,
    f + h + d,
    c,
    0.8
  ), x = m == null ? void 0 : m[m.length - 1], y = [
    { x: u - d, y: f + d },
    { x: u - d, y: f + h + d },
    ...m,
    { x: u + s - d, y: x.y - d },
    { x: u + s, y: x.y - d },
    { x: u + s, y: x.y - 2 * d },
    { x: u + s + d, y: x.y - 2 * d },
    { x: u + s + d, y: f - d },
    { x: u + d, y: f - d },
    { x: u + d, y: f },
    { x: u, y: f },
    { x: u, y: f + d }
  ], b = [
    { x: u, y: f + d },
    { x: u + s - d, y: f + d },
    { x: u + s - d, y: x.y - d },
    { x: u + s, y: x.y - d },
    { x: u + s, y: f },
    { x: u, y: f }
  ], w = W.svg(n), k = H(t, {});
  t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid");
  const _ = tt(y), C = w.path(_, k), v = tt(b), D = w.path(v, k), R = n.insert(() => C, ":first-child");
  return R.insert(() => D), R.attr("class", "basic label-container"), g && t.look !== "handDrawn" && R.selectAll("path").attr("style", g), i && t.look !== "handDrawn" && R.selectAll("path").attr("style", i), R.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - d - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + d - c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, R), t.intersect = function(O) {
    return N.polygon(t, y, O);
  }, n;
}
p(Td, "multiWaveEdgedRectangle");
async function Bd(e, t, { config: { themeVariables: r } }) {
  var b;
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i, t.useHtmlLabels || ((b = Bt().flowchart) == null ? void 0 : b.htmlLabels) !== !1 || (t.centerLabel = !0);
  const { shapeSvg: o, bbox: s, label: l } = await Z(e, t, V(t)), c = Math.max(s.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), h = Math.max(s.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), u = -c / 2, f = -h / 2, { cssStyles: d } = t, g = W.svg(o), m = H(t, {
    fill: r.noteBkgColor,
    stroke: r.noteBorderColor
  });
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = g.rectangle(u, f, c, h, m), y = o.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), d && t.look !== "handDrawn" && y.selectAll("path").attr("style", d), n && t.look !== "handDrawn" && y.selectAll("path").attr("style", n), l.attr(
    "transform",
    `translate(${-s.width / 2 - (s.x - (s.left ?? 0))}, ${-(s.height / 2) - (s.y - (s.top ?? 0))})`
  ), j(t, y), t.intersect = function(w) {
    return N.rect(t, w);
  }, o;
}
p(Bd, "note");
var D_ = /* @__PURE__ */ p((e, t, r) => [
  `M${e + r / 2},${t}`,
  `L${e + r},${t - r / 2}`,
  `L${e + r / 2},${t - r}`,
  `L${e},${t - r / 2}`,
  "Z"
].join(" "), "createDecisionBoxPathD");
async function Ld(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = a.width + t.padding, s = a.height + t.padding, l = o + s, c = 0.5, h = [
    { x: l / 2, y: 0 },
    { x: l, y: -l / 2 },
    { x: l / 2, y: -l },
    { x: 0, y: -l / 2 }
  ];
  let u;
  const { cssStyles: f } = t;
  if (t.look === "handDrawn") {
    const d = W.svg(n), g = H(t, {}), m = D_(0, 0, l), x = d.path(m, g);
    u = n.insert(() => x, ":first-child").attr("transform", `translate(${-l / 2 + c}, ${l / 2})`), f && u.attr("style", f);
  } else
    u = Me(n, l, l, h), u.attr("transform", `translate(${-l / 2 + c}, ${l / 2})`);
  return i && u.attr("style", i), j(t, u), t.calcIntersect = function(d, g) {
    const m = d.width, x = [
      { x: m / 2, y: 0 },
      { x: m, y: -m / 2 },
      { x: m / 2, y: -m },
      { x: 0, y: -m / 2 }
    ], y = N.polygon(d, x, g);
    return { x: y.x - 0.5, y: y.y - 0.5 };
  }, t.intersect = function(d) {
    return this.calcIntersect(t, d);
  }, n;
}
p(Ld, "question");
async function Md(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0), (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0), (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, u = h / 2, f = [
    { x: c + u, y: h },
    { x: c, y: 0 },
    { x: c + u, y: -h },
    { x: -c, y: -h },
    { x: -c, y: h }
  ], { cssStyles: d } = t, g = W.svg(n), m = H(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = tt(f), y = g.path(x, m), b = n.insert(() => y, ":first-child");
  return b.attr("class", "basic label-container"), d && t.look !== "handDrawn" && b.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), b.attr("transform", `translate(${-u / 2},0)`), o.attr(
    "transform",
    `translate(${-u / 2 - a.width / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), j(t, b), t.intersect = function(w) {
    return N.polygon(t, f, w);
  }, n;
}
p(Md, "rect_left_inv_arrow");
async function $d(e, t) {
  var D, R;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  let n;
  t.cssClasses ? n = "node " + t.cssClasses : n = "node default";
  const a = e.insert("g").attr("class", n).attr("id", t.domId || t.id), o = a.insert("g"), s = a.insert("g").attr("class", "label").attr("style", i), l = t.description, c = t.label, h = s.node().appendChild(await Pe(c, t.labelStyle, !0, !0));
  let u = { width: 0, height: 0 };
  if (Ct((R = (D = nt()) == null ? void 0 : D.flowchart) == null ? void 0 : R.htmlLabels)) {
    const O = h.children[0], A = rt(h);
    u = O.getBoundingClientRect(), A.attr("width", u.width), A.attr("height", u.height);
  }
  F.info("Text 2", l);
  const f = l || [], d = h.getBBox(), g = s.node().appendChild(
    await Pe(
      f.join ? f.join("<br/>") : f,
      t.labelStyle,
      !0,
      !0
    )
  ), m = g.children[0], x = rt(g);
  u = m.getBoundingClientRect(), x.attr("width", u.width), x.attr("height", u.height);
  const y = (t.padding || 0) / 2;
  rt(g).attr(
    "transform",
    "translate( " + (u.width > d.width ? 0 : (d.width - u.width) / 2) + ", " + (d.height + y + 5) + ")"
  ), rt(h).attr(
    "transform",
    "translate( " + (u.width < d.width ? 0 : -(d.width - u.width) / 2) + ", 0)"
  ), u = s.node().getBBox(), s.attr(
    "transform",
    "translate(" + -u.width / 2 + ", " + (-u.height / 2 - y + 3) + ")"
  );
  const b = u.width + (t.padding || 0), w = u.height + (t.padding || 0), k = -u.width / 2 - y, _ = -u.height / 2 - y;
  let C, v;
  if (t.look === "handDrawn") {
    const O = W.svg(a), A = H(t, {}), I = O.path(
      Le(k, _, b, w, t.rx || 0),
      A
    ), E = O.line(
      -u.width / 2 - y,
      -u.height / 2 - y + d.height + y,
      u.width / 2 + y,
      -u.height / 2 - y + d.height + y,
      A
    );
    v = a.insert(() => (F.debug("Rough node insert CXC", I), E), ":first-child"), C = a.insert(() => (F.debug("Rough node insert CXC", I), I), ":first-child");
  } else
    C = o.insert("rect", ":first-child"), v = o.insert("line"), C.attr("class", "outer title-state").attr("style", i).attr("x", -u.width / 2 - y).attr("y", -u.height / 2 - y).attr("width", u.width + (t.padding || 0)).attr("height", u.height + (t.padding || 0)), v.attr("class", "divider").attr("x1", -u.width / 2 - y).attr("x2", u.width / 2 + y).attr("y1", -u.height / 2 - y + d.height + y).attr("y2", -u.height / 2 - y + d.height + y);
  return j(t, C), t.intersect = function(O) {
    return N.rect(t, O);
  }, a;
}
p($d, "rectWithTitle");
function Hr(e, t, r, i, n, a, o) {
  const l = (e + r) / 2, c = (t + i) / 2, h = Math.atan2(i - t, r - e), u = (r - e) / 2, f = (i - t) / 2, d = u / n, g = f / a, m = Math.sqrt(d ** 2 + g ** 2);
  if (m > 1)
    throw new Error("The given radii are too small to create an arc between the points.");
  const x = Math.sqrt(1 - m ** 2), y = l + x * a * Math.sin(h) * (o ? -1 : 1), b = c - x * n * Math.cos(h) * (o ? -1 : 1), w = Math.atan2((t - b) / a, (e - y) / n);
  let _ = Math.atan2((i - b) / a, (r - y) / n) - w;
  o && _ < 0 && (_ += 2 * Math.PI), !o && _ > 0 && (_ -= 2 * Math.PI);
  const C = [];
  for (let v = 0; v < 20; v++) {
    const D = v / 19, R = w + D * _, O = y + n * Math.cos(R), A = b + a * Math.sin(R);
    C.push({ x: O, y: A });
  }
  return C;
}
p(Hr, "generateArcPoints");
async function Ad(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = (t == null ? void 0 : t.padding) ?? 0, s = (t == null ? void 0 : t.padding) ?? 0, l = (t != null && t.width ? t == null ? void 0 : t.width : a.width) + o * 2, c = (t != null && t.height ? t == null ? void 0 : t.height : a.height) + s * 2, h = t.radius || 5, u = t.taper || 5, { cssStyles: f } = t, d = W.svg(n), g = H(t, {});
  t.stroke && (g.stroke = t.stroke), t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    // Top edge (left to right)
    { x: -l / 2 + u, y: -c / 2 },
    // Top-left corner start (1)
    { x: l / 2 - u, y: -c / 2 },
    // Top-right corner start (2)
    ...Hr(l / 2 - u, -c / 2, l / 2, -c / 2 + u, h, h, !0),
    // Top-left arc (2 to 3)
    // Right edge (top to bottom)
    { x: l / 2, y: -c / 2 + u },
    // Top-right taper point (3)
    { x: l / 2, y: c / 2 - u },
    // Bottom-right taper point (4)
    ...Hr(l / 2, c / 2 - u, l / 2 - u, c / 2, h, h, !0),
    // Top-left arc (4 to 5)
    // Bottom edge (right to left)
    { x: l / 2 - u, y: c / 2 },
    // Bottom-right corner start (5)
    { x: -l / 2 + u, y: c / 2 },
    // Bottom-left corner start (6)
    ...Hr(-l / 2 + u, c / 2, -l / 2, c / 2 - u, h, h, !0),
    // Top-left arc (4 to 5)
    // Left edge (bottom to top)
    { x: -l / 2, y: c / 2 - u },
    // Bottom-left taper point (7)
    { x: -l / 2, y: -c / 2 + u },
    // Top-left taper point (8)
    ...Hr(-l / 2, -c / 2 + u, -l / 2 + u, -c / 2, h, h, !0)
    // Top-left arc (4 to 5)
  ], x = tt(m), y = d.path(x, g), b = n.insert(() => y, ":first-child");
  return b.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && b.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && b.selectChildren("path").attr("style", i), j(t, b), t.intersect = function(w) {
    return N.polygon(t, m, w);
  }, n;
}
p(Ad, "roundedRect");
async function Fd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = (t == null ? void 0 : t.padding) ?? 0, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = -a.width / 2 - s, u = -a.height / 2 - s, { cssStyles: f } = t, d = W.svg(n), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = [
    { x: h, y: u },
    { x: h + l + 8, y: u },
    { x: h + l + 8, y: u + c },
    { x: h - 8, y: u + c },
    { x: h - 8, y: u },
    { x: h, y: u },
    { x: h, y: u + c }
  ], x = d.polygon(
    m.map((b) => [b.x, b.y]),
    g
  ), y = n.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container").attr("style", Mt(f)), i && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), f && t.look !== "handDrawn" && y.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-l / 2 + 4 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-c / 2 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), j(t, y), t.intersect = function(b) {
    return N.rect(t, b);
  }, n;
}
p(Fd, "shadedProcess");
async function Ed(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = -s / 2, h = -l / 2, { cssStyles: u } = t, f = W.svg(n), d = H(t, {});
  t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid");
  const g = [
    { x: c, y: h },
    { x: c, y: h + l },
    { x: c + s, y: h + l },
    { x: c + s, y: h - l / 2 }
  ], m = tt(g), x = f.path(m, d), y = n.insert(() => x, ":first-child");
  return y.attr("class", "basic label-container"), u && t.look !== "handDrawn" && y.selectChildren("path").attr("style", u), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), y.attr("transform", `translate(0, ${l / 4})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))}, ${-l / 4 + (t.padding ?? 0) - (a.y - (a.top ?? 0))})`
  ), j(t, y), t.intersect = function(b) {
    return N.polygon(t, g, b);
  }, n;
}
p(Ed, "slopedRect");
async function Dd(e, t) {
  const r = {
    rx: 0,
    ry: 0,
    labelPaddingX: t.labelPaddingX ?? ((t == null ? void 0 : t.padding) || 0) * 2,
    labelPaddingY: ((t == null ? void 0 : t.padding) || 0) * 1
  };
  return Vn(e, t, r);
}
p(Dd, "squareRect");
async function Od(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = a.height + t.padding, s = a.width + o / 4 + t.padding, l = o / 2, { cssStyles: c } = t, h = W.svg(n), u = H(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = [
    { x: -s / 2 + l, y: -o / 2 },
    { x: s / 2 - l, y: -o / 2 },
    ...li(-s / 2 + l, 0, l, 50, 90, 270),
    { x: s / 2 - l, y: o / 2 },
    ...li(s / 2 - l, 0, l, 50, 270, 450)
  ], d = tt(f), g = h.path(d, u), m = n.insert(() => g, ":first-child");
  return m.attr("class", "basic label-container outer-path"), c && t.look !== "handDrawn" && m.selectChildren("path").attr("style", c), i && t.look !== "handDrawn" && m.selectChildren("path").attr("style", i), j(t, m), t.intersect = function(x) {
    return N.polygon(t, f, x);
  }, n;
}
p(Od, "stadium");
async function Rd(e, t) {
  return Vn(e, t, {
    rx: 5,
    ry: 5
  });
}
p(Rd, "state");
function Id(e, t, { config: { themeVariables: r } }) {
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i;
  const { cssStyles: a } = t, { lineColor: o, stateBorder: s, nodeBorder: l } = r, c = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id), h = W.svg(c), u = H(t, {});
  t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid");
  const f = h.circle(0, 0, 14, {
    ...u,
    stroke: o,
    strokeWidth: 2
  }), d = s ?? l, g = h.circle(0, 0, 5, {
    ...u,
    fill: d,
    stroke: d,
    strokeWidth: 2,
    fillStyle: "solid"
  }), m = c.insert(() => f, ":first-child");
  return m.insert(() => g), a && m.selectAll("path").attr("style", a), n && m.selectAll("path").attr("style", n), j(t, m), t.intersect = function(x) {
    return N.circle(t, 7, x);
  }, c;
}
p(Id, "stateEnd");
function Pd(e, t, { config: { themeVariables: r } }) {
  const { lineColor: i } = r, n = e.insert("g").attr("class", "node default").attr("id", t.domId || t.id);
  let a;
  if (t.look === "handDrawn") {
    const s = W.svg(n).circle(0, 0, 14, Xb(i));
    a = n.insert(() => s), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  } else
    a = n.insert("circle", ":first-child"), a.attr("class", "state-start").attr("r", 7).attr("width", 14).attr("height", 14);
  return j(t, a), t.intersect = function(o) {
    return N.circle(t, 7, o);
  }, n;
}
p(Pd, "stateStart");
async function Nd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = ((t == null ? void 0 : t.padding) || 0) / 2, s = a.width + t.padding, l = a.height + t.padding, c = -a.width / 2 - o, h = -a.height / 2 - o, u = [
    { x: 0, y: 0 },
    { x: s, y: 0 },
    { x: s, y: -l },
    { x: 0, y: -l },
    { x: 0, y: 0 },
    { x: -8, y: 0 },
    { x: s + 8, y: 0 },
    { x: s + 8, y: -l },
    { x: -8, y: -l },
    { x: -8, y: 0 }
  ];
  if (t.look === "handDrawn") {
    const f = W.svg(n), d = H(t, {}), g = f.rectangle(c - 8, h, s + 16, l, d), m = f.line(c, h, c, h + l, d), x = f.line(c + s, h, c + s, h + l, d);
    n.insert(() => m, ":first-child"), n.insert(() => x, ":first-child");
    const y = n.insert(() => g, ":first-child"), { cssStyles: b } = t;
    y.attr("class", "basic label-container").attr("style", Mt(b)), j(t, y);
  } else {
    const f = Me(n, s, l, u);
    i && f.attr("style", i), j(t, f);
  }
  return t.intersect = function(f) {
    return N.polygon(t, u, f);
  }, n;
}
p(Nd, "subroutine");
async function zd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), s = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), l = -o / 2, c = -s / 2, h = 0.2 * s, u = 0.2 * s, { cssStyles: f } = t, d = W.svg(n), g = H(t, {}), m = [
    { x: l - h / 2, y: c },
    { x: l + o + h / 2, y: c },
    { x: l + o + h / 2, y: c + s },
    { x: l - h / 2, y: c + s }
  ], x = [
    { x: l + o - h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s },
    { x: l + o + h / 2, y: c + s - u }
  ];
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = tt(m), b = d.path(y, g), w = tt(x), k = d.path(w, { ...g, fillStyle: "solid" }), _ = n.insert(() => k, ":first-child");
  return _.insert(() => b, ":first-child"), _.attr("class", "basic label-container"), f && t.look !== "handDrawn" && _.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && _.selectAll("path").attr("style", i), j(t, _), t.intersect = function(C) {
    return N.polygon(t, m, C);
  }, n;
}
p(zd, "taggedRect");
async function qd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 4, h = 0.2 * s, u = 0.2 * l, f = l + c, { cssStyles: d } = t, g = W.svg(n), m = H(t, {});
  t.look !== "handDrawn" && (m.roughness = 0, m.fillStyle = "solid");
  const x = [
    { x: -s / 2 - s / 2 * 0.1, y: f / 2 },
    ...Se(
      -s / 2 - s / 2 * 0.1,
      f / 2,
      s / 2 + s / 2 * 0.1,
      f / 2,
      c,
      0.8
    ),
    { x: s / 2 + s / 2 * 0.1, y: -f / 2 },
    { x: -s / 2 - s / 2 * 0.1, y: -f / 2 }
  ], y = -s / 2 + s / 2 * 0.1, b = -f / 2 - u * 0.4, w = [
    { x: y + s - h, y: (b + l) * 1.4 },
    { x: y + s, y: b + l - u },
    { x: y + s, y: (b + l) * 0.9 },
    ...Se(
      y + s,
      (b + l) * 1.3,
      y + s - h,
      (b + l) * 1.5,
      -l * 0.03,
      0.5
    )
  ], k = tt(x), _ = g.path(k, m), C = tt(w), v = g.path(C, {
    ...m,
    fillStyle: "solid"
  }), D = n.insert(() => v, ":first-child");
  return D.insert(() => _, ":first-child"), D.attr("class", "basic label-container"), d && t.look !== "handDrawn" && D.selectAll("path").attr("style", d), i && t.look !== "handDrawn" && D.selectAll("path").attr("style", i), D.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, D), t.intersect = function(R) {
    return N.polygon(t, x, R);
  }, n;
}
p(qd, "taggedWaveEdgedRectangle");
async function Wd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = Math.max(a.width + t.padding, (t == null ? void 0 : t.width) || 0), s = Math.max(a.height + t.padding, (t == null ? void 0 : t.height) || 0), l = -o / 2, c = -s / 2, h = n.insert("rect", ":first-child");
  return h.attr("class", "text").attr("style", i).attr("rx", 0).attr("ry", 0).attr("x", l).attr("y", c).attr("width", o).attr("height", s), j(t, h), t.intersect = function(u) {
    return N.rect(t, u);
  }, n;
}
p(Wd, "text");
var O_ = /* @__PURE__ */ p((e, t, r, i, n, a) => `M${e},${t}
    a${n},${a} 0,0,1 0,${-i}
    l${r},0
    a${n},${a} 0,0,1 0,${i}
    M${r},${-i}
    a${n},${a} 0,0,0 0,${i}
    l${-r},0`, "createCylinderPathD"), R_ = /* @__PURE__ */ p((e, t, r, i, n, a) => [
  `M${e},${t}`,
  `M${e + r},${t}`,
  `a${n},${a} 0,0,0 0,${-i}`,
  `l${-r},0`,
  `a${n},${a} 0,0,0 0,${i}`,
  `l${r},0`
].join(" "), "createOuterCylinderPathD"), I_ = /* @__PURE__ */ p((e, t, r, i, n, a) => [`M${e + r / 2},${-i / 2}`, `a${n},${a} 0,0,0 0,${i}`].join(" "), "createInnerCylinderPathD");
async function Hd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o, halfPadding: s } = await Z(
    e,
    t,
    V(t)
  ), l = t.look === "neo" ? s * 2 : s, c = a.height + l, h = c / 2, u = h / (2.5 + c / 50), f = a.width + u + l, { cssStyles: d } = t;
  let g;
  if (t.look === "handDrawn") {
    const m = W.svg(n), x = R_(0, 0, f, c, u, h), y = I_(0, 0, f, c, u, h), b = m.path(x, H(t, {})), w = m.path(y, H(t, { fill: "none" }));
    g = n.insert(() => w, ":first-child"), g = n.insert(() => b, ":first-child"), g.attr("class", "basic label-container"), d && g.attr("style", d);
  } else {
    const m = O_(0, 0, f, c, u, h);
    g = n.insert("path", ":first-child").attr("d", m).attr("class", "basic label-container").attr("style", Mt(d)).attr("style", i), g.attr("class", "basic label-container"), d && g.selectAll("path").attr("style", d), i && g.selectAll("path").attr("style", i);
  }
  return g.attr("label-offset-x", u), g.attr("transform", `translate(${-f / 2}, ${c / 2} )`), o.attr(
    "transform",
    `translate(${-(a.width / 2) - u - (a.x - (a.left ?? 0))}, ${-(a.height / 2) - (a.y - (a.top ?? 0))})`
  ), j(t, g), t.intersect = function(m) {
    const x = N.rect(t, m), y = x.y - (t.y ?? 0);
    if (h != 0 && (Math.abs(y) < (t.height ?? 0) / 2 || Math.abs(y) == (t.height ?? 0) / 2 && Math.abs(x.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - u)) {
      let b = u * u * (1 - y * y / (h * h));
      b != 0 && (b = Math.sqrt(Math.abs(b))), b = u - b, m.x - (t.x ?? 0) > 0 && (b = -b), x.x += b;
    }
    return x;
  }, n;
}
p(Hd, "tiltedCylinder");
async function jd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = a.width + t.padding, s = a.height + t.padding, l = [
    { x: -3 * s / 6, y: 0 },
    { x: o + 3 * s / 6, y: 0 },
    { x: o, y: -s },
    { x: 0, y: -s }
  ];
  let c;
  const { cssStyles: h } = t;
  if (t.look === "handDrawn") {
    const u = W.svg(n), f = H(t, {}), d = tt(l), g = u.path(d, f);
    c = n.insert(() => g, ":first-child").attr("transform", `translate(${-o / 2}, ${s / 2})`), h && c.attr("style", h);
  } else
    c = Me(n, o, s, l);
  return i && c.attr("style", i), t.width = o, t.height = s, j(t, c), t.intersect = function(u) {
    return N.polygon(t, l, u);
  }, n;
}
p(jd, "trapezoid");
async function Yd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = 60, s = 20, l = Math.max(o, a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(s, a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), { cssStyles: h } = t, u = W.svg(n), f = H(t, {});
  t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid");
  const d = [
    { x: -l / 2 * 0.8, y: -c / 2 },
    { x: l / 2 * 0.8, y: -c / 2 },
    { x: l / 2, y: -c / 2 * 0.6 },
    { x: l / 2, y: c / 2 },
    { x: -l / 2, y: c / 2 },
    { x: -l / 2, y: -c / 2 * 0.6 }
  ], g = tt(d), m = u.path(g, f), x = n.insert(() => m, ":first-child");
  return x.attr("class", "basic label-container"), h && t.look !== "handDrawn" && x.selectChildren("path").attr("style", h), i && t.look !== "handDrawn" && x.selectChildren("path").attr("style", i), j(t, x), t.intersect = function(y) {
    return N.polygon(t, d, y);
  }, n;
}
p(Yd, "trapezoidalPentagon");
async function Gd(e, t) {
  var b;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Ct((b = nt().flowchart) == null ? void 0 : b.htmlLabels), l = a.width + (t.padding ?? 0), c = l + a.height, h = l + a.height, u = [
    { x: 0, y: 0 },
    { x: h, y: 0 },
    { x: h / 2, y: -c }
  ], { cssStyles: f } = t, d = W.svg(n), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = tt(u), x = d.path(m, g), y = n.insert(() => x, ":first-child").attr("transform", `translate(${-c / 2}, ${c / 2})`);
  return f && t.look !== "handDrawn" && y.selectChildren("path").attr("style", f), i && t.look !== "handDrawn" && y.selectChildren("path").attr("style", i), t.width = l, t.height = c, j(t, y), o.attr(
    "transform",
    `translate(${-a.width / 2 - (a.x - (a.left ?? 0))}, ${c / 2 - (a.height + (t.padding ?? 0) / (s ? 2 : 1) - (a.y - (a.top ?? 0)))})`
  ), t.intersect = function(w) {
    return F.info("Triangle intersect", t, u, w), N.polygon(t, u, w);
  }, n;
}
p(Gd, "triangle");
async function Ud(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = l / 8, h = l + c, { cssStyles: u } = t, d = 70 - s, g = d > 0 ? d / 2 : 0, m = W.svg(n), x = H(t, {});
  t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid");
  const y = [
    { x: -s / 2 - g, y: h / 2 },
    ...Se(
      -s / 2 - g,
      h / 2,
      s / 2 + g,
      h / 2,
      c,
      0.8
    ),
    { x: s / 2 + g, y: -h / 2 },
    { x: -s / 2 - g, y: -h / 2 }
  ], b = tt(y), w = m.path(b, x), k = n.insert(() => w, ":first-child");
  return k.attr("class", "basic label-container"), u && t.look !== "handDrawn" && k.selectAll("path").attr("style", u), i && t.look !== "handDrawn" && k.selectAll("path").attr("style", i), k.attr("transform", `translate(0,${-c / 2})`), o.attr(
    "transform",
    `translate(${-s / 2 + (t.padding ?? 0) - (a.x - (a.left ?? 0))},${-l / 2 + (t.padding ?? 0) - c - (a.y - (a.top ?? 0))})`
  ), j(t, k), t.intersect = function(_) {
    return N.polygon(t, y, _);
  }, n;
}
p(Ud, "waveEdgedRectangle");
async function Xd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a } = await Z(e, t, V(t)), o = 100, s = 50, l = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), c = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), h = l / c;
  let u = l, f = c;
  u > f * h ? f = u / h : u = f * h, u = Math.max(u, o), f = Math.max(f, s);
  const d = Math.min(f * 0.2, f / 4), g = f + d * 2, { cssStyles: m } = t, x = W.svg(n), y = H(t, {});
  t.look !== "handDrawn" && (y.roughness = 0, y.fillStyle = "solid");
  const b = [
    { x: -u / 2, y: g / 2 },
    ...Se(-u / 2, g / 2, u / 2, g / 2, d, 1),
    { x: u / 2, y: -g / 2 },
    ...Se(u / 2, -g / 2, -u / 2, -g / 2, d, -1)
  ], w = tt(b), k = x.path(w, y), _ = n.insert(() => k, ":first-child");
  return _.attr("class", "basic label-container"), m && t.look !== "handDrawn" && _.selectAll("path").attr("style", m), i && t.look !== "handDrawn" && _.selectAll("path").attr("style", i), j(t, _), t.intersect = function(C) {
    return N.polygon(t, b, C);
  }, n;
}
p(Xd, "waveRectangle");
async function Vd(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, label: o } = await Z(e, t, V(t)), s = Math.max(a.width + (t.padding ?? 0) * 2, (t == null ? void 0 : t.width) ?? 0), l = Math.max(a.height + (t.padding ?? 0) * 2, (t == null ? void 0 : t.height) ?? 0), c = 5, h = -s / 2, u = -l / 2, { cssStyles: f } = t, d = W.svg(n), g = H(t, {}), m = [
    { x: h - c, y: u - c },
    { x: h - c, y: u + l },
    { x: h + s, y: u + l },
    { x: h + s, y: u - c }
  ], x = `M${h - c},${u - c} L${h + s},${u - c} L${h + s},${u + l} L${h - c},${u + l} L${h - c},${u - c}
                M${h - c},${u} L${h + s},${u}
                M${h},${u - c} L${h},${u + l}`;
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const y = d.path(x, g), b = n.insert(() => y, ":first-child");
  return b.attr("transform", `translate(${c / 2}, ${c / 2})`), b.attr("class", "basic label-container"), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", f), i && t.look !== "handDrawn" && b.selectAll("path").attr("style", i), o.attr(
    "transform",
    `translate(${-(a.width / 2) + c / 2 - (a.x - (a.left ?? 0))}, ${-(a.height / 2) + c / 2 - (a.y - (a.top ?? 0))})`
  ), j(t, b), t.intersect = function(w) {
    return N.polygon(t, m, w);
  }, n;
}
p(Vd, "windowPane");
async function ho(e, t) {
  var lt, ft, yt, At;
  const r = t;
  if (r.alias && (t.label = r.alias), t.look === "handDrawn") {
    const { themeVariables: et } = Bt(), { background: it } = et, gt = {
      ...t,
      id: t.id + "-background",
      look: "default",
      cssStyles: ["stroke: none", `fill: ${it}`]
    };
    await ho(e, gt);
  }
  const i = Bt();
  t.useHtmlLabels = i.htmlLabels;
  let n = ((lt = i.er) == null ? void 0 : lt.diagramPadding) ?? 10, a = ((ft = i.er) == null ? void 0 : ft.entityPadding) ?? 6;
  const { cssStyles: o } = t, { labelStyles: s, nodeStyles: l } = Y(t);
  if (r.attributes.length === 0 && t.label) {
    const et = {
      rx: 0,
      ry: 0,
      labelPaddingX: n,
      labelPaddingY: n * 1.5
    };
    ge(t.label, i) + et.labelPaddingX * 2 < i.er.minEntityWidth && (t.width = i.er.minEntityWidth);
    const it = await Vn(e, t, et);
    if (!Ct(i.htmlLabels)) {
      const gt = it.select("text"), dt = (yt = gt.node()) == null ? void 0 : yt.getBBox();
      gt.attr("transform", `translate(${-dt.width / 2}, 0)`);
    }
    return it;
  }
  i.htmlLabels || (n *= 1.25, a *= 1.25);
  let c = V(t);
  c || (c = "node default");
  const h = e.insert("g").attr("class", c).attr("id", t.domId || t.id), u = await rr(h, t.label ?? "", i, 0, 0, ["name"], s);
  u.height += a;
  let f = 0;
  const d = [], g = [];
  let m = 0, x = 0, y = 0, b = 0, w = !0, k = !0;
  for (const et of r.attributes) {
    const it = await rr(
      h,
      et.type,
      i,
      0,
      f,
      ["attribute-type"],
      s
    );
    m = Math.max(m, it.width + n);
    const gt = await rr(
      h,
      et.name,
      i,
      0,
      f,
      ["attribute-name"],
      s
    );
    x = Math.max(x, gt.width + n);
    const dt = await rr(
      h,
      et.keys.join(),
      i,
      0,
      f,
      ["attribute-keys"],
      s
    );
    y = Math.max(y, dt.width + n);
    const ut = await rr(
      h,
      et.comment,
      i,
      0,
      f,
      ["attribute-comment"],
      s
    );
    b = Math.max(b, ut.width + n);
    const _t = Math.max(it.height, gt.height, dt.height, ut.height) + a;
    g.push({ yOffset: f, rowHeight: _t }), f += _t;
  }
  let _ = 4;
  y <= n && (w = !1, y = 0, _--), b <= n && (k = !1, b = 0, _--);
  const C = h.node().getBBox();
  if (u.width + n * 2 - (m + x + y + b) > 0) {
    const et = u.width + n * 2 - (m + x + y + b);
    m += et / _, x += et / _, y > 0 && (y += et / _), b > 0 && (b += et / _);
  }
  const v = m + x + y + b, D = W.svg(h), R = H(t, {});
  t.look !== "handDrawn" && (R.roughness = 0, R.fillStyle = "solid");
  let O = 0;
  g.length > 0 && (O = g.reduce((et, it) => et + ((it == null ? void 0 : it.rowHeight) ?? 0), 0));
  const A = Math.max(C.width + n * 2, (t == null ? void 0 : t.width) || 0, v), I = Math.max((O ?? 0) + u.height, (t == null ? void 0 : t.height) || 0), E = -A / 2, B = -I / 2;
  h.selectAll("g:not(:first-child)").each((et, it, gt) => {
    const dt = rt(gt[it]), ut = dt.attr("transform");
    let _t = 0, ye = 0;
    if (ut) {
      const ta = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(ut);
      ta && (_t = parseFloat(ta[1]), ye = parseFloat(ta[2]), dt.attr("class").includes("attribute-name") ? _t += m : dt.attr("class").includes("attribute-keys") ? _t += m + x : dt.attr("class").includes("attribute-comment") && (_t += m + x + y));
    }
    dt.attr(
      "transform",
      `translate(${E + n / 2 + _t}, ${ye + B + u.height + a / 2})`
    );
  }), h.select(".name").attr("transform", "translate(" + -u.width / 2 + ", " + (B + a / 2) + ")");
  const L = D.rectangle(E, B, A, I, R), T = h.insert(() => L, ":first-child").attr("style", o.join("")), { themeVariables: $ } = Bt(), { rowEven: M, rowOdd: z, nodeBorder: U } = $;
  d.push(0);
  for (const [et, it] of g.entries()) {
    const dt = (et + 1) % 2 === 0 && it.yOffset !== 0, ut = D.rectangle(E, u.height + B + (it == null ? void 0 : it.yOffset), A, it == null ? void 0 : it.rowHeight, {
      ...R,
      fill: dt ? M : z,
      stroke: U
    });
    h.insert(() => ut, "g.label").attr("style", o.join("")).attr("class", `row-rect-${dt ? "even" : "odd"}`);
  }
  let J = D.line(E, u.height + B, A + E, u.height + B, R);
  h.insert(() => J).attr("class", "divider"), J = D.line(m + E, u.height + B, m + E, I + B, R), h.insert(() => J).attr("class", "divider"), w && (J = D.line(
    m + x + E,
    u.height + B,
    m + x + E,
    I + B,
    R
  ), h.insert(() => J).attr("class", "divider")), k && (J = D.line(
    m + x + y + E,
    u.height + B,
    m + x + y + E,
    I + B,
    R
  ), h.insert(() => J).attr("class", "divider"));
  for (const et of d)
    J = D.line(
      E,
      u.height + B + et,
      A + E,
      u.height + B + et,
      R
    ), h.insert(() => J).attr("class", "divider");
  if (j(t, T), l && t.look !== "handDrawn") {
    const et = l.split(";"), it = (At = et == null ? void 0 : et.filter((gt) => gt.includes("stroke"))) == null ? void 0 : At.map((gt) => `${gt}`).join("; ");
    h.selectAll("path").attr("style", it ?? ""), h.selectAll(".row-rect-even path").attr("style", l);
  }
  return t.intersect = function(et) {
    return N.rect(t, et);
  }, h;
}
p(ho, "erBox");
async function rr(e, t, r, i = 0, n = 0, a = [], o = "") {
  const s = e.insert("g").attr("class", `label ${a.join(" ")}`).attr("transform", `translate(${i}, ${n})`).attr("style", o);
  t !== bo(t) && (t = bo(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;"));
  const l = s.node().appendChild(
    await Be(
      s,
      t,
      {
        width: ge(t, r) + 100,
        style: o,
        useHtmlLabels: r.htmlLabels
      },
      r
    )
  );
  if (t.includes("&lt;") || t.includes("&gt;")) {
    let h = l.children[0];
    for (h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); h.childNodes[0]; )
      h = h.childNodes[0], h.textContent = h.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
  }
  let c = l.getBBox();
  if (Ct(r.htmlLabels)) {
    const h = l.children[0];
    h.style.textAlign = "start";
    const u = rt(l);
    c = h.getBoundingClientRect(), u.attr("width", c.width), u.attr("height", c.height);
  }
  return c;
}
p(rr, "addText");
async function Zd(e, t, r, i, n = r.class.padding ?? 12) {
  const a = i ? 0 : 3, o = e.insert("g").attr("class", V(t)).attr("id", t.domId || t.id);
  let s = null, l = null, c = null, h = null, u = 0, f = 0, d = 0;
  if (s = o.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    const b = t.annotations[0];
    await jr(s, { text: `«${b}»` }, 0), u = s.node().getBBox().height;
  }
  l = o.insert("g").attr("class", "label-group text"), await jr(l, t, 0, ["font-weight: bolder"]);
  const g = l.node().getBBox();
  f = g.height, c = o.insert("g").attr("class", "members-group text");
  let m = 0;
  for (const b of t.members) {
    const w = await jr(c, b, m, [b.parseClassifier()]);
    m += w + a;
  }
  d = c.node().getBBox().height, d <= 0 && (d = n / 2), h = o.insert("g").attr("class", "methods-group text");
  let x = 0;
  for (const b of t.methods) {
    const w = await jr(h, b, x, [b.parseClassifier()]);
    x += w + a;
  }
  let y = o.node().getBBox();
  if (s !== null) {
    const b = s.node().getBBox();
    s.attr("transform", `translate(${-b.width / 2})`);
  }
  return l.attr("transform", `translate(${-g.width / 2}, ${u})`), y = o.node().getBBox(), c.attr(
    "transform",
    `translate(0, ${u + f + n * 2})`
  ), y = o.node().getBBox(), h.attr(
    "transform",
    `translate(0, ${u + f + (d ? d + n * 4 : n * 2)})`
  ), y = o.node().getBBox(), { shapeSvg: o, bbox: y };
}
p(Zd, "textHelper");
async function jr(e, t, r, i = []) {
  const n = e.insert("g").attr("class", "label").attr("style", i.join("; ")), a = Bt();
  let o = "useHtmlLabels" in t ? t.useHtmlLabels : Ct(a.htmlLabels) ?? !0, s = "";
  "text" in t ? s = t.text : s = t.label, !o && s.startsWith("\\") && (s = s.substring(1)), yr(s) && (o = !0);
  const l = await Be(
    n,
    bs(Ke(s)),
    {
      width: ge(s, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o
    },
    a
  );
  let c, h = 1;
  if (o) {
    const u = l.children[0], f = rt(l);
    h = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (h += u.innerHTML.split("<mrow>").length - 1);
    const d = u.getElementsByTagName("img");
    if (d) {
      const g = s.replace(/<img[^>]*>/g, "").trim() === "";
      await Promise.all(
        [...d].map(
          (m) => new Promise((x) => {
            function y() {
              var b;
              if (m.style.display = "flex", m.style.flexDirection = "column", g) {
                const w = ((b = a.fontSize) == null ? void 0 : b.toString()) ?? window.getComputedStyle(document.body).fontSize, _ = parseInt(w, 10) * 5 + "px";
                m.style.minWidth = _, m.style.maxWidth = _;
              } else
                m.style.width = "100%";
              x(m);
            }
            p(y, "setupImage"), setTimeout(() => {
              m.complete && y();
            }), m.addEventListener("error", y), m.addEventListener("load", y);
          })
        )
      );
    }
    c = u.getBoundingClientRect(), f.attr("width", c.width), f.attr("height", c.height);
  } else {
    i.includes("font-weight: bolder") && rt(l).selectAll("tspan").attr("font-weight", ""), h = l.children.length;
    const u = l.children[0];
    (l.textContent === "" || l.textContent.includes("&gt")) && (u.textContent = s[0] + s.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), s[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), c = l.getBBox();
  }
  return n.attr("transform", "translate(0," + (-c.height / (2 * h) + r) + ")"), c.height;
}
p(jr, "addText");
async function Kd(e, t) {
  var R, O;
  const r = nt(), i = r.class.padding ?? 12, n = i, a = t.useHtmlLabels ?? Ct(r.htmlLabels) ?? !0, o = t;
  o.annotations = o.annotations ?? [], o.members = o.members ?? [], o.methods = o.methods ?? [];
  const { shapeSvg: s, bbox: l } = await Zd(e, t, r, a, n), { labelStyles: c, nodeStyles: h } = Y(t);
  t.labelStyle = c, t.cssStyles = o.styles || "";
  const u = ((R = o.styles) == null ? void 0 : R.join(";")) || h || "";
  t.cssStyles || (t.cssStyles = u.replaceAll("!important", "").split(";"));
  const f = o.members.length === 0 && o.methods.length === 0 && !((O = r.class) != null && O.hideEmptyMembersBox), d = W.svg(s), g = H(t, {});
  t.look !== "handDrawn" && (g.roughness = 0, g.fillStyle = "solid");
  const m = l.width;
  let x = l.height;
  o.members.length === 0 && o.methods.length === 0 ? x += n : o.members.length > 0 && o.methods.length === 0 && (x += n * 2);
  const y = -m / 2, b = -x / 2, w = d.rectangle(
    y - i,
    b - i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0),
    m + 2 * i,
    x + 2 * i + (f ? i * 2 : o.members.length === 0 && o.methods.length === 0 ? -i : 0),
    g
  ), k = s.insert(() => w, ":first-child");
  k.attr("class", "basic label-container");
  const _ = k.node().getBBox();
  s.selectAll(".text").each((A, I, E) => {
    var z;
    const B = rt(E[I]), L = B.attr("transform");
    let T = 0;
    if (L) {
      const J = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(L);
      J && (T = parseFloat(J[2]));
    }
    let $ = T + b + i - (f ? i : o.members.length === 0 && o.methods.length === 0 ? -i / 2 : 0);
    a || ($ -= 4);
    let M = y;
    (B.attr("class").includes("label-group") || B.attr("class").includes("annotation-group")) && (M = -((z = B.node()) == null ? void 0 : z.getBBox().width) / 2 || 0, s.selectAll("text").each(function(U, J, lt) {
      window.getComputedStyle(lt[J]).textAnchor === "middle" && (M = 0);
    })), B.attr("transform", `translate(${M}, ${$})`);
  });
  const C = s.select(".annotation-group").node().getBBox().height - (f ? i / 2 : 0) || 0, v = s.select(".label-group").node().getBBox().height - (f ? i / 2 : 0) || 0, D = s.select(".members-group").node().getBBox().height - (f ? i / 2 : 0) || 0;
  if (o.members.length > 0 || o.methods.length > 0 || f) {
    const A = d.line(
      _.x,
      C + v + b + i,
      _.x + _.width,
      C + v + b + i,
      g
    );
    s.insert(() => A).attr("class", "divider").attr("style", u);
  }
  if (f || o.members.length > 0 || o.methods.length > 0) {
    const A = d.line(
      _.x,
      C + v + D + b + n * 2 + i,
      _.x + _.width,
      C + v + D + b + i + n * 2,
      g
    );
    s.insert(() => A).attr("class", "divider").attr("style", u);
  }
  if (o.look !== "handDrawn" && s.selectAll("path").attr("style", u), k.select(":nth-child(2)").attr("style", u), s.selectAll(".divider").select("path").attr("style", u), t.labelStyle ? s.selectAll("span").attr("style", t.labelStyle) : s.selectAll("span").attr("style", u), !a) {
    const A = RegExp(/color\s*:\s*([^;]*)/), I = A.exec(u);
    if (I) {
      const E = I[0].replace("color", "fill");
      s.selectAll("tspan").attr("style", E);
    } else if (c) {
      const E = A.exec(c);
      if (E) {
        const B = E[0].replace("color", "fill");
        s.selectAll("tspan").attr("style", B);
      }
    }
  }
  return j(t, k), t.intersect = function(A) {
    return N.rect(t, A);
  }, s;
}
p(Kd, "classBox");
async function Qd(e, t) {
  var C, v;
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const n = t, a = t, o = 20, s = 20, l = "verifyMethod" in t, c = V(t), h = e.insert("g").attr("class", c).attr("id", t.domId ?? t.id);
  let u;
  l ? u = await Jt(
    h,
    `&lt;&lt;${n.type}&gt;&gt;`,
    0,
    t.labelStyle
  ) : u = await Jt(h, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle);
  let f = u;
  const d = await Jt(
    h,
    n.name,
    f,
    t.labelStyle + "; font-weight: bold;"
  );
  if (f += d + s, l) {
    const D = await Jt(
      h,
      `${n.requirementId ? `ID: ${n.requirementId}` : ""}`,
      f,
      t.labelStyle
    );
    f += D;
    const R = await Jt(
      h,
      `${n.text ? `Text: ${n.text}` : ""}`,
      f,
      t.labelStyle
    );
    f += R;
    const O = await Jt(
      h,
      `${n.risk ? `Risk: ${n.risk}` : ""}`,
      f,
      t.labelStyle
    );
    f += O, await Jt(
      h,
      `${n.verifyMethod ? `Verification: ${n.verifyMethod}` : ""}`,
      f,
      t.labelStyle
    );
  } else {
    const D = await Jt(
      h,
      `${a.type ? `Type: ${a.type}` : ""}`,
      f,
      t.labelStyle
    );
    f += D, await Jt(
      h,
      `${a.docRef ? `Doc Ref: ${a.docRef}` : ""}`,
      f,
      t.labelStyle
    );
  }
  const g = (((C = h.node()) == null ? void 0 : C.getBBox().width) ?? 200) + o, m = (((v = h.node()) == null ? void 0 : v.getBBox().height) ?? 200) + o, x = -g / 2, y = -m / 2, b = W.svg(h), w = H(t, {});
  t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid");
  const k = b.rectangle(x, y, g, m, w), _ = h.insert(() => k, ":first-child");
  if (_.attr("class", "basic label-container").attr("style", i), h.selectAll(".label").each((D, R, O) => {
    const A = rt(O[R]), I = A.attr("transform");
    let E = 0, B = 0;
    if (I) {
      const M = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(I);
      M && (E = parseFloat(M[1]), B = parseFloat(M[2]));
    }
    const L = B - m / 2;
    let T = x + o / 2;
    (R === 0 || R === 1) && (T = E), A.attr("transform", `translate(${T}, ${L + o})`);
  }), f > u + d + s) {
    const D = b.line(
      x,
      y + u + d + s,
      x + g,
      y + u + d + s,
      w
    );
    h.insert(() => D).attr("style", i);
  }
  return j(t, _), t.intersect = function(D) {
    return N.rect(t, D);
  }, h;
}
p(Qd, "requirementBox");
async function Jt(e, t, r, i = "") {
  if (t === "")
    return 0;
  const n = e.insert("g").attr("class", "label").attr("style", i), a = nt(), o = a.htmlLabels ?? !0, s = await Be(
    n,
    bs(Ke(t)),
    {
      width: ge(t, a) + 50,
      // Add room for error when splitting text into multiple lines
      classes: "markdown-node-label",
      useHtmlLabels: o,
      style: i
    },
    a
  );
  let l;
  if (o) {
    const c = s.children[0], h = rt(s);
    l = c.getBoundingClientRect(), h.attr("width", l.width), h.attr("height", l.height);
  } else {
    const c = s.children[0];
    for (const h of c.children)
      h.textContent = h.textContent.replaceAll("&gt;", ">").replaceAll("&lt;", "<"), i && h.setAttribute("style", i);
    l = s.getBBox(), l.height += 6;
  }
  return n.attr("transform", `translate(${-l.width / 2},${-l.height / 2 + r})`), l.height;
}
p(Jt, "addText");
var P_ = /* @__PURE__ */ p((e) => {
  switch (e) {
    case "Very High":
      return "red";
    case "High":
      return "orange";
    case "Medium":
      return null;
    case "Low":
      return "blue";
    case "Very Low":
      return "lightblue";
  }
}, "colorFromPriority");
async function Jd(e, t, { config: r }) {
  var I, E;
  const { labelStyles: i, nodeStyles: n } = Y(t);
  t.labelStyle = i || "";
  const a = 10, o = t.width;
  t.width = (t.width ?? 200) - 10;
  const {
    shapeSvg: s,
    bbox: l,
    label: c
  } = await Z(e, t, V(t)), h = t.padding || 10;
  let u = "", f;
  "ticket" in t && t.ticket && ((I = r == null ? void 0 : r.kanban) != null && I.ticketBaseUrl) && (u = (E = r == null ? void 0 : r.kanban) == null ? void 0 : E.ticketBaseUrl.replace("#TICKET#", t.ticket), f = s.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank"));
  const d = {
    useHtmlLabels: t.useHtmlLabels,
    labelStyle: t.labelStyle || "",
    width: t.width,
    img: t.img,
    padding: t.padding || 8,
    centerLabel: !1
  };
  let g, m;
  f ? { label: g, bbox: m } = await da(
    f,
    "ticket" in t && t.ticket || "",
    d
  ) : { label: g, bbox: m } = await da(
    s,
    "ticket" in t && t.ticket || "",
    d
  );
  const { label: x, bbox: y } = await da(
    s,
    "assigned" in t && t.assigned || "",
    d
  );
  t.width = o;
  const b = 10, w = (t == null ? void 0 : t.width) || 0, k = Math.max(m.height, y.height) / 2, _ = Math.max(l.height + b * 2, (t == null ? void 0 : t.height) || 0) + k, C = -w / 2, v = -_ / 2;
  c.attr(
    "transform",
    "translate(" + (h - w / 2) + ", " + (-k - l.height / 2) + ")"
  ), g.attr(
    "transform",
    "translate(" + (h - w / 2) + ", " + (-k + l.height / 2) + ")"
  ), x.attr(
    "transform",
    "translate(" + (h + w / 2 - y.width - 2 * a) + ", " + (-k + l.height / 2) + ")"
  );
  let D;
  const { rx: R, ry: O } = t, { cssStyles: A } = t;
  if (t.look === "handDrawn") {
    const B = W.svg(s), L = H(t, {}), T = R || O ? B.path(Le(C, v, w, _, R || 0), L) : B.rectangle(C, v, w, _, L);
    D = s.insert(() => T, ":first-child"), D.attr("class", "basic label-container").attr("style", A || null);
  } else {
    D = s.insert("rect", ":first-child"), D.attr("class", "basic label-container __APA__").attr("style", n).attr("rx", R ?? 5).attr("ry", O ?? 5).attr("x", C).attr("y", v).attr("width", w).attr("height", _);
    const B = "priority" in t && t.priority;
    if (B) {
      const L = s.append("line"), T = C + 2, $ = v + Math.floor((R ?? 0) / 2), M = v + _ - Math.floor((R ?? 0) / 2);
      L.attr("x1", T).attr("y1", $).attr("x2", T).attr("y2", M).attr("stroke-width", "4").attr("stroke", P_(B));
    }
  }
  return j(t, D), t.height = _, t.intersect = function(B) {
    return N.rect(t, B);
  }, s;
}
p(Jd, "kanbanItem");
async function tp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await Z(
    e,
    t,
    V(t)
  ), l = a.width + 10 * o, c = a.height + 8 * o, h = 0.15 * l, { cssStyles: u } = t, f = a.width + 20, d = a.height + 20, g = Math.max(l, f), m = Math.max(c, d);
  s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`);
  let x;
  const y = `M0 0 
    a${h},${h} 1 0,0 ${g * 0.25},${-1 * m * 0.1}
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},0
    a${h},${h} 1 0,0 ${g * 0.25},${m * 0.1}

    a${h},${h} 1 0,0 ${g * 0.15},${m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${m * 0.34}
    a${h},${h} 1 0,0 ${-1 * g * 0.15},${m * 0.33}

    a${h},${h} 1 0,0 ${-1 * g * 0.25},${m * 0.15}
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},0
    a${h},${h} 1 0,0 ${-1 * g * 0.25},${-1 * m * 0.15}

    a${h},${h} 1 0,0 ${-1 * g * 0.1},${-1 * m * 0.33}
    a${h * 0.8},${h * 0.8} 1 0,0 0,${-1 * m * 0.34}
    a${h},${h} 1 0,0 ${g * 0.1},${-1 * m * 0.33}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const b = W.svg(n), w = H(t, {}), k = b.path(y, w);
    x = n.insert(() => k, ":first-child"), x.attr("class", "basic label-container").attr("style", Mt(u));
  } else
    x = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", y);
  return x.attr("transform", `translate(${-g / 2}, ${-m / 2})`), j(t, x), t.calcIntersect = function(b, w) {
    return N.rect(b, w);
  }, t.intersect = function(b) {
    return F.info("Bang intersect", t, b), N.rect(t, b);
  }, n;
}
p(tp, "bang");
async function ep(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await Z(
    e,
    t,
    V(t)
  ), l = a.width + 2 * o, c = a.height + 2 * o, h = 0.15 * l, u = 0.25 * l, f = 0.35 * l, d = 0.2 * l, { cssStyles: g } = t;
  let m;
  const x = `M0 0 
    a${h},${h} 0 0,1 ${l * 0.25},${-1 * l * 0.1}
    a${f},${f} 1 0,1 ${l * 0.4},${-1 * l * 0.1}
    a${u},${u} 1 0,1 ${l * 0.35},${l * 0.2}

    a${h},${h} 1 0,1 ${l * 0.15},${c * 0.35}
    a${d},${d} 1 0,1 ${-1 * l * 0.15},${c * 0.65}

    a${u},${h} 1 0,1 ${-1 * l * 0.25},${l * 0.15}
    a${f},${f} 1 0,1 ${-1 * l * 0.5},0
    a${h},${h} 1 0,1 ${-1 * l * 0.25},${-1 * l * 0.15}

    a${h},${h} 1 0,1 ${-1 * l * 0.1},${-1 * c * 0.35}
    a${d},${d} 1 0,1 ${l * 0.1},${-1 * c * 0.65}
  H0 V0 Z`;
  if (t.look === "handDrawn") {
    const y = W.svg(n), b = H(t, {}), w = y.path(x, b);
    m = n.insert(() => w, ":first-child"), m.attr("class", "basic label-container").attr("style", Mt(g));
  } else
    m = n.insert("path", ":first-child").attr("class", "basic label-container").attr("style", i).attr("d", x);
  return s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), m.attr("transform", `translate(${-l / 2}, ${-c / 2})`), j(t, m), t.calcIntersect = function(y, b) {
    return N.rect(y, b);
  }, t.intersect = function(y) {
    return F.info("Cloud intersect", t, y), N.rect(t, y);
  }, n;
}
p(ep, "cloud");
async function rp(e, t) {
  const { labelStyles: r, nodeStyles: i } = Y(t);
  t.labelStyle = r;
  const { shapeSvg: n, bbox: a, halfPadding: o, label: s } = await Z(
    e,
    t,
    V(t)
  ), l = a.width + 8 * o, c = a.height + 2 * o, h = 5, u = `
    M${-l / 2} ${c / 2 - h}
    v${-c + 2 * h}
    q0,-${h} ${h},-${h}
    h${l - 2 * h}
    q${h},0 ${h},${h}
    v${c - 2 * h}
    q0,${h} -${h},${h}
    h${-l + 2 * h}
    q-${h},0 -${h},-${h}
    Z
  `, f = n.append("path").attr("id", "node-" + t.id).attr("class", "node-bkg node-" + t.type).attr("style", i).attr("d", u);
  return n.append("line").attr("class", "node-line-").attr("x1", -l / 2).attr("y1", c / 2).attr("x2", l / 2).attr("y2", c / 2), s.attr("transform", `translate(${-a.width / 2}, ${-a.height / 2})`), n.append(() => s.node()), j(t, f), t.calcIntersect = function(d, g) {
    return N.rect(d, g);
  }, t.intersect = function(d) {
    return N.rect(t, d);
  }, n;
}
p(rp, "defaultMindmapNode");
async function ip(e, t) {
  const r = {
    padding: t.padding ?? 0
  };
  return co(e, t, r);
}
p(ip, "mindmapCircle");
var N_ = [
  {
    semanticName: "Process",
    name: "Rectangle",
    shortName: "rect",
    description: "Standard process shape",
    aliases: ["proc", "process", "rectangle"],
    internalAliases: ["squareRect"],
    handler: Dd
  },
  {
    semanticName: "Event",
    name: "Rounded Rectangle",
    shortName: "rounded",
    description: "Represents an event",
    aliases: ["event"],
    internalAliases: ["roundedRect"],
    handler: Ad
  },
  {
    semanticName: "Terminal Point",
    name: "Stadium",
    shortName: "stadium",
    description: "Terminal point",
    aliases: ["terminal", "pill"],
    handler: Od
  },
  {
    semanticName: "Subprocess",
    name: "Framed Rectangle",
    shortName: "fr-rect",
    description: "Subprocess",
    aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"],
    handler: Nd
  },
  {
    semanticName: "Database",
    name: "Cylinder",
    shortName: "cyl",
    description: "Database storage",
    aliases: ["db", "database", "cylinder"],
    handler: nd
  },
  {
    semanticName: "Start",
    name: "Circle",
    shortName: "circle",
    description: "Starting point",
    aliases: ["circ"],
    handler: co
  },
  {
    semanticName: "Bang",
    name: "Bang",
    shortName: "bang",
    description: "Bang",
    aliases: ["bang"],
    handler: tp
  },
  {
    semanticName: "Cloud",
    name: "Cloud",
    shortName: "cloud",
    description: "cloud",
    aliases: ["cloud"],
    handler: ep
  },
  {
    semanticName: "Decision",
    name: "Diamond",
    shortName: "diam",
    description: "Decision-making step",
    aliases: ["decision", "diamond", "question"],
    handler: Ld
  },
  {
    semanticName: "Prepare Conditional",
    name: "Hexagon",
    shortName: "hex",
    description: "Preparation or condition step",
    aliases: ["hexagon", "prepare"],
    handler: ud
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Right",
    shortName: "lean-r",
    description: "Represents input or output",
    aliases: ["lean-right", "in-out"],
    internalAliases: ["lean_right"],
    handler: wd
  },
  {
    semanticName: "Data Input/Output",
    name: "Lean Left",
    shortName: "lean-l",
    description: "Represents output or input",
    aliases: ["lean-left", "out-in"],
    internalAliases: ["lean_left"],
    handler: Cd
  },
  {
    semanticName: "Priority Action",
    name: "Trapezoid Base Bottom",
    shortName: "trap-b",
    description: "Priority action",
    aliases: ["priority", "trapezoid-bottom", "trapezoid"],
    handler: jd
  },
  {
    semanticName: "Manual Operation",
    name: "Trapezoid Base Top",
    shortName: "trap-t",
    description: "Represents a manual task",
    aliases: ["manual", "trapezoid-top", "inv-trapezoid"],
    internalAliases: ["inv_trapezoid"],
    handler: xd
  },
  {
    semanticName: "Stop",
    name: "Double Circle",
    shortName: "dbl-circ",
    description: "Represents a stop point",
    aliases: ["double-circle"],
    internalAliases: ["doublecircle"],
    handler: sd
  },
  {
    semanticName: "Text Block",
    name: "Text Block",
    shortName: "text",
    description: "Text block",
    handler: Wd
  },
  {
    semanticName: "Card",
    name: "Notched Rectangle",
    shortName: "notch-rect",
    description: "Represents a card",
    aliases: ["card", "notched-rectangle"],
    handler: Zf
  },
  {
    semanticName: "Lined/Shaded Process",
    name: "Lined Rectangle",
    shortName: "lin-rect",
    description: "Lined process shape",
    aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"],
    handler: Fd
  },
  {
    semanticName: "Start",
    name: "Small Circle",
    shortName: "sm-circ",
    description: "Small starting point",
    aliases: ["start", "small-circle"],
    internalAliases: ["stateStart"],
    handler: Pd
  },
  {
    semanticName: "Stop",
    name: "Framed Circle",
    shortName: "fr-circ",
    description: "Stop point",
    aliases: ["stop", "framed-circle"],
    internalAliases: ["stateEnd"],
    handler: Id
  },
  {
    semanticName: "Fork/Join",
    name: "Filled Rectangle",
    shortName: "fork",
    description: "Fork or join in process flow",
    aliases: ["join"],
    internalAliases: ["forkJoin"],
    handler: cd
  },
  {
    semanticName: "Collate",
    name: "Hourglass",
    shortName: "hourglass",
    description: "Represents a collate operation",
    aliases: ["hourglass", "collate"],
    handler: fd
  },
  {
    semanticName: "Comment",
    name: "Curly Brace",
    shortName: "brace",
    description: "Adds a comment",
    aliases: ["comment", "brace-l"],
    handler: td
  },
  {
    semanticName: "Comment Right",
    name: "Curly Brace",
    shortName: "brace-r",
    description: "Adds a comment",
    handler: ed
  },
  {
    semanticName: "Comment with braces on both sides",
    name: "Curly Braces",
    shortName: "braces",
    description: "Adds a comment",
    handler: rd
  },
  {
    semanticName: "Com Link",
    name: "Lightning Bolt",
    shortName: "bolt",
    description: "Communication link",
    aliases: ["com-link", "lightning-bolt"],
    handler: _d
  },
  {
    semanticName: "Document",
    name: "Document",
    shortName: "doc",
    description: "Represents a document",
    aliases: ["doc", "document"],
    handler: Ud
  },
  {
    semanticName: "Delay",
    name: "Half-Rounded Rectangle",
    shortName: "delay",
    description: "Represents a delay",
    aliases: ["half-rounded-rectangle"],
    handler: hd
  },
  {
    semanticName: "Direct Access Storage",
    name: "Horizontal Cylinder",
    shortName: "h-cyl",
    description: "Direct access storage",
    aliases: ["das", "horizontal-cylinder"],
    handler: Hd
  },
  {
    semanticName: "Disk Storage",
    name: "Lined Cylinder",
    shortName: "lin-cyl",
    description: "Disk storage",
    aliases: ["disk", "lined-cylinder"],
    handler: vd
  },
  {
    semanticName: "Display",
    name: "Curved Trapezoid",
    shortName: "curv-trap",
    description: "Represents a display",
    aliases: ["curved-trapezoid", "display"],
    handler: id
  },
  {
    semanticName: "Divided Process",
    name: "Divided Rectangle",
    shortName: "div-rect",
    description: "Divided process shape",
    aliases: ["div-proc", "divided-rectangle", "divided-process"],
    handler: ad
  },
  {
    semanticName: "Extract",
    name: "Triangle",
    shortName: "tri",
    description: "Extraction process",
    aliases: ["extract", "triangle"],
    handler: Gd
  },
  {
    semanticName: "Internal Storage",
    name: "Window Pane",
    shortName: "win-pane",
    description: "Internal storage",
    aliases: ["internal-storage", "window-pane"],
    handler: Vd
  },
  {
    semanticName: "Junction",
    name: "Filled Circle",
    shortName: "f-circ",
    description: "Junction point",
    aliases: ["junction", "filled-circle"],
    handler: od
  },
  {
    semanticName: "Loop Limit",
    name: "Trapezoidal Pentagon",
    shortName: "notch-pent",
    description: "Loop limit step",
    aliases: ["loop-limit", "notched-pentagon"],
    handler: Yd
  },
  {
    semanticName: "Manual File",
    name: "Flipped Triangle",
    shortName: "flip-tri",
    description: "Manual file operation",
    aliases: ["manual-file", "flipped-triangle"],
    handler: ld
  },
  {
    semanticName: "Manual Input",
    name: "Sloped Rectangle",
    shortName: "sl-rect",
    description: "Manual input step",
    aliases: ["manual-input", "sloped-rectangle"],
    handler: Ed
  },
  {
    semanticName: "Multi-Document",
    name: "Stacked Document",
    shortName: "docs",
    description: "Multiple documents",
    aliases: ["documents", "st-doc", "stacked-document"],
    handler: Td
  },
  {
    semanticName: "Multi-Process",
    name: "Stacked Rectangle",
    shortName: "st-rect",
    description: "Multiple processes",
    aliases: ["procs", "processes", "stacked-rectangle"],
    handler: Sd
  },
  {
    semanticName: "Stored Data",
    name: "Bow Tie Rectangle",
    shortName: "bow-rect",
    description: "Stored data",
    aliases: ["stored-data", "bow-tie-rectangle"],
    handler: Vf
  },
  {
    semanticName: "Summary",
    name: "Crossed Circle",
    shortName: "cross-circ",
    description: "Summary",
    aliases: ["summary", "crossed-circle"],
    handler: Jf
  },
  {
    semanticName: "Tagged Document",
    name: "Tagged Document",
    shortName: "tag-doc",
    description: "Tagged document",
    aliases: ["tag-doc", "tagged-document"],
    handler: qd
  },
  {
    semanticName: "Tagged Process",
    name: "Tagged Rectangle",
    shortName: "tag-rect",
    description: "Tagged process",
    aliases: ["tagged-rectangle", "tag-proc", "tagged-process"],
    handler: zd
  },
  {
    semanticName: "Paper Tape",
    name: "Flag",
    shortName: "flag",
    description: "Paper tape",
    aliases: ["paper-tape"],
    handler: Xd
  },
  {
    semanticName: "Odd",
    name: "Odd",
    shortName: "odd",
    description: "Odd shape",
    internalAliases: ["rect_left_inv_arrow"],
    handler: Md
  },
  {
    semanticName: "Lined Document",
    name: "Lined Document",
    shortName: "lin-doc",
    description: "Lined document",
    aliases: ["lined-document"],
    handler: kd
  }
], z_ = /* @__PURE__ */ p(() => {
  const t = [
    ...Object.entries({
      // States
      state: Rd,
      choice: Kf,
      note: Bd,
      // Rectangles
      rectWithTitle: $d,
      labelRect: bd,
      // Icons
      iconSquare: md,
      iconCircle: pd,
      icon: dd,
      iconRounded: gd,
      imageSquare: yd,
      anchor: Xf,
      // Kanban diagram
      kanbanItem: Jd,
      //Mindmap diagram
      mindmapCircle: ip,
      defaultMindmapNode: rp,
      // class diagram
      classBox: Kd,
      // er diagram
      erBox: ho,
      // Requirement diagram
      requirementBox: Qd
    }),
    ...N_.flatMap((r) => [
      r.shortName,
      ..."aliases" in r ? r.aliases : [],
      ..."internalAliases" in r ? r.internalAliases : []
    ].map((n) => [n, r.handler]))
  ];
  return Object.fromEntries(t);
}, "generateShapeMap"), np = z_();
function q_(e) {
  return e in np;
}
p(q_, "isValidShape");
var Zn = /* @__PURE__ */ new Map();
async function ap(e, t, r) {
  let i, n;
  t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect");
  const a = t.shape ? np[t.shape] : void 0;
  if (!a)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`);
  if (t.link) {
    let o;
    r.config.securityLevel === "sandbox" ? o = "_top" : t.linkTarget && (o = t.linkTarget || "_blank"), i = e.insert("svg:a").attr("xlink:href", t.link).attr("target", o ?? null), n = await a(i, t, r);
  } else
    n = await a(e, t, r), i = n;
  return t.tooltip && n.attr("title", t.tooltip), Zn.set(t.id, i), t.haveCallback && i.attr("class", i.attr("class") + " clickable"), i;
}
p(ap, "insertNode");
var UT = /* @__PURE__ */ p((e, t) => {
  Zn.set(t.id, e);
}, "setNodeElem"), XT = /* @__PURE__ */ p(() => {
  Zn.clear();
}, "clear"), VT = /* @__PURE__ */ p((e) => {
  const t = Zn.get(e.id);
  F.trace(
    "Transforming node",
    e.diff,
    e,
    "translate(" + (e.x - e.width / 2 - 5) + ", " + e.width / 2 + ")"
  );
  const r = 8, i = e.diff || 0;
  return e.clusterNode ? t.attr(
    "transform",
    "translate(" + (e.x + i - e.width / 2) + ", " + (e.y - e.height / 2 - r) + ")"
  ) : t.attr("transform", "translate(" + e.x + ", " + e.y + ")"), i;
}, "positionNode"), W_ = /* @__PURE__ */ p((e, t, r, i, n, a) => {
  t.arrowTypeStart && kl(e, "start", t.arrowTypeStart, r, i, n, a), t.arrowTypeEnd && kl(e, "end", t.arrowTypeEnd, r, i, n, a);
}, "addEdgeMarkers"), H_ = {
  arrow_cross: { type: "cross", fill: !1 },
  arrow_point: { type: "point", fill: !0 },
  arrow_barb: { type: "barb", fill: !0 },
  arrow_circle: { type: "circle", fill: !1 },
  aggregation: { type: "aggregation", fill: !1 },
  extension: { type: "extension", fill: !1 },
  composition: { type: "composition", fill: !0 },
  dependency: { type: "dependency", fill: !0 },
  lollipop: { type: "lollipop", fill: !1 },
  only_one: { type: "onlyOne", fill: !1 },
  zero_or_one: { type: "zeroOrOne", fill: !1 },
  one_or_more: { type: "oneOrMore", fill: !1 },
  zero_or_more: { type: "zeroOrMore", fill: !1 },
  requirement_arrow: { type: "requirement_arrow", fill: !1 },
  requirement_contains: { type: "requirement_contains", fill: !1 }
}, kl = /* @__PURE__ */ p((e, t, r, i, n, a, o) => {
  var u;
  const s = H_[r];
  if (!s) {
    F.warn(`Unknown arrow type: ${r}`);
    return;
  }
  const l = s.type, h = `${n}_${a}-${l}${t === "start" ? "Start" : "End"}`;
  if (o && o.trim() !== "") {
    const f = o.replace(/[^\dA-Za-z]/g, "_"), d = `${h}_${f}`;
    if (!document.getElementById(d)) {
      const g = document.getElementById(h);
      if (g) {
        const m = g.cloneNode(!0);
        m.id = d, m.querySelectorAll("path, circle, line").forEach((y) => {
          y.setAttribute("stroke", o), s.fill && y.setAttribute("fill", o);
        }), (u = g.parentNode) == null || u.appendChild(m);
      }
    }
    e.attr(`marker-${t}`, `url(${i}#${d})`);
  } else
    e.attr(`marker-${t}`, `url(${i}#${h})`);
}, "addEdgeMarker"), Sn = /* @__PURE__ */ new Map(), kt = /* @__PURE__ */ new Map(), ZT = /* @__PURE__ */ p(() => {
  Sn.clear(), kt.clear();
}, "clear"), Ir = /* @__PURE__ */ p((e) => e ? e.reduce((r, i) => r + ";" + i, "") : "", "getLabelStyles"), j_ = /* @__PURE__ */ p(async (e, t) => {
  let r = Ct(nt().flowchart.htmlLabels);
  const i = await Be(e, t.label, {
    style: Ir(t.labelStyle),
    useHtmlLabels: r,
    addSvgBackground: !0,
    isNode: !1
  });
  F.info("abc82", t, t.labelType);
  const n = e.insert("g").attr("class", "edgeLabel"), a = n.insert("g").attr("class", "label");
  a.node().appendChild(i);
  let o = i.getBBox();
  if (r) {
    const l = i.children[0], c = rt(i);
    o = l.getBoundingClientRect(), c.attr("width", o.width), c.attr("height", o.height);
  }
  a.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), Sn.set(t.id, n), t.width = o.width, t.height = o.height;
  let s;
  if (t.startLabelLeft) {
    const l = await Pe(
      t.startLabelLeft,
      Ir(t.labelStyle)
    ), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), kt.get(t.id) || kt.set(t.id, {}), kt.get(t.id).startLeft = c, Yr(s, t.startLabelLeft);
  }
  if (t.startLabelRight) {
    const l = await Pe(
      t.startLabelRight,
      Ir(t.labelStyle)
    ), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = c.node().appendChild(l), h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), kt.get(t.id) || kt.set(t.id, {}), kt.get(t.id).startRight = c, Yr(s, t.startLabelRight);
  }
  if (t.endLabelLeft) {
    const l = await Pe(t.endLabelLeft, Ir(t.labelStyle)), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.node().appendChild(l), kt.get(t.id) || kt.set(t.id, {}), kt.get(t.id).endLeft = c, Yr(s, t.endLabelLeft);
  }
  if (t.endLabelRight) {
    const l = await Pe(t.endLabelRight, Ir(t.labelStyle)), c = e.insert("g").attr("class", "edgeTerminals"), h = c.insert("g").attr("class", "inner");
    s = h.node().appendChild(l);
    const u = l.getBBox();
    h.attr("transform", "translate(" + -u.width / 2 + ", " + -u.height / 2 + ")"), c.node().appendChild(l), kt.get(t.id) || kt.set(t.id, {}), kt.get(t.id).endRight = c, Yr(s, t.endLabelRight);
  }
  return i;
}, "insertEdgeLabel");
function Yr(e, t) {
  nt().flowchart.htmlLabels && e && (e.style.width = t.length * 9 + "px", e.style.height = "12px");
}
p(Yr, "setTerminalWidth");
var Y_ = /* @__PURE__ */ p((e, t) => {
  F.debug("Moving label abc88 ", e.id, e.label, Sn.get(e.id), t);
  let r = t.updatedPath ? t.updatedPath : t.originalPath;
  const i = nt(), { subGraphTitleTotalMargin: n } = Ns(i);
  if (e.label) {
    const a = Sn.get(e.id);
    let o = e.x, s = e.y;
    if (r) {
      const l = Ut.calcLabelPosition(r);
      F.debug(
        "Moving label " + e.label + " from (",
        o,
        ",",
        s,
        ") to (",
        l.x,
        ",",
        l.y,
        ") abc88"
      ), t.updatedPath && (o = l.x, s = l.y);
    }
    a.attr("transform", `translate(${o}, ${s + n / 2})`);
  }
  if (e.startLabelLeft) {
    const a = kt.get(e.id).startLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = Ut.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.startLabelRight) {
    const a = kt.get(e.id).startRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = Ut.calcTerminalLabelPosition(
        e.arrowTypeStart ? 10 : 0,
        "start_right",
        r
      );
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelLeft) {
    const a = kt.get(e.id).endLeft;
    let o = e.x, s = e.y;
    if (r) {
      const l = Ut.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
  if (e.endLabelRight) {
    const a = kt.get(e.id).endRight;
    let o = e.x, s = e.y;
    if (r) {
      const l = Ut.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", r);
      o = l.x, s = l.y;
    }
    a.attr("transform", `translate(${o}, ${s})`);
  }
}, "positionEdgeLabel"), G_ = /* @__PURE__ */ p((e, t) => {
  const r = e.x, i = e.y, n = Math.abs(t.x - r), a = Math.abs(t.y - i), o = e.width / 2, s = e.height / 2;
  return n >= o || a >= s;
}, "outsideNode"), U_ = /* @__PURE__ */ p((e, t, r) => {
  F.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(r)}
  node        : x:${e.x} y:${e.y} w:${e.width} h:${e.height}`);
  const i = e.x, n = e.y, a = Math.abs(i - r.x), o = e.width / 2;
  let s = r.x < t.x ? o - a : o + a;
  const l = e.height / 2, c = Math.abs(t.y - r.y), h = Math.abs(t.x - r.x);
  if (Math.abs(n - t.y) * o > Math.abs(i - t.x) * l) {
    let u = r.y < t.y ? t.y - l - n : n - l - t.y;
    s = h * u / c;
    const f = {
      x: r.x < t.x ? r.x + s : r.x - h + s,
      y: r.y < t.y ? r.y + c - u : r.y - c + u
    };
    return s === 0 && (f.x = t.x, f.y = t.y), h === 0 && (f.x = t.x), c === 0 && (f.y = t.y), F.debug(`abc89 top/bottom calc, Q ${c}, q ${u}, R ${h}, r ${s}`, f), f;
  } else {
    r.x < t.x ? s = t.x - o - i : s = i - o - t.x;
    let u = c * s / h, f = r.x < t.x ? r.x + h - s : r.x - h + s, d = r.y < t.y ? r.y + u : r.y - u;
    return F.debug(`sides calc abc89, Q ${c}, q ${u}, R ${h}, r ${s}`, { _x: f, _y: d }), s === 0 && (f = t.x, d = t.y), h === 0 && (f = t.x), c === 0 && (d = t.y), { x: f, y: d };
  }
}, "intersection"), Sl = /* @__PURE__ */ p((e, t) => {
  F.warn("abc88 cutPathAtIntersect", e, t);
  let r = [], i = e[0], n = !1;
  return e.forEach((a) => {
    if (F.info("abc88 checking point", a, t), !G_(t, a) && !n) {
      const o = U_(t, i, a);
      F.debug("abc88 inside", a, i, o), F.debug("abc88 intersection", o, t);
      let s = !1;
      r.forEach((l) => {
        s = s || l.x === o.x && l.y === o.y;
      }), r.some((l) => l.x === o.x && l.y === o.y) ? F.warn("abc88 no intersect", o, r) : r.push(o), n = !0;
    } else
      F.warn("abc88 outside", a, i), i = a, n || r.push(a);
  }), F.debug("returning points", r), r;
}, "cutPathAtIntersect");
function sp(e) {
  const t = [], r = [];
  for (let i = 1; i < e.length - 1; i++) {
    const n = e[i - 1], a = e[i], o = e[i + 1];
    (n.x === a.x && a.y === o.y && Math.abs(a.x - o.x) > 5 && Math.abs(a.y - n.y) > 5 || n.y === a.y && a.x === o.x && Math.abs(a.x - n.x) > 5 && Math.abs(a.y - o.y) > 5) && (t.push(a), r.push(i));
  }
  return { cornerPoints: t, cornerPointPositions: r };
}
p(sp, "extractCornerPoints");
var Tl = /* @__PURE__ */ p(function(e, t, r) {
  const i = t.x - e.x, n = t.y - e.y, a = Math.sqrt(i * i + n * n), o = r / a;
  return { x: t.x - o * i, y: t.y - o * n };
}, "findAdjacentPoint"), X_ = /* @__PURE__ */ p(function(e) {
  const { cornerPointPositions: t } = sp(e), r = [];
  for (let i = 0; i < e.length; i++)
    if (t.includes(i)) {
      const n = e[i - 1], a = e[i + 1], o = e[i], s = Tl(n, o, 5), l = Tl(a, o, 5), c = l.x - s.x, h = l.y - s.y;
      r.push(s);
      const u = Math.sqrt(2) * 2;
      let f = { x: o.x, y: o.y };
      if (Math.abs(a.x - n.x) > 10 && Math.abs(a.y - n.y) >= 10) {
        F.debug(
          "Corner point fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
        const d = 5;
        o.x === s.x ? f = {
          x: c < 0 ? s.x - d + u : s.x + d - u,
          y: h < 0 ? s.y - u : s.y + u
        } : f = {
          x: c < 0 ? s.x - u : s.x + u,
          y: h < 0 ? s.y - d + u : s.y + d - u
        };
      } else
        F.debug(
          "Corner point skipping fixing",
          Math.abs(a.x - n.x),
          Math.abs(a.y - n.y)
        );
      r.push(f, l);
    } else
      r.push(e[i]);
  return r;
}, "fixCorners"), V_ = /* @__PURE__ */ p(function(e, t, r, i, n, a, o) {
  var A;
  const { handDrawnSeed: s } = nt();
  let l = t.points, c = !1;
  const h = n;
  var u = a;
  const f = [];
  for (const I in t.cssCompiledStyles)
    Ou(I) || f.push(t.cssCompiledStyles[I]);
  u.intersect && h.intersect && (l = l.slice(1, t.points.length - 1), l.unshift(h.intersect(l[0])), F.debug(
    "Last point APA12",
    t.start,
    "-->",
    t.end,
    l[l.length - 1],
    u,
    u.intersect(l[l.length - 1])
  ), l.push(u.intersect(l[l.length - 1]))), t.toCluster && (F.info("to cluster abc88", r.get(t.toCluster)), l = Sl(t.points, r.get(t.toCluster).node), c = !0), t.fromCluster && (F.debug(
    "from cluster abc88",
    r.get(t.fromCluster),
    JSON.stringify(l, null, 2)
  ), l = Sl(l.reverse(), r.get(t.fromCluster).node).reverse(), c = !0);
  let d = l.filter((I) => !Number.isNaN(I.y));
  d = X_(d);
  let g = Oi;
  switch (g = en, t.curve) {
    case "linear":
      g = en;
      break;
    case "basis":
      g = Oi;
      break;
    case "cardinal":
      g = Nc;
      break;
    case "bumpX":
      g = Dc;
      break;
    case "bumpY":
      g = Oc;
      break;
    case "catmullRom":
      g = qc;
      break;
    case "monotoneX":
      g = Uc;
      break;
    case "monotoneY":
      g = Xc;
      break;
    case "natural":
      g = Zc;
      break;
    case "step":
      g = Kc;
      break;
    case "stepAfter":
      g = Jc;
      break;
    case "stepBefore":
      g = Qc;
      break;
    default:
      g = Oi;
  }
  const { x: m, y: x } = Ub(t), y = $x().x(m).y(x).curve(g);
  let b;
  switch (t.thickness) {
    case "normal":
      b = "edge-thickness-normal";
      break;
    case "thick":
      b = "edge-thickness-thick";
      break;
    case "invisible":
      b = "edge-thickness-invisible";
      break;
    default:
      b = "edge-thickness-normal";
  }
  switch (t.pattern) {
    case "solid":
      b += " edge-pattern-solid";
      break;
    case "dotted":
      b += " edge-pattern-dotted";
      break;
    case "dashed":
      b += " edge-pattern-dashed";
      break;
    default:
      b += " edge-pattern-solid";
  }
  let w, k = y(d);
  const _ = Array.isArray(t.style) ? t.style : t.style ? [t.style] : [];
  let C = _.find((I) => I == null ? void 0 : I.startsWith("stroke:"));
  if (t.look === "handDrawn") {
    const I = W.svg(e);
    Object.assign([], d);
    const E = I.path(k, {
      roughness: 0.3,
      seed: s
    });
    b += " transition", w = rt(E).select("path").attr("id", t.id).attr("class", " " + b + (t.classes ? " " + t.classes : "")).attr("style", _ ? _.reduce((L, T) => L + ";" + T, "") : "");
    let B = w.attr("d");
    w.attr("d", B), e.node().appendChild(w.node());
  } else {
    const I = f.join(";"), E = _ ? _.reduce((T, $) => T + $ + ";", "") : "";
    let B = "";
    t.animate && (B = " edge-animation-fast"), t.animation && (B = " edge-animation-" + t.animation);
    const L = I ? I + ";" + E + ";" : E;
    w = e.append("path").attr("d", k).attr("id", t.id).attr(
      "class",
      " " + b + (t.classes ? " " + t.classes : "") + (B ?? "")
    ).attr("style", L), C = (A = L.match(/stroke:([^;]+)/)) == null ? void 0 : A[1];
  }
  let v = "";
  (nt().flowchart.arrowMarkerAbsolute || nt().state.arrowMarkerAbsolute) && (v = rc(!0)), F.info("arrowTypeStart", t.arrowTypeStart), F.info("arrowTypeEnd", t.arrowTypeEnd), W_(w, t, v, o, i, C);
  const D = Math.floor(l.length / 2), R = l[D];
  Ut.isLabelCoordinateInPath(R, w.attr("d")) || (c = !0);
  let O = {};
  return c && (O.updatedPath = l), O.originalPath = t.points, O;
}, "insertEdge"), Z_ = /* @__PURE__ */ p((e, t, r, i) => {
  t.forEach((n) => {
    fv[n](e, r, i);
  });
}, "insertMarkers"), K_ = /* @__PURE__ */ p((e, t, r) => {
  F.trace("Making markers for ", r), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 1,1 V 13 L18,7 Z");
}, "extension"), Q_ = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "composition"), J_ = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z");
}, "aggregation"), tv = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), e.append("defs").append("marker").attr("id", r + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z");
}, "dependency"), ev = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), e.append("defs").append("marker").attr("id", r + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").append("circle").attr("stroke", "black").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6);
}, "lollipop"), rv = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "point"), iv = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0");
}, "circle"), nv = /* @__PURE__ */ p((e, t, r) => {
  e.append("marker").attr("id", r + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), e.append("marker").attr("id", r + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0");
}, "cross"), av = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z");
}, "barb"), sv = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), e.append("defs").append("marker").attr("id", r + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18");
}, "only_one"), ov = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), n.append("path").attr("d", "M21,0 L21,18");
}, "zero_or_one"), lv = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), e.append("defs").append("marker").attr("id", r + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18");
}, "one_or_more"), cv = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  i.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18");
  const n = e.append("defs").append("marker").attr("id", r + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto");
  n.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), n.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18");
}, "zero_or_more"), hv = /* @__PURE__ */ p((e, t, r) => {
  e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr(
    "d",
    `M0,0
      L20,10
      M20,10
      L0,20`
  );
}, "requirement_arrow"), uv = /* @__PURE__ */ p((e, t, r) => {
  const i = e.append("defs").append("marker").attr("id", r + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g");
  i.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), i.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), i.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10);
}, "requirement_contains"), fv = {
  extension: K_,
  composition: Q_,
  aggregation: J_,
  dependency: tv,
  lollipop: ev,
  point: rv,
  circle: iv,
  cross: nv,
  barb: av,
  only_one: sv,
  zero_or_one: ov,
  one_or_more: lv,
  zero_or_more: cv,
  requirement_arrow: hv,
  requirement_contains: uv
}, dv = Z_, pv = {
  common: kr,
  getConfig: Bt,
  insertCluster: v_,
  insertEdge: V_,
  insertEdgeLabel: j_,
  insertMarkers: dv,
  insertNode: ap,
  interpolateToCurve: Ys,
  labelHelper: Z,
  log: F,
  positionEdgeLabel: Y_
}, ci = {}, op = /* @__PURE__ */ p((e) => {
  for (const t of e)
    ci[t.name] = t;
}, "registerLayoutLoaders"), gv = /* @__PURE__ */ p(() => {
  op([
    {
      name: "dagre",
      loader: /* @__PURE__ */ p(async () => await import("./dagre-5GWH7T2D-C7DKDukP.js"), "loader")
    },
    {
      name: "cose-bilkent",
      loader: /* @__PURE__ */ p(async () => await import("./cose-bilkent-S5V4N54A-CmDySzvN.js"), "loader")
    }
  ]);
}, "registerDefaultLayoutLoaders");
gv();
var KT = /* @__PURE__ */ p(async (e, t) => {
  if (!(e.layoutAlgorithm in ci))
    throw new Error(`Unknown layout algorithm: ${e.layoutAlgorithm}`);
  const r = ci[e.layoutAlgorithm];
  return (await r.loader()).render(e, t, pv, {
    algorithm: r.algorithm
  });
}, "render"), QT = /* @__PURE__ */ p((e = "", { fallback: t = "dagre" } = {}) => {
  if (e in ci)
    return e;
  if (t in ci)
    return F.warn(`Layout algorithm ${e} is not registered. Using ${t} as fallback.`), t;
  throw new Error(`Both layout algorithms ${e} and ${t} are not registered.`);
}, "getRegisteredLayoutAlgorithm"), lp = "comm", cp = "rule", hp = "decl", mv = "@import", yv = "@namespace", xv = "@keyframes", bv = "@layer", up = Math.abs, uo = String.fromCharCode;
function fp(e) {
  return e.trim();
}
function qi(e, t, r) {
  return e.replace(t, r);
}
function Cv(e, t, r) {
  return e.indexOf(t, r);
}
function sr(e, t) {
  return e.charCodeAt(t) | 0;
}
function _r(e, t, r) {
  return e.slice(t, r);
}
function te(e) {
  return e.length;
}
function wv(e) {
  return e.length;
}
function Mi(e, t) {
  return t.push(e), e;
}
var Kn = 1, vr = 1, dp = 0, Yt = 0, mt = 0, Mr = "";
function fo(e, t, r, i, n, a, o, s) {
  return { value: e, root: t, parent: r, type: i, props: n, children: a, line: Kn, column: vr, length: o, return: "", siblings: s };
}
function _v() {
  return mt;
}
function vv() {
  return mt = Yt > 0 ? sr(Mr, --Yt) : 0, vr--, mt === 10 && (vr = 1, Kn--), mt;
}
function Vt() {
  return mt = Yt < dp ? sr(Mr, Yt++) : 0, vr++, mt === 10 && (vr = 1, Kn++), mt;
}
function Ce() {
  return sr(Mr, Yt);
}
function Wi() {
  return Yt;
}
function Qn(e, t) {
  return _r(Mr, e, t);
}
function hi(e) {
  switch (e) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32:
      return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125:
      return 4;
    case 58:
      return 3;
    case 34:
    case 39:
    case 40:
    case 91:
      return 2;
    case 41:
    case 93:
      return 1;
  }
  return 0;
}
function kv(e) {
  return Kn = vr = 1, dp = te(Mr = e), Yt = 0, [];
}
function Sv(e) {
  return Mr = "", e;
}
function pa(e) {
  return fp(Qn(Yt - 1, ns(e === 91 ? e + 2 : e === 40 ? e + 1 : e)));
}
function Tv(e) {
  for (; (mt = Ce()) && mt < 33; )
    Vt();
  return hi(e) > 2 || hi(mt) > 3 ? "" : " ";
}
function Bv(e, t) {
  for (; --t && Vt() && !(mt < 48 || mt > 102 || mt > 57 && mt < 65 || mt > 70 && mt < 97); )
    ;
  return Qn(e, Wi() + (t < 6 && Ce() == 32 && Vt() == 32));
}
function ns(e) {
  for (; Vt(); )
    switch (mt) {
      case e:
        return Yt;
      case 34:
      case 39:
        e !== 34 && e !== 39 && ns(mt);
        break;
      case 40:
        e === 41 && ns(e);
        break;
      case 92:
        Vt();
        break;
    }
  return Yt;
}
function Lv(e, t) {
  for (; Vt() && e + mt !== 57; )
    if (e + mt === 84 && Ce() === 47)
      break;
  return "/*" + Qn(t, Yt - 1) + "*" + uo(e === 47 ? e : Vt());
}
function Mv(e) {
  for (; !hi(Ce()); )
    Vt();
  return Qn(e, Yt);
}
function $v(e) {
  return Sv(Hi("", null, null, null, [""], e = kv(e), 0, [0], e));
}
function Hi(e, t, r, i, n, a, o, s, l) {
  for (var c = 0, h = 0, u = o, f = 0, d = 0, g = 0, m = 1, x = 1, y = 1, b = 0, w = "", k = n, _ = a, C = i, v = w; x; )
    switch (g = b, b = Vt()) {
      case 40:
        if (g != 108 && sr(v, u - 1) == 58) {
          Cv(v += qi(pa(b), "&", "&\f"), "&\f", up(c ? s[c - 1] : 0)) != -1 && (y = -1);
          break;
        }
      case 34:
      case 39:
      case 91:
        v += pa(b);
        break;
      case 9:
      case 10:
      case 13:
      case 32:
        v += Tv(g);
        break;
      case 92:
        v += Bv(Wi() - 1, 7);
        continue;
      case 47:
        switch (Ce()) {
          case 42:
          case 47:
            Mi(Av(Lv(Vt(), Wi()), t, r, l), l), (hi(g || 1) == 5 || hi(Ce() || 1) == 5) && te(v) && _r(v, -1, void 0) !== " " && (v += " ");
            break;
          default:
            v += "/";
        }
        break;
      case 123 * m:
        s[c++] = te(v) * y;
      case 125 * m:
      case 59:
      case 0:
        switch (b) {
          case 0:
          case 125:
            x = 0;
          case 59 + h:
            y == -1 && (v = qi(v, /\f/g, "")), d > 0 && (te(v) - u || m === 0 && g === 47) && Mi(d > 32 ? Ll(v + ";", i, r, u - 1, l) : Ll(qi(v, " ", "") + ";", i, r, u - 2, l), l);
            break;
          case 59:
            v += ";";
          default:
            if (Mi(C = Bl(v, t, r, c, h, n, s, w, k = [], _ = [], u, a), a), b === 123)
              if (h === 0)
                Hi(v, t, C, C, k, a, u, s, _);
              else {
                switch (f) {
                  case 99:
                    if (sr(v, 3) === 110) break;
                  case 108:
                    if (sr(v, 2) === 97) break;
                  default:
                    h = 0;
                  case 100:
                  case 109:
                  case 115:
                }
                h ? Hi(e, C, C, i && Mi(Bl(e, C, C, 0, 0, n, s, w, n, k = [], u, _), _), n, _, u, s, i ? k : _) : Hi(v, C, C, C, [""], _, 0, s, _);
              }
        }
        c = h = d = 0, m = y = 1, w = v = "", u = o;
        break;
      case 58:
        u = 1 + te(v), d = g;
      default:
        if (m < 1) {
          if (b == 123)
            --m;
          else if (b == 125 && m++ == 0 && vv() == 125)
            continue;
        }
        switch (v += uo(b), b * m) {
          case 38:
            y = h > 0 ? 1 : (v += "\f", -1);
            break;
          case 44:
            s[c++] = (te(v) - 1) * y, y = 1;
            break;
          case 64:
            Ce() === 45 && (v += pa(Vt())), f = Ce(), h = u = te(w = v += Mv(Wi())), b++;
            break;
          case 45:
            g === 45 && te(v) == 2 && (m = 0);
        }
    }
  return a;
}
function Bl(e, t, r, i, n, a, o, s, l, c, h, u) {
  for (var f = n - 1, d = n === 0 ? a : [""], g = wv(d), m = 0, x = 0, y = 0; m < i; ++m)
    for (var b = 0, w = _r(e, f + 1, f = up(x = o[m])), k = e; b < g; ++b)
      (k = fp(x > 0 ? d[b] + " " + w : qi(w, /&\f/g, d[b]))) && (l[y++] = k);
  return fo(e, t, r, n === 0 ? cp : s, l, c, h, u);
}
function Av(e, t, r, i) {
  return fo(e, t, r, lp, uo(_v()), _r(e, 2, -2), 0, i);
}
function Ll(e, t, r, i, n) {
  return fo(e, t, r, hp, _r(e, 0, i), _r(e, i + 1, -1), i, n);
}
function as(e, t) {
  for (var r = "", i = 0; i < e.length; i++)
    r += t(e[i], i, e, t) || "";
  return r;
}
function Fv(e, t, r, i) {
  switch (e.type) {
    case bv:
      if (e.children.length) break;
    case mv:
    case yv:
    case hp:
      return e.return = e.return || e.value;
    case lp:
      return "";
    case xv:
      return e.return = e.value + "{" + as(e.children, i) + "}";
    case cp:
      if (!te(e.value = e.props.join(","))) return "";
  }
  return te(r = as(e.children, i)) ? e.return = e.value + "{" + r + "}" : "";
}
var Ev = zu(Object.keys, Object), Dv = Object.prototype, Ov = Dv.hasOwnProperty;
function Rv(e) {
  if (!qn(e))
    return Ev(e);
  var t = [];
  for (var r in Object(e))
    Ov.call(e, r) && r != "constructor" && t.push(r);
  return t;
}
var ss = Ze(ae, "DataView"), os = Ze(ae, "Promise"), ls = Ze(ae, "Set"), cs = Ze(ae, "WeakMap"), Ml = "[object Map]", Iv = "[object Object]", $l = "[object Promise]", Al = "[object Set]", Fl = "[object WeakMap]", El = "[object DataView]", Pv = Ve(ss), Nv = Ve(oi), zv = Ve(os), qv = Ve(ls), Wv = Ve(cs), Ee = Tr;
(ss && Ee(new ss(new ArrayBuffer(1))) != El || oi && Ee(new oi()) != Ml || os && Ee(os.resolve()) != $l || ls && Ee(new ls()) != Al || cs && Ee(new cs()) != Fl) && (Ee = function(e) {
  var t = Tr(e), r = t == Iv ? e.constructor : void 0, i = r ? Ve(r) : "";
  if (i)
    switch (i) {
      case Pv:
        return El;
      case Nv:
        return Ml;
      case zv:
        return $l;
      case qv:
        return Al;
      case Wv:
        return Fl;
    }
  return t;
});
var Hv = "[object Map]", jv = "[object Set]", Yv = Object.prototype, Gv = Yv.hasOwnProperty;
function Dl(e) {
  if (e == null)
    return !0;
  if (Wn(e) && (gn(e) || typeof e == "string" || typeof e.splice == "function" || Hs(e) || js(e) || pn(e)))
    return !e.length;
  var t = Ee(e);
  if (t == Hv || t == jv)
    return !e.size;
  if (qn(e))
    return !Rv(e).length;
  for (var r in e)
    if (Gv.call(e, r))
      return !1;
  return !0;
}
var pp = "c4", Uv = /* @__PURE__ */ p((e) => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(e), "detector"), Xv = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./c4Diagram-FPNF74CW-BzJUytD6.js");
  return { id: pp, diagram: e };
}, "loader"), Vv = {
  id: pp,
  detector: Uv,
  loader: Xv
}, Zv = Vv, gp = "flowchart", Kv = /* @__PURE__ */ p((e, t) => {
  var r, i;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" || ((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" ? !1 : /^\s*graph/.test(e);
}, "detector"), Qv = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-PVAE7QVJ-CkfqewEK.js");
  return { id: gp, diagram: e };
}, "loader"), Jv = {
  id: gp,
  detector: Kv,
  loader: Qv
}, tk = Jv, mp = "flowchart-v2", ek = /* @__PURE__ */ p((e, t) => {
  var r, i, n;
  return ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "dagre-d3" ? !1 : (((i = t == null ? void 0 : t.flowchart) == null ? void 0 : i.defaultRenderer) === "elk" && (t.layout = "elk"), /^\s*graph/.test(e) && ((n = t == null ? void 0 : t.flowchart) == null ? void 0 : n.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(e));
}, "detector"), rk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-PVAE7QVJ-CkfqewEK.js");
  return { id: mp, diagram: e };
}, "loader"), ik = {
  id: mp,
  detector: ek,
  loader: rk
}, nk = ik, yp = "er", ak = /* @__PURE__ */ p((e) => /^\s*erDiagram/.test(e), "detector"), sk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./erDiagram-AWTI2OKA-Bu8jHz0J.js");
  return { id: yp, diagram: e };
}, "loader"), ok = {
  id: yp,
  detector: ak,
  loader: sk
}, lk = ok, xp = "gitGraph", ck = /* @__PURE__ */ p((e) => /^\s*gitGraph/.test(e), "detector"), hk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./gitGraphDiagram-NY62KEGX-D1c6lrtv.js");
  return { id: xp, diagram: e };
}, "loader"), uk = {
  id: xp,
  detector: ck,
  loader: hk
}, fk = uk, bp = "gantt", dk = /* @__PURE__ */ p((e) => /^\s*gantt/.test(e), "detector"), pk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./ganttDiagram-OWAHRB6G-D_9sxxU_.js");
  return { id: bp, diagram: e };
}, "loader"), gk = {
  id: bp,
  detector: dk,
  loader: pk
}, mk = gk, Cp = "info", yk = /* @__PURE__ */ p((e) => /^\s*info/.test(e), "detector"), xk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./infoDiagram-STP46IZ2-BdILp4t9.js");
  return { id: Cp, diagram: e };
}, "loader"), bk = {
  id: Cp,
  detector: yk,
  loader: xk
}, wp = "pie", Ck = /* @__PURE__ */ p((e) => /^\s*pie/.test(e), "detector"), wk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./pieDiagram-ADFJNKIX-CXecVC9C.js");
  return { id: wp, diagram: e };
}, "loader"), _k = {
  id: wp,
  detector: Ck,
  loader: wk
}, _p = "quadrantChart", vk = /* @__PURE__ */ p((e) => /^\s*quadrantChart/.test(e), "detector"), kk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./quadrantDiagram-LMRXKWRM-Dd_eOjir.js");
  return { id: _p, diagram: e };
}, "loader"), Sk = {
  id: _p,
  detector: vk,
  loader: kk
}, Tk = Sk, vp = "xychart", Bk = /* @__PURE__ */ p((e) => /^\s*xychart(-beta)?/.test(e), "detector"), Lk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./xychartDiagram-6GGTOJPD-DJSlFf1b.js");
  return { id: vp, diagram: e };
}, "loader"), Mk = {
  id: vp,
  detector: Bk,
  loader: Lk
}, $k = Mk, kp = "requirement", Ak = /* @__PURE__ */ p((e) => /^\s*requirement(Diagram)?/.test(e), "detector"), Fk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./requirementDiagram-4UW4RH46-DocUziw6.js");
  return { id: kp, diagram: e };
}, "loader"), Ek = {
  id: kp,
  detector: Ak,
  loader: Fk
}, Dk = Ek, Sp = "sequence", Ok = /* @__PURE__ */ p((e) => /^\s*sequenceDiagram/.test(e), "detector"), Rk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./sequenceDiagram-C3RYC4MD-CA4-m3Dq.js");
  return { id: Sp, diagram: e };
}, "loader"), Ik = {
  id: Sp,
  detector: Ok,
  loader: Rk
}, Pk = Ik, Tp = "class", Nk = /* @__PURE__ */ p((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(e);
}, "detector"), zk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./classDiagram-KNZD7YFC-B-4TNS9A.js");
  return { id: Tp, diagram: e };
}, "loader"), qk = {
  id: Tp,
  detector: Nk,
  loader: zk
}, Wk = qk, Bp = "classDiagram", Hk = /* @__PURE__ */ p((e, t) => {
  var r;
  return /^\s*classDiagram/.test(e) && ((r = t == null ? void 0 : t.class) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(e);
}, "detector"), jk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./classDiagram-v2-RKCZMP56-B-4TNS9A.js");
  return { id: Bp, diagram: e };
}, "loader"), Yk = {
  id: Bp,
  detector: Hk,
  loader: jk
}, Gk = Yk, Lp = "state", Uk = /* @__PURE__ */ p((e, t) => {
  var r;
  return ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(e);
}, "detector"), Xk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./stateDiagram-KXAO66HF-BRj4pG2w.js");
  return { id: Lp, diagram: e };
}, "loader"), Vk = {
  id: Lp,
  detector: Uk,
  loader: Xk
}, Zk = Vk, Mp = "stateDiagram", Kk = /* @__PURE__ */ p((e, t) => {
  var r;
  return !!(/^\s*stateDiagram-v2/.test(e) || /^\s*stateDiagram/.test(e) && ((r = t == null ? void 0 : t.state) == null ? void 0 : r.defaultRenderer) === "dagre-wrapper");
}, "detector"), Qk = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./stateDiagram-v2-UMBNRL4Z-Dl_eWHJr.js");
  return { id: Mp, diagram: e };
}, "loader"), Jk = {
  id: Mp,
  detector: Kk,
  loader: Qk
}, tS = Jk, $p = "journey", eS = /* @__PURE__ */ p((e) => /^\s*journey/.test(e), "detector"), rS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./journeyDiagram-BIP6EPQ6-DjDxAk2U.js");
  return { id: $p, diagram: e };
}, "loader"), iS = {
  id: $p,
  detector: eS,
  loader: rS
}, nS = iS, aS = /* @__PURE__ */ p((e, t, r) => {
  F.debug(`rendering svg for syntax error
`);
  const i = Nx(t), n = i.append("g");
  i.attr("viewBox", "0 0 2412 512"), ic(i, 100, 512, !0), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"
  ), n.append("path").attr("class", "error-icon").attr(
    "d",
    "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"
  ), n.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), n.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${r}`);
}, "draw"), Ap = { draw: aS }, sS = Ap, oS = {
  db: {},
  renderer: Ap,
  parser: {
    parse: /* @__PURE__ */ p(() => {
    }, "parse")
  }
}, lS = oS, Fp = "flowchart-elk", cS = /* @__PURE__ */ p((e, t = {}) => {
  var r;
  return (
    // If diagram explicitly states flowchart-elk
    /^\s*flowchart-elk/.test(e) || // If a flowchart/graph diagram has their default renderer set to elk
    /^\s*(flowchart|graph)/.test(e) && ((r = t == null ? void 0 : t.flowchart) == null ? void 0 : r.defaultRenderer) === "elk" ? (t.layout = "elk", !0) : !1
  );
}, "detector"), hS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./flowDiagram-PVAE7QVJ-CkfqewEK.js");
  return { id: Fp, diagram: e };
}, "loader"), uS = {
  id: Fp,
  detector: cS,
  loader: hS
}, fS = uS, Ep = "timeline", dS = /* @__PURE__ */ p((e) => /^\s*timeline/.test(e), "detector"), pS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./timeline-definition-XQNQX7LJ-CYDrN7AM.js");
  return { id: Ep, diagram: e };
}, "loader"), gS = {
  id: Ep,
  detector: dS,
  loader: pS
}, mS = gS, Dp = "mindmap", yS = /* @__PURE__ */ p((e) => /^\s*mindmap/.test(e), "detector"), xS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./mindmap-definition-Q6HEUPPD-CEFkjGfQ.js");
  return { id: Dp, diagram: e };
}, "loader"), bS = {
  id: Dp,
  detector: yS,
  loader: xS
}, CS = bS, Op = "kanban", wS = /* @__PURE__ */ p((e) => /^\s*kanban/.test(e), "detector"), _S = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./kanban-definition-6OIFK2YF-ChmHZBJv.js");
  return { id: Op, diagram: e };
}, "loader"), vS = {
  id: Op,
  detector: wS,
  loader: _S
}, kS = vS, Rp = "sankey", SS = /* @__PURE__ */ p((e) => /^\s*sankey(-beta)?/.test(e), "detector"), TS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./sankeyDiagram-GR3RE2ED-DIMDrYui.js");
  return { id: Rp, diagram: e };
}, "loader"), BS = {
  id: Rp,
  detector: SS,
  loader: TS
}, LS = BS, Ip = "packet", MS = /* @__PURE__ */ p((e) => /^\s*packet(-beta)?/.test(e), "detector"), $S = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-S2PKOQOG-DvPk1LlR.js");
  return { id: Ip, diagram: e };
}, "loader"), AS = {
  id: Ip,
  detector: MS,
  loader: $S
}, Pp = "radar", FS = /* @__PURE__ */ p((e) => /^\s*radar-beta/.test(e), "detector"), ES = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-QEK2KX5R-DV6lXhia.js");
  return { id: Pp, diagram: e };
}, "loader"), DS = {
  id: Pp,
  detector: FS,
  loader: ES
}, Np = "block", OS = /* @__PURE__ */ p((e) => /^\s*block(-beta)?/.test(e), "detector"), RS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./blockDiagram-QIGZ2CNN-BIMk7NHL.js");
  return { id: Np, diagram: e };
}, "loader"), IS = {
  id: Np,
  detector: OS,
  loader: RS
}, PS = IS, zp = "architecture", NS = /* @__PURE__ */ p((e) => /^\s*architecture/.test(e), "detector"), zS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./architectureDiagram-W76B3OCA-CXnd277e.js");
  return { id: zp, diagram: e };
}, "loader"), qS = {
  id: zp,
  detector: NS,
  loader: zS
}, WS = qS, qp = "treemap", HS = /* @__PURE__ */ p((e) => /^\s*treemap/.test(e), "detector"), jS = /* @__PURE__ */ p(async () => {
  const { diagram: e } = await import("./diagram-N5W7TBWH-4ft0PJkY.js");
  return { id: qp, diagram: e };
}, "loader"), YS = {
  id: qp,
  detector: HS,
  loader: jS
}, Ol = !1, Jn = /* @__PURE__ */ p(() => {
  Ol || (Ol = !0, Xi("error", lS, (e) => e.toLowerCase().trim() === "error"), Xi(
    "---",
    // --- diagram type may appear if YAML front-matter is not parsed correctly
    {
      db: {
        clear: /* @__PURE__ */ p(() => {
        }, "clear")
      },
      styles: {},
      // should never be used
      renderer: {
        draw: /* @__PURE__ */ p(() => {
        }, "draw")
      },
      parser: {
        parse: /* @__PURE__ */ p(() => {
          throw new Error(
            "Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"
          );
        }, "parse")
      },
      init: /* @__PURE__ */ p(() => null, "init")
      // no op
    },
    (e) => e.toLowerCase().trimStart().startsWith("---")
  ), ya(fS, CS, WS), ya(
    Zv,
    kS,
    Gk,
    Wk,
    lk,
    mk,
    bk,
    _k,
    Dk,
    Pk,
    nk,
    tk,
    mS,
    fk,
    tS,
    Zk,
    nS,
    Tk,
    LS,
    AS,
    $k,
    PS,
    DS,
    YS
  ));
}, "addDiagrams"), GS = /* @__PURE__ */ p(async () => {
  F.debug("Loading registered diagrams");
  const t = (await Promise.allSettled(
    Object.entries(qe).map(async ([r, { detector: i, loader: n }]) => {
      if (n)
        try {
          wa(r);
        } catch {
          try {
            const { diagram: a, id: o } = await n();
            Xi(o, a, i);
          } catch (a) {
            throw F.error(`Failed to load external diagram with key ${r}. Removing from detectors.`), delete qe[r], a;
          }
        }
    })
  )).filter((r) => r.status === "rejected");
  if (t.length > 0) {
    F.error(`Failed to load ${t.length} external diagrams`);
    for (const r of t)
      F.error(r);
    throw new Error(`Failed to load ${t.length} external diagrams`);
  }
}, "loadRegisteredDiagrams"), US = "graphics-document document";
function Wp(e, t) {
  e.attr("role", US), t !== "" && e.attr("aria-roledescription", t);
}
p(Wp, "setA11yDiagramInfo");
function Hp(e, t, r, i) {
  if (e.insert !== void 0) {
    if (r) {
      const n = `chart-desc-${i}`;
      e.attr("aria-describedby", n), e.insert("desc", ":first-child").attr("id", n).text(r);
    }
    if (t) {
      const n = `chart-title-${i}`;
      e.attr("aria-labelledby", n), e.insert("title", ":first-child").attr("id", n).text(t);
    }
  }
}
p(Hp, "addSVGa11yTitleDescription");
var ze, hs = (ze = class {
  constructor(t, r, i, n, a) {
    this.type = t, this.text = r, this.db = i, this.parser = n, this.renderer = a;
  }
  static async fromText(t, r = {}) {
    var c, h;
    const i = Bt(), n = ds(t, i);
    t = GC(t) + `
`;
    try {
      wa(n);
    } catch {
      const u = mg(n);
      if (!u)
        throw new jl(`Diagram ${n} not found.`);
      const { id: f, diagram: d } = await u();
      Xi(f, d);
    }
    const { db: a, parser: o, renderer: s, init: l } = wa(n);
    return o.parser && (o.parser.yy = a), (c = a.clear) == null || c.call(a), l == null || l(i), r.title && ((h = a.setDiagramTitle) == null || h.call(a, r.title)), await o.parse(t), new ze(n, t, a, o, s);
  }
  async render(t, r) {
    await this.renderer.draw(this.text, t, r, this);
  }
  getParser() {
    return this.parser;
  }
  getType() {
    return this.type;
  }
}, p(ze, "Diagram"), ze), Rl = [], XS = /* @__PURE__ */ p(() => {
  Rl.forEach((e) => {
    e();
  }), Rl = [];
}, "attachFunctions"), VS = /* @__PURE__ */ p((e) => e.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function jp(e) {
  const t = e.match(Hl);
  if (!t)
    return {
      text: e,
      metadata: {}
    };
  let r = Gb(t[1], {
    // To support config, we need JSON schema.
    // https://www.yaml.org/spec/1.2/spec.html#id2803231
    schema: Yb
  }) ?? {};
  r = typeof r == "object" && !Array.isArray(r) ? r : {};
  const i = {};
  return r.displayMode && (i.displayMode = r.displayMode.toString()), r.title && (i.title = r.title.toString()), r.config && (i.config = r.config), {
    text: e.slice(t[0].length),
    metadata: i
  };
}
p(jp, "extractFrontMatter");
var ZS = /* @__PURE__ */ p((e) => e.replace(/\r\n?/g, `
`).replace(
  /<(\w+)([^>]*)>/g,
  (t, r, i) => "<" + r + i.replace(/="([^"]*)"/g, "='$1'") + ">"
), "cleanupText"), KS = /* @__PURE__ */ p((e) => {
  const { text: t, metadata: r } = jp(e), { displayMode: i, title: n, config: a = {} } = r;
  return i && (a.gantt || (a.gantt = {}), a.gantt.displayMode = i), { title: n, config: a, text: t };
}, "processFrontmatter"), QS = /* @__PURE__ */ p((e) => {
  const t = Ut.detectInit(e) ?? {}, r = Ut.detectDirective(e, "wrap");
  return Array.isArray(r) ? t.wrap = r.some(({ type: i }) => i === "wrap") : (r == null ? void 0 : r.type) === "wrap" && (t.wrap = !0), {
    text: EC(e),
    directive: t
  };
}, "processDirectives");
function po(e) {
  const t = ZS(e), r = KS(t), i = QS(r.text), n = Zs(r.config, i.directive);
  return e = VS(i.text), {
    code: e,
    title: r.title,
    config: n
  };
}
p(po, "preprocessDiagram");
function Yp(e) {
  const t = new TextEncoder().encode(e), r = Array.from(t, (i) => String.fromCodePoint(i)).join("");
  return btoa(r);
}
p(Yp, "toBase64");
var JS = 5e4, tT = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", eT = "sandbox", rT = "loose", iT = "http://www.w3.org/2000/svg", nT = "http://www.w3.org/1999/xlink", aT = "http://www.w3.org/1999/xhtml", sT = "100%", oT = "100%", lT = "border:0;margin:0;", cT = "margin:0", hT = "allow-top-navigation-by-user-activation allow-popups", uT = 'The "iframe" tag is not supported by your browser.', fT = ["foreignobject"], dT = ["dominant-baseline"];
function go(e) {
  const t = po(e);
  return Gi(), Fg(t.config ?? {}), t;
}
p(go, "processAndSetConfigs");
async function Gp(e, t) {
  Jn();
  try {
    const { code: r, config: i } = go(e);
    return { diagramType: (await Xp(r)).type, config: i };
  } catch (r) {
    if (t != null && t.suppressErrors)
      return !1;
    throw r;
  }
}
p(Gp, "parse");
var Il = /* @__PURE__ */ p((e, t, r = []) => `
.${e} ${t} { ${r.join(" !important; ")} !important; }`, "cssImportantStyles"), pT = /* @__PURE__ */ p((e, t = /* @__PURE__ */ new Map()) => {
  var i;
  let r = "";
  if (e.themeCSS !== void 0 && (r += `
${e.themeCSS}`), e.fontFamily !== void 0 && (r += `
:root { --mermaid-font-family: ${e.fontFamily}}`), e.altFontFamily !== void 0 && (r += `
:root { --mermaid-alt-font-family: ${e.altFontFamily}}`), t instanceof Map) {
    const s = e.htmlLabels ?? ((i = e.flowchart) == null ? void 0 : i.htmlLabels) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
    t.forEach((l) => {
      Dl(l.styles) || s.forEach((c) => {
        r += Il(l.id, c, l.styles);
      }), Dl(l.textStyles) || (r += Il(
        l.id,
        "tspan",
        ((l == null ? void 0 : l.textStyles) || []).map((c) => c.replace("color", "fill"))
      ));
    });
  }
  return r;
}, "createCssStyles"), gT = /* @__PURE__ */ p((e, t, r, i) => {
  const n = pT(e, r), a = Kg(t, n, e.themeVariables);
  return as($v(`${i}{${a}}`), Fv);
}, "createUserStyles"), mT = /* @__PURE__ */ p((e = "", t, r) => {
  let i = e;
  return !r && !t && (i = i.replace(
    /marker-end="url\([\d+./:=?A-Za-z-]*?#/g,
    'marker-end="url(#'
  )), i = Ke(i), i = i.replace(/<br>/g, "<br/>"), i;
}, "cleanUpSvgCode"), yT = /* @__PURE__ */ p((e = "", t) => {
  var n, a;
  const r = (a = (n = t == null ? void 0 : t.viewBox) == null ? void 0 : n.baseVal) != null && a.height ? t.viewBox.baseVal.height + "px" : oT, i = Yp(`<body style="${cT}">${e}</body>`);
  return `<iframe style="width:${sT};height:${r};${lT}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${hT}">
  ${uT}
</iframe>`;
}, "putIntoIFrame"), Pl = /* @__PURE__ */ p((e, t, r, i, n) => {
  const a = e.append("div");
  a.attr("id", r), i && a.attr("style", i);
  const o = a.append("svg").attr("id", t).attr("width", "100%").attr("xmlns", iT);
  return n && o.attr("xmlns:xlink", n), o.append("g"), e;
}, "appendDivSvgG");
function us(e, t) {
  return e.append("iframe").attr("id", t).attr("style", "width: 100%; height: 100%;").attr("sandbox", "");
}
p(us, "sandboxedIframe");
var xT = /* @__PURE__ */ p((e, t, r, i) => {
  var n, a, o;
  (n = e.getElementById(t)) == null || n.remove(), (a = e.getElementById(r)) == null || a.remove(), (o = e.getElementById(i)) == null || o.remove();
}, "removeExistingElements"), bT = /* @__PURE__ */ p(async function(e, t, r) {
  var I, E, B, L, T, $;
  Jn();
  const i = go(t);
  t = i.code;
  const n = Bt();
  F.debug(n), t.length > ((n == null ? void 0 : n.maxTextSize) ?? JS) && (t = tT);
  const a = "#" + e, o = "i" + e, s = "#" + o, l = "d" + e, c = "#" + l, h = /* @__PURE__ */ p(() => {
    const z = rt(f ? s : c).node();
    z && "remove" in z && z.remove();
  }, "removeTempElements");
  let u = rt("body");
  const f = n.securityLevel === eT, d = n.securityLevel === rT, g = n.fontFamily;
  if (r !== void 0) {
    if (r && (r.innerHTML = ""), f) {
      const M = us(rt(r), o);
      u = rt(M.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = rt(r);
    Pl(u, e, l, `font-family: ${g}`, nT);
  } else {
    if (xT(document, e, l, o), f) {
      const M = us(rt("body"), o);
      u = rt(M.nodes()[0].contentDocument.body), u.node().style.margin = 0;
    } else
      u = rt("body");
    Pl(u, e, l);
  }
  let m, x;
  try {
    m = await hs.fromText(t, { title: i.title });
  } catch (M) {
    if (n.suppressErrorRendering)
      throw h(), M;
    m = await hs.fromText("error"), x = M;
  }
  const y = u.select(c).node(), b = m.type, w = y.firstChild, k = w.firstChild, _ = (E = (I = m.renderer).getClasses) == null ? void 0 : E.call(I, t, m), C = gT(n, b, _, a), v = document.createElement("style");
  v.innerHTML = C, w.insertBefore(v, k);
  try {
    await m.renderer.draw(t, e, mo.version, m);
  } catch (M) {
    throw n.suppressErrorRendering ? h() : sS.draw(t, e, mo.version), M;
  }
  const D = u.select(`${c} svg`), R = (L = (B = m.db).getAccTitle) == null ? void 0 : L.call(B), O = ($ = (T = m.db).getAccDescription) == null ? void 0 : $.call(T);
  Vp(b, D, R, O), u.select(`[id="${e}"]`).selectAll("foreignobject > *").attr("xmlns", aT);
  let A = u.select(c).node().innerHTML;
  if (F.debug("config.arrowMarkerAbsolute", n.arrowMarkerAbsolute), A = mT(A, f, Ct(n.arrowMarkerAbsolute)), f) {
    const M = u.select(c + " svg").node();
    A = yT(A, M);
  } else d || (A = gr.sanitize(A, {
    ADD_TAGS: fT,
    ADD_ATTR: dT,
    HTML_INTEGRATION_POINTS: { foreignobject: !0 }
  }));
  if (XS(), x)
    throw x;
  return h(), {
    diagramType: b,
    svg: A,
    bindFunctions: m.db.bindFunctions
  };
}, "render");
function Up(e = {}) {
  var i;
  const t = xt({}, e);
  t != null && t.fontFamily && !((i = t.themeVariables) != null && i.fontFamily) && (t.themeVariables || (t.themeVariables = {}), t.themeVariables.fontFamily = t.fontFamily), $g(t), t != null && t.theme && t.theme in fe ? t.themeVariables = fe[t.theme].getThemeVariables(
    t.themeVariables
  ) : t && (t.themeVariables = fe.default.getThemeVariables(t.themeVariables));
  const r = typeof t == "object" ? Mg(t) : Vl();
  fs(r.logLevel), Jn();
}
p(Up, "initialize");
var Xp = /* @__PURE__ */ p((e, t = {}) => {
  const { code: r } = po(e);
  return hs.fromText(r, t);
}, "getDiagramFromText");
function Vp(e, t, r, i) {
  Wp(t, e), Hp(t, r, i, t.attr("id"));
}
p(Vp, "addA11yInfo");
var Ue = Object.freeze({
  render: bT,
  parse: Gp,
  getDiagramFromText: Xp,
  initialize: Up,
  getConfig: Bt,
  setConfig: Zl,
  getSiteConfig: Vl,
  updateSiteConfig: Ag,
  reset: /* @__PURE__ */ p(() => {
    Gi();
  }, "reset"),
  globalReset: /* @__PURE__ */ p(() => {
    Gi(mr);
  }, "globalReset"),
  defaultConfig: mr
});
fs(Bt().logLevel);
Gi(Bt());
var CT = /* @__PURE__ */ p((e, t, r) => {
  F.warn(e), Vs(e) ? (r && r(e.str, e.hash), t.push({ ...e, message: e.str, error: e })) : (r && r(e), e instanceof Error && t.push({
    str: e.message,
    message: e.message,
    hash: e.name,
    error: e
  }));
}, "handleError"), Zp = /* @__PURE__ */ p(async function(e = {
  querySelector: ".mermaid"
}) {
  try {
    await wT(e);
  } catch (t) {
    if (Vs(t) && F.error(t.str), zt.parseError && zt.parseError(t), !e.suppressErrors)
      throw F.error("Use the suppressErrors option to suppress these errors"), t;
  }
}, "run"), wT = /* @__PURE__ */ p(async function({ postRenderCallback: e, querySelector: t, nodes: r } = {
  querySelector: ".mermaid"
}) {
  const i = Ue.getConfig();
  F.debug(`${e ? "" : "No "}Callback function found`);
  let n;
  if (r)
    n = r;
  else if (t)
    n = document.querySelectorAll(t);
  else
    throw new Error("Nodes and querySelector are both undefined");
  F.debug(`Found ${n.length} diagrams`), (i == null ? void 0 : i.startOnLoad) !== void 0 && (F.debug("Start On Load: " + (i == null ? void 0 : i.startOnLoad)), Ue.updateSiteConfig({ startOnLoad: i == null ? void 0 : i.startOnLoad }));
  const a = new Ut.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed);
  let o;
  const s = [];
  for (const l of Array.from(n)) {
    if (F.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
      continue;
    l.setAttribute("data-processed", "true");
    const c = `mermaid-${a.next()}`;
    o = l.innerHTML, o = bf(Ut.entityDecode(o)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    const h = Ut.detectInit(o);
    h && F.debug("Detected early reinit: ", h);
    try {
      const { svg: u, bindFunctions: f } = await tg(c, o, l);
      l.innerHTML = u, e && await e(c), f && f(l);
    } catch (u) {
      CT(u, s, zt.parseError);
    }
  }
  if (s.length > 0)
    throw s[0];
}, "runThrowsErrors"), Kp = /* @__PURE__ */ p(function(e) {
  Ue.initialize(e);
}, "initialize"), _T = /* @__PURE__ */ p(async function(e, t, r) {
  F.warn("mermaid.init is deprecated. Please use run instead."), e && Kp(e);
  const i = { postRenderCallback: r, querySelector: ".mermaid" };
  typeof t == "string" ? i.querySelector = t : t && (t instanceof HTMLElement ? i.nodes = [t] : i.nodes = t), await Zp(i);
}, "init"), vT = /* @__PURE__ */ p(async (e, {
  lazyLoad: t = !0
} = {}) => {
  Jn(), ya(...e), t === !1 && await GS();
}, "registerExternalDiagrams"), Qp = /* @__PURE__ */ p(function() {
  if (zt.startOnLoad) {
    const { startOnLoad: e } = Ue.getConfig();
    e && zt.run().catch((t) => F.error("Mermaid failed to initialize", t));
  }
}, "contentLoaded");
typeof document < "u" && window.addEventListener("load", Qp, !1);
var kT = /* @__PURE__ */ p(function(e) {
  zt.parseError = e;
}, "setParseErrorHandler"), Tn = [], ga = !1, Jp = /* @__PURE__ */ p(async () => {
  if (!ga) {
    for (ga = !0; Tn.length > 0; ) {
      const e = Tn.shift();
      if (e)
        try {
          await e();
        } catch (t) {
          F.error("Error executing queue", t);
        }
    }
    ga = !1;
  }
}, "executeQueue"), ST = /* @__PURE__ */ p(async (e, t) => new Promise((r, i) => {
  const n = /* @__PURE__ */ p(() => new Promise((a, o) => {
    Ue.parse(e, t).then(
      (s) => {
        a(s), r(s);
      },
      (s) => {
        var l;
        F.error("Error parsing", s), (l = zt.parseError) == null || l.call(zt, s), o(s), i(s);
      }
    );
  }), "performCall");
  Tn.push(n), Jp().catch(i);
}), "parse"), tg = /* @__PURE__ */ p((e, t, r) => new Promise((i, n) => {
  const a = /* @__PURE__ */ p(() => new Promise((o, s) => {
    Ue.render(e, t, r).then(
      (l) => {
        o(l), i(l);
      },
      (l) => {
        var c;
        F.error("Error parsing", l), (c = zt.parseError) == null || c.call(zt, l), s(l), n(l);
      }
    );
  }), "performCall");
  Tn.push(a), Jp().catch(n);
}), "render"), TT = /* @__PURE__ */ p(() => Object.keys(qe).map((e) => ({
  id: e
})), "getRegisteredDiagramsMetadata"), zt = {
  startOnLoad: !0,
  mermaidAPI: Ue,
  parse: ST,
  render: tg,
  init: _T,
  run: Zp,
  registerExternalDiagrams: vT,
  registerLayoutLoaders: op,
  initialize: Kp,
  parseError: void 0,
  contentLoaded: Qp,
  setParseErrorHandler: kT,
  detectType: ds,
  registerIconPacks: Zw,
  getRegisteredDiagramsMetadata: TT
}, BT = zt;
/*! Check if previously processed */
/*!
 * Wait for document loaded before starting the execution
 */
const JT = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: BT
}, Symbol.toStringTag, { value: "Module" }));
export {
  nc as $,
  Ur as A,
  og as B,
  s0 as C,
  Zs as D,
  Bt as E,
  Xl as F,
  PC as G,
  Nx as H,
  mo as I,
  Yb as J,
  _g as K,
  yr as L,
  AT as M,
  Hn as N,
  rc as O,
  ps as P,
  bo as Q,
  $x as R,
  Oi as S,
  IC as T,
  fi as U,
  Xg as V,
  ui as W,
  q as X,
  X as Y,
  MC as Z,
  p as _,
  t0 as a,
  Pt as a$,
  Tx as a0,
  Bs as a1,
  IT as a2,
  zT as a3,
  Je as a4,
  No as a5,
  Po as a6,
  WT as a7,
  qT as a8,
  NT as a9,
  SC as aA,
  y2 as aB,
  xC as aC,
  qs as aD,
  Dl as aE,
  Qw as aF,
  Bx as aG,
  $T as aH,
  bi as aI,
  Zw as aJ,
  Vw as aK,
  vs as aL,
  be as aM,
  Fo as aN,
  sy as aO,
  ti as aP,
  Xe as aQ,
  TC as aR,
  Xu as aS,
  Pn as aT,
  Wn as aU,
  gn as aV,
  Zu as aW,
  Uu as aX,
  rC as aY,
  Y as aZ,
  Ou as a_,
  OT as aa,
  RT as ab,
  jT as ac,
  PT as ad,
  HT as ae,
  v_ as af,
  ap as ag,
  VT as ah,
  Ub as ai,
  Ct as aj,
  Be as ak,
  Ns as al,
  Af as am,
  Ke as an,
  rf as ao,
  Q as ap,
  re as aq,
  dv as ar,
  XT as as,
  ZT as at,
  GT as au,
  j as av,
  UT as aw,
  V_ as ax,
  Y_ as ay,
  j_ as az,
  Jg as b,
  Jm as b0,
  _s as b1,
  xc as b2,
  pi as b3,
  wc as b4,
  DT as b5,
  sg as b6,
  kC as b7,
  yC as b8,
  n2 as b9,
  BC as bA,
  qn as bB,
  JT as bC,
  Ws as ba,
  Q2 as bb,
  LC as bc,
  yi as bd,
  Tr as be,
  fn as bf,
  cC as bg,
  Rv as bh,
  mi as bi,
  pn as bj,
  iC as bk,
  qu as bl,
  o2 as bm,
  l2 as bn,
  Ee as bo,
  il as bp,
  c2 as bq,
  Hs as br,
  s2 as bs,
  f2 as bt,
  Br as bu,
  Te as bv,
  Qo as bw,
  js as bx,
  Hu as by,
  ls as bz,
  nt as c,
  rt as d,
  ic as e,
  xt as f,
  r0 as g,
  ge as h,
  jt as i,
  Ru as j,
  kr as k,
  F as l,
  af as m,
  FT as n,
  QT as o,
  i0 as p,
  n0 as q,
  KT as r,
  e0 as s,
  Gb as t,
  Ut as u,
  q_ as v,
  qC as w,
  YT as x,
  Qg as y,
  ET as z
};
